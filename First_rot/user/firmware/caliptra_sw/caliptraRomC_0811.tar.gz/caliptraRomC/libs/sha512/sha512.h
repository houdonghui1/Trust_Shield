// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#ifndef SHA512_H
  #define SHA512_H
  
#include "caliptra_defines.h"
#include "caliptra_reg.h"
#include "riscv_hw_if.h"

#define SHA512_BLOCK_SIZE 128
#define SHA512_DIGEST_WORDS 16

/* --------------- symbols/typedefs --------------- */
enum sha512_mode_e {
    SHA512_224_MODE = 0x0,
    SHA512_256_MODE = 0x1,
    SHA512_384_MODE = 0x2,
    SHA512_512_MODE = 0x3
};

typedef struct {
    uint8_t   data_size;
    uint32_t  data[32];
}sha512_io;

/* --------------- Function Prototypes --------------- */
void sha_init(enum sha512_mode_e mode);
void sha_next(enum sha512_mode_e mode);
void sha_init_last(enum sha512_mode_e mode);
void sha_next_last(enum sha512_mode_e mode);

void sha384_kvflow(uint8_t sha_kv_id, uint8_t store_to_kv, uint8_t digest_kv_id, uint32_t expected_digest[12]);
void sha512_zeroize();
void sha512_flow(sha512_io block, uint8_t mode, sha512_io digest);
void sha512_measure(sha512_io block, uint8_t mode, uint32_t* measurevalue);
uint32_t measure_fmc(const uint8_t *recv_data, uint32_t recv_data_len);
uint32_t measure_rt(const uint8_t *recv_data, uint32_t recv_data_len);
uint32_t measure_soc(const uint8_t *recv_data, uint32_t recv_data_len);

//polls until sha512 is ready to be used
inline void sha512_poll_ready() {
    while((lsu_read_32(CLP_SHA512_REG_SHA512_STATUS) & SHA512_REG_SHA512_STATUS_READY_MASK) == 0);
}
//polls until sha512 is done and valid is set
inline void sha512_poll_valid() {
    while((lsu_read_32(CLP_SHA512_REG_SHA512_STATUS) & SHA512_REG_SHA512_STATUS_VALID_MASK) == 0);
}
//Gen hash functions
void sha_gen_hash_start();
inline void sha_poll_gen_hash_ready() {
    while((lsu_read_32(CLP_SHA512_REG_SHA512_GEN_PCR_HASH_STATUS) & SHA512_REG_SHA512_GEN_PCR_HASH_STATUS_READY_MASK) == 0);
}
inline void sha_poll_gen_hash_valid() {
    while((lsu_read_32(CLP_SHA512_REG_SHA512_GEN_PCR_HASH_STATUS) & SHA512_REG_SHA512_GEN_PCR_HASH_STATUS_VALID_MASK) == 0);
}

#endif
