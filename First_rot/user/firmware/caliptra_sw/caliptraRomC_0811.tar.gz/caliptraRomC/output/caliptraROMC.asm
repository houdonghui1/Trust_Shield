
/home/jdeng/work/caliptra-sw/rom/dev/caliptraRomC/output/caliptraROMC.elf：     文件格式 elf32-littleriscv


Disassembly of section .text.init:

40015000 <_start>:
40015000:	b0201073          	csrw	minstret,zero
40015004:	b8201073          	csrw	minstreth,zero
40015008:	aaaaa2b7          	lui	t0,0xaaaaa
4001500c:	0a928293          	add	t0,t0,169 # aaaaa0a9 <_tbs_der_store_end+0x5aa8b089>
40015010:	7c029073          	csrw	milm_ctl,t0
40015014:	4291                	li	t0,4
40015016:	0000100f          	fence.i
4001501a:	7f929073          	csrw	mattri2_base,t0
4001501e:	0000100f          	fence.i
40015022:	00004297          	auipc	t0,0x4
40015026:	ef628293          	add	t0,t0,-266 # 40018f18 <early_trap_vector>
4001502a:	30529073          	csrw	mtvec,t0
4001502e:	00004297          	auipc	t0,0x4
40015032:	20a28293          	add	t0,t0,522 # 40019238 <_data_lma_start>
40015036:	00005317          	auipc	t1,0x5
4001503a:	47230313          	add	t1,t1,1138 # 4001a4a8 <_bss_lma_end>
4001503e:	0fffb397          	auipc	t2,0xfffb
40015042:	fc238393          	add	t2,t2,-62 # 50010000 <_data_vma_start>

40015046 <data_cp_loop>:
40015046:	0002ae03          	lw	t3,0(t0)
4001504a:	01c3a023          	sw	t3,0(t2)
4001504e:	0291                	add	t0,t0,4
40015050:	0391                	add	t2,t2,4
40015052:	fe62eae3          	bltu	t0,t1,40015046 <data_cp_loop>
40015056:	00005297          	auipc	t0,0x5
4001505a:	45228293          	add	t0,t0,1106 # 4001a4a8 <_bss_lma_end>
4001505e:	00005317          	auipc	t1,0x5
40015062:	44a30313          	add	t1,t1,1098 # 4001a4a8 <_bss_lma_end>
40015066:	0fffc397          	auipc	t2,0xfffc
4001506a:	20a38393          	add	t2,t2,522 # 50011270 <SOC_FW_data>

4001506e <bss_cp_loop>:
4001506e:	0002ae03          	lw	t3,0(t0)
40015072:	01c3a023          	sw	t3,0(t2)
40015076:	0291                	add	t0,t0,4
40015078:	0391                	add	t2,t2,4
4001507a:	fe62eae3          	bltu	t0,t1,4001506e <bss_cp_loop>
4001507e:	10007117          	auipc	sp,0x10007
40015082:	1f210113          	add	sp,sp,498 # 5001c270 <STACK>
40015086:	29d030ef          	jal	40018b22 <main>

4001508a <_finish>:
4001508a:	300302b7          	lui	t0,0x30030
4001508e:	0cc28293          	add	t0,t0,204 # 300300cc <mfdc+0x3002f8d3>
40015092:	0ff00f13          	li	t5,255
40015096:	01e28023          	sb	t5,0(t0)
4001509a:	fe0008e3          	beqz	zero,4001508a <_finish>
4001509e:	0001                	nop
400150a0:	0001                	nop
400150a2:	0001                	nop
400150a4:	0001                	nop
400150a6:	0001                	nop
400150a8:	0001                	nop
400150aa:	0001                	nop
400150ac:	0001                	nop
400150ae:	0001                	nop
400150b0:	0001                	nop
400150b2:	0001                	nop
400150b4:	0001                	nop
400150b6:	0001                	nop
400150b8:	0001                	nop
400150ba:	0001                	nop
400150bc:	0001                	nop
400150be:	0001                	nop
400150c0:	0001                	nop
400150c2:	0001                	nop
400150c4:	0001                	nop
400150c6:	0001                	nop
400150c8:	0001                	nop
400150ca:	0001                	nop
400150cc:	0001                	nop
400150ce:	0001                	nop
400150d0:	0001                	nop
400150d2:	0001                	nop
400150d4:	0001                	nop
400150d6:	0001                	nop
400150d8:	0001                	nop
400150da:	0001                	nop
400150dc:	0001                	nop
400150de:	0001                	nop
400150e0:	0001                	nop
400150e2:	0001                	nop
400150e4:	0001                	nop
400150e6:	0001                	nop
400150e8:	0001                	nop
400150ea:	0001                	nop
400150ec:	0001                	nop
400150ee:	0001                	nop
400150f0:	0001                	nop
400150f2:	0001                	nop
400150f4:	0001                	nop
400150f6:	0001                	nop
400150f8:	0001                	nop
400150fa:	0001                	nop
400150fc:	0001                	nop
400150fe:	0001                	nop
40015100:	0001                	nop
40015102:	0001                	nop
40015104:	0001                	nop
40015106:	0001                	nop
40015108:	0001                	nop
4001510a:	0001                	nop
4001510c:	0001                	nop
4001510e:	0001                	nop
40015110:	0001                	nop
40015112:	0001                	nop
40015114:	0001                	nop
40015116:	0001                	nop
40015118:	0001                	nop
4001511a:	0001                	nop
4001511c:	0001                	nop
4001511e:	0001                	nop
40015120:	0001                	nop
40015122:	0001                	nop
40015124:	0001                	nop
40015126:	0001                	nop
40015128:	0001                	nop
4001512a:	0001                	nop
4001512c:	0001                	nop
4001512e:	0001                	nop
40015130:	0001                	nop
40015132:	0001                	nop
40015134:	0001                	nop
40015136:	0001                	nop
40015138:	0001                	nop
4001513a:	0001                	nop
4001513c:	0001                	nop
4001513e:	0001                	nop
40015140:	0001                	nop
40015142:	0001                	nop
40015144:	0001                	nop
40015146:	0001                	nop
40015148:	0001                	nop
4001514a:	0001                	nop
4001514c:	0001                	nop
4001514e:	0001                	nop
40015150:	0001                	nop
40015152:	0001                	nop
40015154:	0001                	nop
40015156:	0001                	nop
40015158:	0001                	nop
4001515a:	0001                	nop
4001515c:	0001                	nop
4001515e:	0001                	nop
40015160:	0001                	nop
40015162:	0001                	nop
40015164:	0001                	nop

Disassembly of section .text:

40015168 <store_to_datavault>:
40015168:	1101                	add	sp,sp,-32
4001516a:	040077b7          	lui	a5,0x4007
4001516e:	c64e                	sw	s3,12(sp)
40015170:	c256                	sw	s5,4(sp)
40015172:	08278793          	add	a5,a5,130 # 4007082 <mfdc+0x4006889>
40015176:	8aaa                	mv	s5,a0
40015178:	89ae                	mv	s3,a1
4001517a:	50010537          	lui	a0,0x50010
4001517e:	500105b7          	lui	a1,0x50010
40015182:	ca26                	sw	s1,20(sp)
40015184:	c452                	sw	s4,8(sp)
40015186:	84b2                	mv	s1,a2
40015188:	00f60a33          	add	s4,a2,a5
4001518c:	25058593          	add	a1,a1,592 # 50010250 <__func__.1>
40015190:	97b6                	add	a5,a5,a3
40015192:	0d100613          	li	a2,209
40015196:	16450513          	add	a0,a0,356 # 50010164 <trap_msg+0x7c>
4001519a:	cc22                	sw	s0,24(sp)
4001519c:	c84a                	sw	s2,16(sp)
4001519e:	00279413          	sll	s0,a5,0x2
400151a2:	ce06                	sw	ra,28(sp)
400151a4:	8936                	mv	s2,a3
400151a6:	6e5000ef          	jal	4001608a <printf>
400151aa:	47a5                	li	a5,9
400151ac:	0097e463          	bltu	a5,s1,400151b4 <store_to_datavault+0x4c>
400151b0:	0327f263          	bgeu	a5,s2,400151d4 <store_to_datavault+0x6c>
400151b4:	50010537          	lui	a0,0x50010
400151b8:	17850513          	add	a0,a0,376 # 50010178 <trap_msg+0x90>
400151bc:	6cd000ef          	jal	40016088 <puts>
400151c0:	557d                	li	a0,-1
400151c2:	40f2                	lw	ra,28(sp)
400151c4:	4462                	lw	s0,24(sp)
400151c6:	44d2                	lw	s1,20(sp)
400151c8:	4942                	lw	s2,16(sp)
400151ca:	49b2                	lw	s3,12(sp)
400151cc:	4a22                	lw	s4,8(sp)
400151ce:	4a92                	lw	s5,4(sp)
400151d0:	6105                	add	sp,sp,32
400151d2:	8082                	ret
400151d4:	03000713          	li	a4,48
400151d8:	02e486b3          	mul	a3,s1,a4
400151dc:	1001c7b7          	lui	a5,0x1001c
400151e0:	23078793          	add	a5,a5,560 # 1001c230 <mfdc+0x1001ba37>
400151e4:	0a0a                	sll	s4,s4,0x2
400151e6:	96be                	add	a3,a3,a5
400151e8:	4781                	li	a5,0
400151ea:	00fa85b3          	add	a1,s5,a5
400151ee:	00f68633          	add	a2,a3,a5
400151f2:	418c                	lw	a1,0(a1)
400151f4:	c20c                	sw	a1,0(a2)
400151f6:	0791                	add	a5,a5,4
400151f8:	fee799e3          	bne	a5,a4,400151ea <store_to_datavault+0x82>
400151fc:	0220000f          	fence	r,r
40015200:	0220000f          	fence	r,r
40015204:	02f907b3          	mul	a5,s2,a5
40015208:	4705                	li	a4,1
4001520a:	00ea2023          	sw	a4,0(s4)
4001520e:	1001c737          	lui	a4,0x1001c
40015212:	23070713          	add	a4,a4,560 # 1001c230 <mfdc+0x1001ba37>
40015216:	03000693          	li	a3,48
4001521a:	97ba                	add	a5,a5,a4
4001521c:	4701                	li	a4,0
4001521e:	00e985b3          	add	a1,s3,a4
40015222:	00e78633          	add	a2,a5,a4
40015226:	418c                	lw	a1,0(a1)
40015228:	c20c                	sw	a1,0(a2)
4001522a:	0711                	add	a4,a4,4
4001522c:	fed719e3          	bne	a4,a3,4001521e <store_to_datavault+0xb6>
40015230:	0220000f          	fence	r,r
40015234:	0220000f          	fence	r,r
40015238:	4785                	li	a5,1
4001523a:	50010537          	lui	a0,0x50010
4001523e:	c01c                	sw	a5,0(s0)
40015240:	864a                	mv	a2,s2
40015242:	85a6                	mv	a1,s1
40015244:	1a450513          	add	a0,a0,420 # 500101a4 <trap_msg+0xbc>
40015248:	643000ef          	jal	4001608a <printf>
4001524c:	4501                	li	a0,0
4001524e:	bf95                	j	400151c2 <store_to_datavault+0x5a>

40015250 <read_from_datavault>:
40015250:	1101                	add	sp,sp,-32
40015252:	c84a                	sw	s2,16(sp)
40015254:	c64e                	sw	s3,12(sp)
40015256:	892e                	mv	s2,a1
40015258:	89aa                	mv	s3,a0
4001525a:	500105b7          	lui	a1,0x50010
4001525e:	50010537          	lui	a0,0x50010
40015262:	cc22                	sw	s0,24(sp)
40015264:	23c58593          	add	a1,a1,572 # 5001023c <__func__.0>
40015268:	8432                	mv	s0,a2
4001526a:	16450513          	add	a0,a0,356 # 50010164 <trap_msg+0x7c>
4001526e:	0ec00613          	li	a2,236
40015272:	ca26                	sw	s1,20(sp)
40015274:	ce06                	sw	ra,28(sp)
40015276:	84b6                	mv	s1,a3
40015278:	613000ef          	jal	4001608a <printf>
4001527c:	47a5                	li	a5,9
4001527e:	0087e463          	bltu	a5,s0,40015286 <read_from_datavault+0x36>
40015282:	0297f063          	bgeu	a5,s1,400152a2 <read_from_datavault+0x52>
40015286:	50010537          	lui	a0,0x50010
4001528a:	17850513          	add	a0,a0,376 # 50010178 <trap_msg+0x90>
4001528e:	5fb000ef          	jal	40016088 <puts>
40015292:	557d                	li	a0,-1
40015294:	40f2                	lw	ra,28(sp)
40015296:	4462                	lw	s0,24(sp)
40015298:	44d2                	lw	s1,20(sp)
4001529a:	4942                	lw	s2,16(sp)
4001529c:	49b2                	lw	s3,12(sp)
4001529e:	6105                	add	sp,sp,32
400152a0:	8082                	ret
400152a2:	03000713          	li	a4,48
400152a6:	02e406b3          	mul	a3,s0,a4
400152aa:	1001c7b7          	lui	a5,0x1001c
400152ae:	23078793          	add	a5,a5,560 # 1001c230 <mfdc+0x1001ba37>
400152b2:	96be                	add	a3,a3,a5
400152b4:	4781                	li	a5,0
400152b6:	00f68633          	add	a2,a3,a5
400152ba:	420c                	lw	a1,0(a2)
400152bc:	00f98633          	add	a2,s3,a5
400152c0:	c20c                	sw	a1,0(a2)
400152c2:	0791                	add	a5,a5,4
400152c4:	fee799e3          	bne	a5,a4,400152b6 <read_from_datavault+0x66>
400152c8:	02f487b3          	mul	a5,s1,a5
400152cc:	1001c737          	lui	a4,0x1001c
400152d0:	23070713          	add	a4,a4,560 # 1001c230 <mfdc+0x1001ba37>
400152d4:	03000693          	li	a3,48
400152d8:	97ba                	add	a5,a5,a4
400152da:	4701                	li	a4,0
400152dc:	00e78633          	add	a2,a5,a4
400152e0:	420c                	lw	a1,0(a2)
400152e2:	00e90633          	add	a2,s2,a4
400152e6:	c20c                	sw	a1,0(a2)
400152e8:	0711                	add	a4,a4,4
400152ea:	fed719e3          	bne	a4,a3,400152dc <read_from_datavault+0x8c>
400152ee:	50010537          	lui	a0,0x50010
400152f2:	8626                	mv	a2,s1
400152f4:	85a2                	mv	a1,s0
400152f6:	1f050513          	add	a0,a0,496 # 500101f0 <trap_msg+0x108>
400152fa:	591000ef          	jal	4001608a <printf>
400152fe:	4501                	li	a0,0
40015300:	bf51                	j	40015294 <read_from_datavault+0x44>

40015302 <ecc_keygen_flow>:
40015302:	7179                	add	sp,sp,-48
40015304:	ce4e                	sw	s3,28(sp)
40015306:	89ba                	mv	s3,a4
40015308:	10008737          	lui	a4,0x10008
4001530c:	d422                	sw	s0,40(sp)
4001530e:	d226                	sw	s1,36(sp)
40015310:	d04a                	sw	s2,32(sp)
40015312:	cc52                	sw	s4,24(sp)
40015314:	ca56                	sw	s5,20(sp)
40015316:	d606                	sw	ra,44(sp)
40015318:	c85a                	sw	s6,16(sp)
4001531a:	c65e                	sw	s7,12(sp)
4001531c:	8aaa                	mv	s5,a0
4001531e:	8a2e                	mv	s4,a1
40015320:	8432                	mv	s0,a2
40015322:	8936                	mv	s2,a3
40015324:	84be                	mv	s1,a5
40015326:	0761                	add	a4,a4,24 # 10008018 <mfdc+0x1000781f>
40015328:	431c                	lw	a5,0(a4)
4001532a:	8b85                	and	a5,a5,1
4001532c:	dff5                	beqz	a5,40015328 <ecc_keygen_flow+0x26>
4001532e:	000ac783          	lbu	a5,0(s5)
40015332:	50010bb7          	lui	s7,0x50010
40015336:	50010b37          	lui	s6,0x50010
4001533a:	18078c63          	beqz	a5,400154d2 <ecc_keygen_flow+0x1d0>
4001533e:	03900613          	li	a2,57
40015342:	510b8593          	add	a1,s7,1296 # 50010510 <__func__.0>
40015346:	164b0513          	add	a0,s6,356 # 50010164 <trap_msg+0x7c>
4001534a:	541000ef          	jal	4001608a <printf>
4001534e:	001ac783          	lbu	a5,1(s5)
40015352:	0786                	sll	a5,a5,0x1
40015354:	03e7f793          	and	a5,a5,62
40015358:	0017e793          	or	a5,a5,1
4001535c:	0220000f          	fence	r,r
40015360:	0220000f          	fence	r,r
40015364:	10008737          	lui	a4,0x10008
40015368:	60f72423          	sw	a5,1544(a4) # 10008608 <mfdc+0x10007e0f>
4001536c:	60c70713          	add	a4,a4,1548
40015370:	431c                	lw	a5,0(a4)
40015372:	8b89                	and	a5,a5,2
40015374:	dff5                	beqz	a5,40015370 <ecc_keygen_flow+0x6e>
40015376:	00094783          	lbu	a5,0(s2)
4001537a:	cb85                	beqz	a5,400153aa <ecc_keygen_flow+0xa8>
4001537c:	04b00613          	li	a2,75
40015380:	510b8593          	add	a1,s7,1296
40015384:	164b0513          	add	a0,s6,356
40015388:	503000ef          	jal	4001608a <printf>
4001538c:	00194783          	lbu	a5,1(s2)
40015390:	0786                	sll	a5,a5,0x1
40015392:	03e7f793          	and	a5,a5,62
40015396:	2017e793          	or	a5,a5,513
4001539a:	0220000f          	fence	r,r
4001539e:	0220000f          	fence	r,r
400153a2:	10008737          	lui	a4,0x10008
400153a6:	60f72823          	sw	a5,1552(a4) # 10008610 <mfdc+0x10007e17>
400153aa:	100087b7          	lui	a5,0x10008
400153ae:	efff8637          	lui	a2,0xefff8
400153b2:	10008737          	lui	a4,0x10008
400153b6:	50078793          	add	a5,a5,1280 # 10008500 <mfdc+0x10007d07>
400153ba:	b0060613          	add	a2,a2,-1280 # efff7b00 <_tbs_der_store_end+0x9ffd8ae0>
400153be:	53070713          	add	a4,a4,1328 # 10008530 <mfdc+0x10007d37>
400153c2:	85be                	mv	a1,a5
400153c4:	0791                	add	a5,a5,4
400153c6:	00c786b3          	add	a3,a5,a2
400153ca:	96d2                	add	a3,a3,s4
400153cc:	4294                	lw	a3,0(a3)
400153ce:	c194                	sw	a3,0(a1)
400153d0:	fee799e3          	bne	a5,a4,400153c2 <ecc_keygen_flow+0xc0>
400153d4:	100087b7          	lui	a5,0x10008
400153d8:	efff8637          	lui	a2,0xefff8
400153dc:	10008737          	lui	a4,0x10008
400153e0:	48078793          	add	a5,a5,1152 # 10008480 <mfdc+0x10007c87>
400153e4:	b8060613          	add	a2,a2,-1152 # efff7b80 <_tbs_der_store_end+0x9ffd8b60>
400153e8:	4b070713          	add	a4,a4,1200 # 100084b0 <mfdc+0x10007cb7>
400153ec:	85be                	mv	a1,a5
400153ee:	0791                	add	a5,a5,4
400153f0:	00c786b3          	add	a3,a5,a2
400153f4:	96a2                	add	a3,a3,s0
400153f6:	4294                	lw	a3,0(a3)
400153f8:	c194                	sw	a3,0(a1)
400153fa:	fee799e3          	bne	a5,a4,400153ec <ecc_keygen_flow+0xea>
400153fe:	50010537          	lui	a0,0x50010
40015402:	26450513          	add	a0,a0,612 # 50010264 <__func__.1+0x14>
40015406:	483000ef          	jal	40016088 <puts>
4001540a:	0220000f          	fence	r,r
4001540e:	0220000f          	fence	r,r
40015412:	100087b7          	lui	a5,0x10008
40015416:	4705                	li	a4,1
40015418:	cb98                	sw	a4,16(a5)
4001541a:	01878713          	add	a4,a5,24 # 10008018 <mfdc+0x1000781f>
4001541e:	431c                	lw	a5,0(a4)
40015420:	8b89                	and	a5,a5,2
40015422:	dff5                	beqz	a5,4001541e <ecc_keygen_flow+0x11c>
40015424:	00094783          	lbu	a5,0(s2)
40015428:	c3fd                	beqz	a5,4001550e <ecc_keygen_flow+0x20c>
4001542a:	50010537          	lui	a0,0x50010
4001542e:	27050513          	add	a0,a0,624 # 50010270 <__func__.1+0x20>
40015432:	457000ef          	jal	40016088 <puts>
40015436:	10008737          	lui	a4,0x10008
4001543a:	61470713          	add	a4,a4,1556 # 10008614 <mfdc+0x10007e1b>
4001543e:	431c                	lw	a5,0(a4)
40015440:	8b89                	and	a5,a5,2
40015442:	dff5                	beqz	a5,4001543e <ecc_keygen_flow+0x13c>
40015444:	50010537          	lui	a0,0x50010
40015448:	2fc50513          	add	a0,a0,764 # 500102fc <__func__.1+0xac>
4001544c:	43d000ef          	jal	40016088 <puts>
40015450:	0009c783          	lbu	a5,0(s3)
40015454:	12078963          	beqz	a5,40015586 <ecc_keygen_flow+0x284>
40015458:	100086b7          	lui	a3,0x10008
4001545c:	efff8637          	lui	a2,0xefff8
40015460:	100087b7          	lui	a5,0x10008
40015464:	20068693          	add	a3,a3,512 # 10008200 <mfdc+0x10007a07>
40015468:	e0460613          	add	a2,a2,-508 # efff7e04 <_tbs_der_store_end+0x9ffd8de4>
4001546c:	23078793          	add	a5,a5,560 # 10008230 <mfdc+0x10007a37>
40015470:	00c68733          	add	a4,a3,a2
40015474:	428c                	lw	a1,0(a3)
40015476:	974e                	add	a4,a4,s3
40015478:	c30c                	sw	a1,0(a4)
4001547a:	0691                	add	a3,a3,4
4001547c:	fef69ae3          	bne	a3,a5,40015470 <ecc_keygen_flow+0x16e>
40015480:	50010537          	lui	a0,0x50010
40015484:	34850513          	add	a0,a0,840 # 50010348 <__func__.1+0xf8>
40015488:	401000ef          	jal	40016088 <puts>
4001548c:	0004c783          	lbu	a5,0(s1)
40015490:	16078163          	beqz	a5,400155f2 <ecc_keygen_flow+0x2f0>
40015494:	10008737          	lui	a4,0x10008
40015498:	efff8637          	lui	a2,0xefff8
4001549c:	100087b7          	lui	a5,0x10008
400154a0:	28070713          	add	a4,a4,640 # 10008280 <mfdc+0x10007a87>
400154a4:	d8460613          	add	a2,a2,-636 # efff7d84 <_tbs_der_store_end+0x9ffd8d64>
400154a8:	2b078793          	add	a5,a5,688 # 100082b0 <mfdc+0x10007ab7>
400154ac:	00c706b3          	add	a3,a4,a2
400154b0:	430c                	lw	a1,0(a4)
400154b2:	96a6                	add	a3,a3,s1
400154b4:	c28c                	sw	a1,0(a3)
400154b6:	0711                	add	a4,a4,4
400154b8:	fef71ae3          	bne	a4,a5,400154ac <ecc_keygen_flow+0x1aa>
400154bc:	50b2                	lw	ra,44(sp)
400154be:	5422                	lw	s0,40(sp)
400154c0:	5492                	lw	s1,36(sp)
400154c2:	5902                	lw	s2,32(sp)
400154c4:	49f2                	lw	s3,28(sp)
400154c6:	4a62                	lw	s4,24(sp)
400154c8:	4ad2                	lw	s5,20(sp)
400154ca:	4b42                	lw	s6,16(sp)
400154cc:	4bb2                	lw	s7,12(sp)
400154ce:	6145                	add	sp,sp,48
400154d0:	8082                	ret
400154d2:	04200613          	li	a2,66
400154d6:	510b8593          	add	a1,s7,1296
400154da:	164b0513          	add	a0,s6,356
400154de:	3ad000ef          	jal	4001608a <printf>
400154e2:	100087b7          	lui	a5,0x10008
400154e6:	efff8637          	lui	a2,0xefff8
400154ea:	10008737          	lui	a4,0x10008
400154ee:	08078793          	add	a5,a5,128 # 10008080 <mfdc+0x10007887>
400154f2:	f8060613          	add	a2,a2,-128 # efff7f80 <_tbs_der_store_end+0x9ffd8f60>
400154f6:	0b070713          	add	a4,a4,176 # 100080b0 <mfdc+0x100078b7>
400154fa:	85be                	mv	a1,a5
400154fc:	0791                	add	a5,a5,4
400154fe:	00c786b3          	add	a3,a5,a2
40015502:	96d6                	add	a3,a3,s5
40015504:	4294                	lw	a3,0(a3)
40015506:	c194                	sw	a3,0(a1)
40015508:	fee799e3          	bne	a5,a4,400154fa <ecc_keygen_flow+0x1f8>
4001550c:	b5ad                	j	40015376 <ecc_keygen_flow+0x74>
4001550e:	50010537          	lui	a0,0x50010
40015512:	28450513          	add	a0,a0,644 # 50010284 <__func__.1+0x34>
40015516:	373000ef          	jal	40016088 <puts>
4001551a:	100087b7          	lui	a5,0x10008
4001551e:	efff86b7          	lui	a3,0xefff8
40015522:	10008737          	lui	a4,0x10008
40015526:	4401                	li	s0,0
40015528:	18078793          	add	a5,a5,384 # 10008180 <mfdc+0x10007987>
4001552c:	e8468693          	add	a3,a3,-380 # efff7e84 <_tbs_der_store_end+0x9ffd8e64>
40015530:	1b070713          	add	a4,a4,432 # 100081b0 <mfdc+0x100079b7>
40015534:	00d78633          	add	a2,a5,a3
40015538:	964a                	add	a2,a2,s2
4001553a:	0007aa03          	lw	s4,0(a5)
4001553e:	4210                	lw	a2,0(a2)
40015540:	02ca0e63          	beq	s4,a2,4001557c <ecc_keygen_flow+0x27a>
40015544:	50010537          	lui	a0,0x50010
40015548:	85a2                	mv	a1,s0
4001554a:	2a050513          	add	a0,a0,672 # 500102a0 <__func__.1+0x50>
4001554e:	33d000ef          	jal	4001608a <printf>
40015552:	50010537          	lui	a0,0x50010
40015556:	85d2                	mv	a1,s4
40015558:	2cc50513          	add	a0,a0,716 # 500102cc <__func__.1+0x7c>
4001555c:	32f000ef          	jal	4001608a <printf>
40015560:	040a                	sll	s0,s0,0x2
40015562:	008906b3          	add	a3,s2,s0
40015566:	50010537          	lui	a0,0x50010
4001556a:	42cc                	lw	a1,4(a3)
4001556c:	2e450513          	add	a0,a0,740 # 500102e4 <__func__.1+0x94>
40015570:	31b000ef          	jal	4001608a <printf>
40015574:	4505                	li	a0,1
40015576:	30d000ef          	jal	40016082 <putchar>
4001557a:	a001                	j	4001557a <ecc_keygen_flow+0x278>
4001557c:	0791                	add	a5,a5,4
4001557e:	0405                	add	s0,s0,1
40015580:	fae79ae3          	bne	a5,a4,40015534 <ecc_keygen_flow+0x232>
40015584:	b5c1                	j	40015444 <ecc_keygen_flow+0x142>
40015586:	100086b7          	lui	a3,0x10008
4001558a:	efff8737          	lui	a4,0xefff8
4001558e:	100087b7          	lui	a5,0x10008
40015592:	4401                	li	s0,0
40015594:	20068693          	add	a3,a3,512 # 10008200 <mfdc+0x10007a07>
40015598:	e0470713          	add	a4,a4,-508 # efff7e04 <_tbs_der_store_end+0x9ffd8de4>
4001559c:	23078793          	add	a5,a5,560 # 10008230 <mfdc+0x10007a37>
400155a0:	00e68633          	add	a2,a3,a4
400155a4:	964e                	add	a2,a2,s3
400155a6:	0006a903          	lw	s2,0(a3)
400155aa:	4210                	lw	a2,0(a2)
400155ac:	02c90e63          	beq	s2,a2,400155e8 <ecc_keygen_flow+0x2e6>
400155b0:	50010537          	lui	a0,0x50010
400155b4:	85a2                	mv	a1,s0
400155b6:	31850513          	add	a0,a0,792 # 50010318 <__func__.1+0xc8>
400155ba:	2d1000ef          	jal	4001608a <printf>
400155be:	50010537          	lui	a0,0x50010
400155c2:	85ca                	mv	a1,s2
400155c4:	2cc50513          	add	a0,a0,716 # 500102cc <__func__.1+0x7c>
400155c8:	2c3000ef          	jal	4001608a <printf>
400155cc:	040a                	sll	s0,s0,0x2
400155ce:	00898733          	add	a4,s3,s0
400155d2:	50010537          	lui	a0,0x50010
400155d6:	434c                	lw	a1,4(a4)
400155d8:	2e450513          	add	a0,a0,740 # 500102e4 <__func__.1+0x94>
400155dc:	2af000ef          	jal	4001608a <printf>
400155e0:	4505                	li	a0,1
400155e2:	2a1000ef          	jal	40016082 <putchar>
400155e6:	a001                	j	400155e6 <ecc_keygen_flow+0x2e4>
400155e8:	0691                	add	a3,a3,4
400155ea:	0405                	add	s0,s0,1
400155ec:	faf69ae3          	bne	a3,a5,400155a0 <ecc_keygen_flow+0x29e>
400155f0:	bd41                	j	40015480 <ecc_keygen_flow+0x17e>
400155f2:	10008737          	lui	a4,0x10008
400155f6:	efff86b7          	lui	a3,0xefff8
400155fa:	100087b7          	lui	a5,0x10008
400155fe:	4401                	li	s0,0
40015600:	28070713          	add	a4,a4,640 # 10008280 <mfdc+0x10007a87>
40015604:	d8468693          	add	a3,a3,-636 # efff7d84 <_tbs_der_store_end+0x9ffd8d64>
40015608:	2b078793          	add	a5,a5,688 # 100082b0 <mfdc+0x10007ab7>
4001560c:	00d70633          	add	a2,a4,a3
40015610:	9626                	add	a2,a2,s1
40015612:	00072903          	lw	s2,0(a4)
40015616:	4210                	lw	a2,0(a2)
40015618:	02c90e63          	beq	s2,a2,40015654 <ecc_keygen_flow+0x352>
4001561c:	50010537          	lui	a0,0x50010
40015620:	85a2                	mv	a1,s0
40015622:	36450513          	add	a0,a0,868 # 50010364 <__func__.1+0x114>
40015626:	265000ef          	jal	4001608a <printf>
4001562a:	50010537          	lui	a0,0x50010
4001562e:	85ca                	mv	a1,s2
40015630:	2cc50513          	add	a0,a0,716 # 500102cc <__func__.1+0x7c>
40015634:	257000ef          	jal	4001608a <printf>
40015638:	040a                	sll	s0,s0,0x2
4001563a:	008487b3          	add	a5,s1,s0
4001563e:	50010537          	lui	a0,0x50010
40015642:	43cc                	lw	a1,4(a5)
40015644:	2e450513          	add	a0,a0,740 # 500102e4 <__func__.1+0x94>
40015648:	243000ef          	jal	4001608a <printf>
4001564c:	4505                	li	a0,1
4001564e:	235000ef          	jal	40016082 <putchar>
40015652:	a001                	j	40015652 <ecc_keygen_flow+0x350>
40015654:	0711                	add	a4,a4,4
40015656:	0405                	add	s0,s0,1
40015658:	faf71ae3          	bne	a4,a5,4001560c <ecc_keygen_flow+0x30a>
4001565c:	b585                	j	400154bc <ecc_keygen_flow+0x1ba>

4001565e <ecc_signing_flow>:
4001565e:	1101                	add	sp,sp,-32
40015660:	ca26                	sw	s1,20(sp)
40015662:	84ba                	mv	s1,a4
40015664:	10008737          	lui	a4,0x10008
40015668:	cc22                	sw	s0,24(sp)
4001566a:	c84a                	sw	s2,16(sp)
4001566c:	c64e                	sw	s3,12(sp)
4001566e:	c452                	sw	s4,8(sp)
40015670:	ce06                	sw	ra,28(sp)
40015672:	842a                	mv	s0,a0
40015674:	8a2e                	mv	s4,a1
40015676:	89b2                	mv	s3,a2
40015678:	8936                	mv	s2,a3
4001567a:	0761                	add	a4,a4,24 # 10008018 <mfdc+0x1000781f>
4001567c:	431c                	lw	a5,0(a4)
4001567e:	8b85                	and	a5,a5,1
40015680:	dff5                	beqz	a5,4001567c <ecc_signing_flow+0x1e>
40015682:	100087b7          	lui	a5,0x10008
40015686:	00044703          	lbu	a4,0(s0)
4001568a:	58078793          	add	a5,a5,1408 # 10008580 <mfdc+0x10007d87>
4001568e:	e31d                	bnez	a4,400156b4 <ecc_signing_flow+0x56>
40015690:	efff8637          	lui	a2,0xefff8
40015694:	10008737          	lui	a4,0x10008
40015698:	a8060613          	add	a2,a2,-1408 # efff7a80 <_tbs_der_store_end+0x9ffd8a60>
4001569c:	5b070713          	add	a4,a4,1456 # 100085b0 <mfdc+0x10007db7>
400156a0:	85be                	mv	a1,a5
400156a2:	0791                	add	a5,a5,4
400156a4:	00c786b3          	add	a3,a5,a2
400156a8:	96a2                	add	a3,a3,s0
400156aa:	4294                	lw	a3,0(a3)
400156ac:	c194                	sw	a3,0(a1)
400156ae:	fee799e3          	bne	a5,a4,400156a0 <ecc_signing_flow+0x42>
400156b2:	a81d                	j	400156e8 <ecc_signing_flow+0x8a>
400156b4:	50010537          	lui	a0,0x50010
400156b8:	39450513          	add	a0,a0,916 # 50010394 <__func__.1+0x144>
400156bc:	1cd000ef          	jal	40016088 <puts>
400156c0:	00144783          	lbu	a5,1(s0)
400156c4:	0786                	sll	a5,a5,0x1
400156c6:	03e7f793          	and	a5,a5,62
400156ca:	0017e793          	or	a5,a5,1
400156ce:	0220000f          	fence	r,r
400156d2:	0220000f          	fence	r,r
400156d6:	10008737          	lui	a4,0x10008
400156da:	60f72023          	sw	a5,1536(a4) # 10008600 <mfdc+0x10007e07>
400156de:	60470713          	add	a4,a4,1540
400156e2:	431c                	lw	a5,0(a4)
400156e4:	8b89                	and	a5,a5,2
400156e6:	dff5                	beqz	a5,400156e2 <ecc_signing_flow+0x84>
400156e8:	100087b7          	lui	a5,0x10008
400156ec:	efff8637          	lui	a2,0xefff8
400156f0:	10008737          	lui	a4,0x10008
400156f4:	10078793          	add	a5,a5,256 # 10008100 <mfdc+0x10007907>
400156f8:	f0060613          	add	a2,a2,-256 # efff7f00 <_tbs_der_store_end+0x9ffd8ee0>
400156fc:	13070713          	add	a4,a4,304 # 10008130 <mfdc+0x10007937>
40015700:	85be                	mv	a1,a5
40015702:	0791                	add	a5,a5,4
40015704:	00c786b3          	add	a3,a5,a2
40015708:	96d2                	add	a3,a3,s4
4001570a:	4294                	lw	a3,0(a3)
4001570c:	c194                	sw	a3,0(a1)
4001570e:	fee799e3          	bne	a5,a4,40015700 <ecc_signing_flow+0xa2>
40015712:	100087b7          	lui	a5,0x10008
40015716:	efff8637          	lui	a2,0xefff8
4001571a:	10008737          	lui	a4,0x10008
4001571e:	48078793          	add	a5,a5,1152 # 10008480 <mfdc+0x10007c87>
40015722:	b8060613          	add	a2,a2,-1152 # efff7b80 <_tbs_der_store_end+0x9ffd8b60>
40015726:	4b070713          	add	a4,a4,1200 # 100084b0 <mfdc+0x10007cb7>
4001572a:	85be                	mv	a1,a5
4001572c:	0791                	add	a5,a5,4
4001572e:	00c786b3          	add	a3,a5,a2
40015732:	96ce                	add	a3,a3,s3
40015734:	4294                	lw	a3,0(a3)
40015736:	c194                	sw	a3,0(a1)
40015738:	fee799e3          	bne	a5,a4,4001572a <ecc_signing_flow+0xcc>
4001573c:	50010537          	lui	a0,0x50010
40015740:	3b450513          	add	a0,a0,948 # 500103b4 <__func__.1+0x164>
40015744:	145000ef          	jal	40016088 <puts>
40015748:	0220000f          	fence	r,r
4001574c:	0220000f          	fence	r,r
40015750:	100087b7          	lui	a5,0x10008
40015754:	4709                	li	a4,2
40015756:	cb98                	sw	a4,16(a5)
40015758:	01878713          	add	a4,a5,24 # 10008018 <mfdc+0x1000781f>
4001575c:	431c                	lw	a5,0(a4)
4001575e:	8b89                	and	a5,a5,2
40015760:	dff5                	beqz	a5,4001575c <ecc_signing_flow+0xfe>
40015762:	50010537          	lui	a0,0x50010
40015766:	3c450513          	add	a0,a0,964 # 500103c4 <__func__.1+0x174>
4001576a:	11f000ef          	jal	40016088 <puts>
4001576e:	00094783          	lbu	a5,0(s2)
40015772:	cbb5                	beqz	a5,400157e6 <ecc_signing_flow+0x188>
40015774:	100087b7          	lui	a5,0x10008
40015778:	efff8637          	lui	a2,0xefff8
4001577c:	10008737          	lui	a4,0x10008
40015780:	30078793          	add	a5,a5,768 # 10008300 <mfdc+0x10007b07>
40015784:	d0460613          	add	a2,a2,-764 # efff7d04 <_tbs_der_store_end+0x9ffd8ce4>
40015788:	33070713          	add	a4,a4,816 # 10008330 <mfdc+0x10007b37>
4001578c:	00c786b3          	add	a3,a5,a2
40015790:	438c                	lw	a1,0(a5)
40015792:	96ca                	add	a3,a3,s2
40015794:	c28c                	sw	a1,0(a3)
40015796:	0791                	add	a5,a5,4
40015798:	fee79ae3          	bne	a5,a4,4001578c <ecc_signing_flow+0x12e>
4001579c:	50010537          	lui	a0,0x50010
400157a0:	43c50513          	add	a0,a0,1084 # 5001043c <__func__.1+0x1ec>
400157a4:	0e5000ef          	jal	40016088 <puts>
400157a8:	0004c783          	lbu	a5,0(s1)
400157ac:	c3dd                	beqz	a5,40015852 <ecc_signing_flow+0x1f4>
400157ae:	100087b7          	lui	a5,0x10008
400157b2:	efff8637          	lui	a2,0xefff8
400157b6:	10008737          	lui	a4,0x10008
400157ba:	38078793          	add	a5,a5,896 # 10008380 <mfdc+0x10007b87>
400157be:	c8460613          	add	a2,a2,-892 # efff7c84 <_tbs_der_store_end+0x9ffd8c64>
400157c2:	3b070713          	add	a4,a4,944 # 100083b0 <mfdc+0x10007bb7>
400157c6:	00c786b3          	add	a3,a5,a2
400157ca:	438c                	lw	a1,0(a5)
400157cc:	96a6                	add	a3,a3,s1
400157ce:	c28c                	sw	a1,0(a3)
400157d0:	0791                	add	a5,a5,4
400157d2:	fee79ae3          	bne	a5,a4,400157c6 <ecc_signing_flow+0x168>
400157d6:	40f2                	lw	ra,28(sp)
400157d8:	4462                	lw	s0,24(sp)
400157da:	44d2                	lw	s1,20(sp)
400157dc:	4942                	lw	s2,16(sp)
400157de:	49b2                	lw	s3,12(sp)
400157e0:	4a22                	lw	s4,8(sp)
400157e2:	6105                	add	sp,sp,32
400157e4:	8082                	ret
400157e6:	100087b7          	lui	a5,0x10008
400157ea:	efff86b7          	lui	a3,0xefff8
400157ee:	10008737          	lui	a4,0x10008
400157f2:	4401                	li	s0,0
400157f4:	30078793          	add	a5,a5,768 # 10008300 <mfdc+0x10007b07>
400157f8:	d0468693          	add	a3,a3,-764 # efff7d04 <_tbs_der_store_end+0x9ffd8ce4>
400157fc:	33070713          	add	a4,a4,816 # 10008330 <mfdc+0x10007b37>
40015800:	00d78633          	add	a2,a5,a3
40015804:	964a                	add	a2,a2,s2
40015806:	0007a983          	lw	s3,0(a5)
4001580a:	4210                	lw	a2,0(a2)
4001580c:	02c98e63          	beq	s3,a2,40015848 <ecc_signing_flow+0x1ea>
40015810:	50010537          	lui	a0,0x50010
40015814:	85a2                	mv	a1,s0
40015816:	3e050513          	add	a0,a0,992 # 500103e0 <__func__.1+0x190>
4001581a:	071000ef          	jal	4001608a <printf>
4001581e:	50010537          	lui	a0,0x50010
40015822:	85ce                	mv	a1,s3
40015824:	40c50513          	add	a0,a0,1036 # 5001040c <__func__.1+0x1bc>
40015828:	063000ef          	jal	4001608a <printf>
4001582c:	040a                	sll	s0,s0,0x2
4001582e:	008906b3          	add	a3,s2,s0
40015832:	50010537          	lui	a0,0x50010
40015836:	42cc                	lw	a1,4(a3)
40015838:	42450513          	add	a0,a0,1060 # 50010424 <__func__.1+0x1d4>
4001583c:	04f000ef          	jal	4001608a <printf>
40015840:	4505                	li	a0,1
40015842:	041000ef          	jal	40016082 <putchar>
40015846:	a001                	j	40015846 <ecc_signing_flow+0x1e8>
40015848:	0791                	add	a5,a5,4
4001584a:	0405                	add	s0,s0,1
4001584c:	fae79ae3          	bne	a5,a4,40015800 <ecc_signing_flow+0x1a2>
40015850:	b7b1                	j	4001579c <ecc_signing_flow+0x13e>
40015852:	100087b7          	lui	a5,0x10008
40015856:	efff86b7          	lui	a3,0xefff8
4001585a:	10008737          	lui	a4,0x10008
4001585e:	4401                	li	s0,0
40015860:	38078793          	add	a5,a5,896 # 10008380 <mfdc+0x10007b87>
40015864:	c8468693          	add	a3,a3,-892 # efff7c84 <_tbs_der_store_end+0x9ffd8c64>
40015868:	3b070713          	add	a4,a4,944 # 100083b0 <mfdc+0x10007bb7>
4001586c:	00d78633          	add	a2,a5,a3
40015870:	9626                	add	a2,a2,s1
40015872:	0007a903          	lw	s2,0(a5)
40015876:	4210                	lw	a2,0(a2)
40015878:	02c90e63          	beq	s2,a2,400158b4 <ecc_signing_flow+0x256>
4001587c:	50010537          	lui	a0,0x50010
40015880:	85a2                	mv	a1,s0
40015882:	45850513          	add	a0,a0,1112 # 50010458 <__func__.1+0x208>
40015886:	005000ef          	jal	4001608a <printf>
4001588a:	50010537          	lui	a0,0x50010
4001588e:	85ca                	mv	a1,s2
40015890:	2cc50513          	add	a0,a0,716 # 500102cc <__func__.1+0x7c>
40015894:	7f6000ef          	jal	4001608a <printf>
40015898:	040a                	sll	s0,s0,0x2
4001589a:	00848733          	add	a4,s1,s0
4001589e:	50010537          	lui	a0,0x50010
400158a2:	434c                	lw	a1,4(a4)
400158a4:	2e450513          	add	a0,a0,740 # 500102e4 <__func__.1+0x94>
400158a8:	7e2000ef          	jal	4001608a <printf>
400158ac:	4505                	li	a0,1
400158ae:	7d4000ef          	jal	40016082 <putchar>
400158b2:	a001                	j	400158b2 <ecc_signing_flow+0x254>
400158b4:	0791                	add	a5,a5,4
400158b6:	0405                	add	s0,s0,1
400158b8:	fae79ae3          	bne	a5,a4,4001586c <ecc_signing_flow+0x20e>
400158bc:	bf29                	j	400157d6 <ecc_signing_flow+0x178>

400158be <ecc_verifying_flow>:
400158be:	1141                	add	sp,sp,-16
400158c0:	c422                	sw	s0,8(sp)
400158c2:	8436                	mv	s0,a3
400158c4:	100086b7          	lui	a3,0x10008
400158c8:	c606                	sw	ra,12(sp)
400158ca:	c226                	sw	s1,4(sp)
400158cc:	c04a                	sw	s2,0(sp)
400158ce:	06e1                	add	a3,a3,24 # 10008018 <mfdc+0x1000781f>
400158d0:	429c                	lw	a5,0(a3)
400158d2:	8b85                	and	a5,a5,1
400158d4:	dff5                	beqz	a5,400158d0 <ecc_verifying_flow+0x12>
400158d6:	100087b7          	lui	a5,0x10008
400158da:	100086b7          	lui	a3,0x10008
400158de:	10078793          	add	a5,a5,256 # 10008100 <mfdc+0x10007907>
400158e2:	13068693          	add	a3,a3,304 # 10008130 <mfdc+0x10007937>
400158e6:	883e                	mv	a6,a5
400158e8:	00452883          	lw	a7,4(a0)
400158ec:	0791                	add	a5,a5,4
400158ee:	01182023          	sw	a7,0(a6)
400158f2:	0511                	add	a0,a0,4
400158f4:	fed799e3          	bne	a5,a3,400158e6 <ecc_verifying_flow+0x28>
400158f8:	100087b7          	lui	a5,0x10008
400158fc:	100086b7          	lui	a3,0x10008
40015900:	20078793          	add	a5,a5,512 # 10008200 <mfdc+0x10007a07>
40015904:	23068693          	add	a3,a3,560 # 10008230 <mfdc+0x10007a37>
40015908:	853e                	mv	a0,a5
4001590a:	0045a803          	lw	a6,4(a1)
4001590e:	0791                	add	a5,a5,4
40015910:	01052023          	sw	a6,0(a0)
40015914:	0591                	add	a1,a1,4
40015916:	fed799e3          	bne	a5,a3,40015908 <ecc_verifying_flow+0x4a>
4001591a:	100087b7          	lui	a5,0x10008
4001591e:	100086b7          	lui	a3,0x10008
40015922:	28078793          	add	a5,a5,640 # 10008280 <mfdc+0x10007a87>
40015926:	2b068693          	add	a3,a3,688 # 100082b0 <mfdc+0x10007ab7>
4001592a:	85be                	mv	a1,a5
4001592c:	4248                	lw	a0,4(a2)
4001592e:	0791                	add	a5,a5,4
40015930:	c188                	sw	a0,0(a1)
40015932:	0611                	add	a2,a2,4
40015934:	fed79be3          	bne	a5,a3,4001592a <ecc_verifying_flow+0x6c>
40015938:	100087b7          	lui	a5,0x10008
4001593c:	100086b7          	lui	a3,0x10008
40015940:	8622                	mv	a2,s0
40015942:	30078793          	add	a5,a5,768 # 10008300 <mfdc+0x10007b07>
40015946:	33068693          	add	a3,a3,816 # 10008330 <mfdc+0x10007b37>
4001594a:	85be                	mv	a1,a5
4001594c:	4248                	lw	a0,4(a2)
4001594e:	0791                	add	a5,a5,4
40015950:	c188                	sw	a0,0(a1)
40015952:	0611                	add	a2,a2,4
40015954:	fed79be3          	bne	a5,a3,4001594a <ecc_verifying_flow+0x8c>
40015958:	100087b7          	lui	a5,0x10008
4001595c:	100086b7          	lui	a3,0x10008
40015960:	38078793          	add	a5,a5,896 # 10008380 <mfdc+0x10007b87>
40015964:	3b068693          	add	a3,a3,944 # 100083b0 <mfdc+0x10007bb7>
40015968:	863e                	mv	a2,a5
4001596a:	434c                	lw	a1,4(a4)
4001596c:	0791                	add	a5,a5,4
4001596e:	c20c                	sw	a1,0(a2)
40015970:	0711                	add	a4,a4,4
40015972:	fed79be3          	bne	a5,a3,40015968 <ecc_verifying_flow+0xaa>
40015976:	50010537          	lui	a0,0x50010
4001597a:	48450513          	add	a0,a0,1156 # 50010484 <__func__.1+0x234>
4001597e:	2729                	jal	40016088 <puts>
40015980:	0220000f          	fence	r,r
40015984:	0220000f          	fence	r,r
40015988:	100087b7          	lui	a5,0x10008
4001598c:	470d                	li	a4,3
4001598e:	cb98                	sw	a4,16(a5)
40015990:	00062837          	lui	a6,0x62
40015994:	30030737          	lui	a4,0x30030
40015998:	300308b7          	lui	a7,0x30030
4001599c:	3e900513          	li	a0,1001
400159a0:	01878593          	add	a1,a5,24 # 10008018 <mfdc+0x1000781f>
400159a4:	64070713          	add	a4,a4,1600 # 30030640 <mfdc+0x3002fe47>
400159a8:	a8080813          	add	a6,a6,-1408 # 61a80 <mfdc+0x61287>
400159ac:	64888893          	add	a7,a7,1608 # 30030648 <mfdc+0x3002fe4f>
400159b0:	419c                	lw	a5,0(a1)
400159b2:	8b89                	and	a5,a5,2
400159b4:	cfb1                	beqz	a5,40015a10 <ecc_verifying_flow+0x152>
400159b6:	50010537          	lui	a0,0x50010
400159ba:	49450513          	add	a0,a0,1172 # 50010494 <__func__.1+0x244>
400159be:	25e9                	jal	40016088 <puts>
400159c0:	100087b7          	lui	a5,0x10008
400159c4:	4581                	li	a1,0
400159c6:	40078793          	add	a5,a5,1024 # 10008400 <mfdc+0x10007c07>
400159ca:	46b1                	li	a3,12
400159cc:	00259713          	sll	a4,a1,0x2
400159d0:	973e                	add	a4,a4,a5
400159d2:	00072903          	lw	s2,0(a4)
400159d6:	4044                	lw	s1,4(s0)
400159d8:	06990763          	beq	s2,s1,40015a46 <ecc_verifying_flow+0x188>
400159dc:	50010537          	lui	a0,0x50010
400159e0:	4b050513          	add	a0,a0,1200 # 500104b0 <__func__.1+0x260>
400159e4:	255d                	jal	4001608a <printf>
400159e6:	50010537          	lui	a0,0x50010
400159ea:	85ca                	mv	a1,s2
400159ec:	4e050513          	add	a0,a0,1248 # 500104e0 <__func__.1+0x290>
400159f0:	2d69                	jal	4001608a <printf>
400159f2:	50010537          	lui	a0,0x50010
400159f6:	85a6                	mv	a1,s1
400159f8:	4f850513          	add	a0,a0,1272 # 500104f8 <__func__.1+0x2a8>
400159fc:	2579                	jal	4001608a <printf>
400159fe:	4505                	li	a0,1
40015a00:	2549                	jal	40016082 <putchar>
40015a02:	557d                	li	a0,-1
40015a04:	40b2                	lw	ra,12(sp)
40015a06:	4422                	lw	s0,8(sp)
40015a08:	4492                	lw	s1,4(sp)
40015a0a:	4902                	lw	s2,0(sp)
40015a0c:	0141                	add	sp,sp,16
40015a0e:	8082                	ret
40015a10:	157d                	add	a0,a0,-1
40015a12:	d965                	beqz	a0,40015a02 <ecc_verifying_flow+0x144>
40015a14:	4310                	lw	a2,0(a4)
40015a16:	01060333          	add	t1,a2,a6
40015a1a:	4354                	lw	a3,4(a4)
40015a1c:	00c337b3          	sltu	a5,t1,a2
40015a20:	97b6                	add	a5,a5,a3
40015a22:	0068a023          	sw	t1,0(a7)
40015a26:	861a                	mv	a2,t1
40015a28:	00f8a223          	sw	a5,4(a7)
40015a2c:	00072303          	lw	t1,0(a4)
40015a30:	00472383          	lw	t2,4(a4)
40015a34:	00f3e663          	bltu	t2,a5,40015a40 <ecc_verifying_flow+0x182>
40015a38:	f6779ce3          	bne	a5,t2,400159b0 <ecc_verifying_flow+0xf2>
40015a3c:	f6c37ae3          	bgeu	t1,a2,400159b0 <ecc_verifying_flow+0xf2>
40015a40:	10500073          	wfi
40015a44:	b7e5                	j	40015a2c <ecc_verifying_flow+0x16e>
40015a46:	0585                	add	a1,a1,1
40015a48:	0411                	add	s0,s0,4
40015a4a:	f8d591e3          	bne	a1,a3,400159cc <ecc_verifying_flow+0x10e>
40015a4e:	4501                	li	a0,0
40015a50:	bf55                	j	40015a04 <ecc_verifying_flow+0x146>

40015a52 <hmac_flow>:
40015a52:	1101                	add	sp,sp,-32
40015a54:	cc22                	sw	s0,24(sp)
40015a56:	ca26                	sw	s1,20(sp)
40015a58:	c84a                	sw	s2,16(sp)
40015a5a:	c64e                	sw	s3,12(sp)
40015a5c:	ce06                	sw	ra,28(sp)
40015a5e:	c452                	sw	s4,8(sp)
40015a60:	10010737          	lui	a4,0x10010
40015a64:	892a                	mv	s2,a0
40015a66:	84ae                	mv	s1,a1
40015a68:	89b2                	mv	s3,a2
40015a6a:	8436                	mv	s0,a3
40015a6c:	0006ca03          	lbu	s4,0(a3)
40015a70:	0761                	add	a4,a4,24 # 10010018 <mfdc+0x1000f81f>
40015a72:	431c                	lw	a5,0(a4)
40015a74:	8b85                	and	a5,a5,1
40015a76:	dff5                	beqz	a5,40015a72 <hmac_flow+0x20>
40015a78:	00094783          	lbu	a5,0(s2)
40015a7c:	cff9                	beqz	a5,40015b5a <hmac_flow+0x108>
40015a7e:	00194783          	lbu	a5,1(s2)
40015a82:	0786                	sll	a5,a5,0x1
40015a84:	03e7f793          	and	a5,a5,62
40015a88:	0017e793          	or	a5,a5,1
40015a8c:	0220000f          	fence	r,r
40015a90:	0220000f          	fence	r,r
40015a94:	10010737          	lui	a4,0x10010
40015a98:	60f72023          	sw	a5,1536(a4) # 10010600 <mfdc+0x1000fe07>
40015a9c:	60470713          	add	a4,a4,1540
40015aa0:	431c                	lw	a5,0(a4)
40015aa2:	8b89                	and	a5,a5,2
40015aa4:	dff5                	beqz	a5,40015aa0 <hmac_flow+0x4e>
40015aa6:	0004c783          	lbu	a5,0(s1)
40015aaa:	cff1                	beqz	a5,40015b86 <hmac_flow+0x134>
40015aac:	0014c783          	lbu	a5,1(s1)
40015ab0:	0786                	sll	a5,a5,0x1
40015ab2:	03e7f793          	and	a5,a5,62
40015ab6:	0017e793          	or	a5,a5,1
40015aba:	0220000f          	fence	r,r
40015abe:	0220000f          	fence	r,r
40015ac2:	10010737          	lui	a4,0x10010
40015ac6:	60f72423          	sw	a5,1544(a4) # 10010608 <mfdc+0x1000fe0f>
40015aca:	60c70713          	add	a4,a4,1548
40015ace:	431c                	lw	a5,0(a4)
40015ad0:	8b89                	and	a5,a5,2
40015ad2:	dff5                	beqz	a5,40015ace <hmac_flow+0x7c>
40015ad4:	0049a703          	lw	a4,4(s3)
40015ad8:	100107b7          	lui	a5,0x10010
40015adc:	12e7a823          	sw	a4,304(a5) # 10010130 <mfdc+0x1000f937>
40015ae0:	0089a703          	lw	a4,8(s3)
40015ae4:	13478793          	add	a5,a5,308
40015ae8:	c398                	sw	a4,0(a5)
40015aea:	00c9a703          	lw	a4,12(s3)
40015aee:	c3d8                	sw	a4,4(a5)
40015af0:	0109a703          	lw	a4,16(s3)
40015af4:	c798                	sw	a4,8(a5)
40015af6:	0149a703          	lw	a4,20(s3)
40015afa:	c7d8                	sw	a4,12(a5)
40015afc:	020a0163          	beqz	s4,40015b1e <hmac_flow+0xcc>
40015b00:	00144783          	lbu	a5,1(s0)
40015b04:	0786                	sll	a5,a5,0x1
40015b06:	0ff7f793          	zext.b	a5,a5
40015b0a:	7c17e793          	or	a5,a5,1985
40015b0e:	0220000f          	fence	r,r
40015b12:	0220000f          	fence	r,r
40015b16:	10010737          	lui	a4,0x10010
40015b1a:	60f72823          	sw	a5,1552(a4) # 10010610 <mfdc+0x1000fe17>
40015b1e:	0220000f          	fence	r,r
40015b22:	0220000f          	fence	r,r
40015b26:	100107b7          	lui	a5,0x10010
40015b2a:	4705                	li	a4,1
40015b2c:	cb98                	sw	a4,16(a5)
40015b2e:	060a0c63          	beqz	s4,40015ba6 <hmac_flow+0x154>
40015b32:	50010537          	lui	a0,0x50010
40015b36:	53850513          	add	a0,a0,1336 # 50010538 <__func__.0+0x28>
40015b3a:	23b9                	jal	40016088 <puts>
40015b3c:	10010737          	lui	a4,0x10010
40015b40:	61470713          	add	a4,a4,1556 # 10010614 <mfdc+0x1000fe1b>
40015b44:	431c                	lw	a5,0(a4)
40015b46:	8b89                	and	a5,a5,2
40015b48:	dff5                	beqz	a5,40015b44 <hmac_flow+0xf2>
40015b4a:	40f2                	lw	ra,28(sp)
40015b4c:	4462                	lw	s0,24(sp)
40015b4e:	44d2                	lw	s1,20(sp)
40015b50:	4942                	lw	s2,16(sp)
40015b52:	49b2                	lw	s3,12(sp)
40015b54:	4a22                	lw	s4,8(sp)
40015b56:	6105                	add	sp,sp,32
40015b58:	8082                	ret
40015b5a:	50010537          	lui	a0,0x50010
40015b5e:	52050513          	add	a0,a0,1312 # 50010520 <__func__.0+0x10>
40015b62:	231d                	jal	40016088 <puts>
40015b64:	100107b7          	lui	a5,0x10010
40015b68:	10010737          	lui	a4,0x10010
40015b6c:	04078793          	add	a5,a5,64 # 10010040 <mfdc+0x1000f847>
40015b70:	07070713          	add	a4,a4,112 # 10010070 <mfdc+0x1000f877>
40015b74:	86be                	mv	a3,a5
40015b76:	00492603          	lw	a2,4(s2)
40015b7a:	0791                	add	a5,a5,4
40015b7c:	c290                	sw	a2,0(a3)
40015b7e:	0911                	add	s2,s2,4
40015b80:	fee79ae3          	bne	a5,a4,40015b74 <hmac_flow+0x122>
40015b84:	b70d                	j	40015aa6 <hmac_flow+0x54>
40015b86:	100107b7          	lui	a5,0x10010
40015b8a:	10010737          	lui	a4,0x10010
40015b8e:	08078793          	add	a5,a5,128 # 10010080 <mfdc+0x1000f887>
40015b92:	10070713          	add	a4,a4,256 # 10010100 <mfdc+0x1000f907>
40015b96:	86be                	mv	a3,a5
40015b98:	40d0                	lw	a2,4(s1)
40015b9a:	0791                	add	a5,a5,4
40015b9c:	c290                	sw	a2,0(a3)
40015b9e:	0491                	add	s1,s1,4
40015ba0:	fee79be3          	bne	a5,a4,40015b96 <hmac_flow+0x144>
40015ba4:	bf05                	j	40015ad4 <hmac_flow+0x82>
40015ba6:	50010537          	lui	a0,0x50010
40015baa:	55850513          	add	a0,a0,1368 # 50010558 <__func__.0+0x48>
40015bae:	29e9                	jal	40016088 <puts>
40015bb0:	100107b7          	lui	a5,0x10010
40015bb4:	4581                	li	a1,0
40015bb6:	10078793          	add	a5,a5,256 # 10010100 <mfdc+0x1000f907>
40015bba:	46b1                	li	a3,12
40015bbc:	00259713          	sll	a4,a1,0x2
40015bc0:	973e                	add	a4,a4,a5
40015bc2:	00072903          	lw	s2,0(a4)
40015bc6:	4044                	lw	s1,4(s0)
40015bc8:	02990663          	beq	s2,s1,40015bf4 <hmac_flow+0x1a2>
40015bcc:	50010537          	lui	a0,0x50010
40015bd0:	57050513          	add	a0,a0,1392 # 50010570 <__func__.0+0x60>
40015bd4:	295d                	jal	4001608a <printf>
40015bd6:	50010537          	lui	a0,0x50010
40015bda:	85ca                	mv	a1,s2
40015bdc:	2cc50513          	add	a0,a0,716 # 500102cc <__func__.1+0x7c>
40015be0:	216d                	jal	4001608a <printf>
40015be2:	50010537          	lui	a0,0x50010
40015be6:	85a6                	mv	a1,s1
40015be8:	2e450513          	add	a0,a0,740 # 500102e4 <__func__.1+0x94>
40015bec:	2979                	jal	4001608a <printf>
40015bee:	4505                	li	a0,1
40015bf0:	2949                	jal	40016082 <putchar>
40015bf2:	a001                	j	40015bf2 <hmac_flow+0x1a0>
40015bf4:	0585                	add	a1,a1,1
40015bf6:	0411                	add	s0,s0,4
40015bf8:	fcd592e3          	bne	a1,a3,40015bbc <hmac_flow+0x16a>
40015bfc:	b7b9                	j	40015b4a <hmac_flow+0xf8>

40015bfe <mailbox_send_data>:
40015bfe:	7179                	add	sp,sp,-48
40015c00:	d04a                	sw	s2,32(sp)
40015c02:	892a                	mv	s2,a0
40015c04:	10000537          	lui	a0,0x10000
40015c08:	d606                	sw	ra,44(sp)
40015c0a:	d226                	sw	s1,36(sp)
40015c0c:	d422                	sw	s0,40(sp)
40015c0e:	84ae                	mv	s1,a1
40015c10:	ce4e                	sw	s3,28(sp)
40015c12:	cc52                	sw	s4,24(sp)
40015c14:	ca56                	sw	s5,20(sp)
40015c16:	135010ef          	jal	4001754a <soc_ifc_set_flow_status_field>
40015c1a:	50010537          	lui	a0,0x50010
40015c1e:	59c50513          	add	a0,a0,1436 # 5001059c <__func__.0+0x8c>
40015c22:	219d                	jal	40016088 <puts>
40015c24:	30020737          	lui	a4,0x30020
40015c28:	0761                	add	a4,a4,24 # 30020018 <mfdc+0x3001f81f>
40015c2a:	431c                	lw	a5,0(a4)
40015c2c:	8b85                	and	a5,a5,1
40015c2e:	dff5                	beqz	a5,40015c2a <mailbox_send_data+0x2c>
40015c30:	161010ef          	jal	40017590 <soc_ifc_read_mbox_cmd>
40015c34:	c42a                	sw	a0,8(sp)
40015c36:	c62e                	sw	a1,12(sp)
40015c38:	842a                	mv	s0,a0
40015c3a:	85aa                	mv	a1,a0
40015c3c:	50010537          	lui	a0,0x50010
40015c40:	5a850513          	add	a0,a0,1448 # 500105a8 <__func__.0+0x98>
40015c44:	300209b7          	lui	s3,0x30020
40015c48:	2189                	jal	4001608a <printf>
40015c4a:	09d1                	add	s3,s3,20 # 30020014 <mfdc+0x3001f81b>
40015c4c:	50010a37          	lui	s4,0x50010
40015c50:	4a91                	li	s5,4
40015c52:	e049                	bnez	s0,40015cd4 <mailbox_send_data+0xd6>
40015c54:	0220000f          	fence	r,r
40015c58:	0220000f          	fence	r,r
40015c5c:	1a2b47b7          	lui	a5,0x1a2b4
40015c60:	30020737          	lui	a4,0x30020
40015c64:	c4d78793          	add	a5,a5,-947 # 1a2b3c4d <mfdc+0x1a2b3454>
40015c68:	c71c                	sw	a5,8(a4)
40015c6a:	0220000f          	fence	r,r
40015c6e:	0220000f          	fence	r,r
40015c72:	50010537          	lui	a0,0x50010
40015c76:	c744                	sw	s1,12(a4)
40015c78:	85a6                	mv	a1,s1
40015c7a:	5e450513          	add	a0,a0,1508 # 500105e4 <__func__.0+0xd4>
40015c7e:	2131                	jal	4001608a <printf>
40015c80:	300206b7          	lui	a3,0x30020
40015c84:	4781                	li	a5,0
40015c86:	4811                	li	a6,4
40015c88:	06c1                	add	a3,a3,16 # 30020010 <mfdc+0x3001f817>
40015c8a:	0497ef63          	bltu	a5,s1,40015ce8 <mailbox_send_data+0xea>
40015c8e:	50010537          	lui	a0,0x50010
40015c92:	60c50513          	add	a0,a0,1548 # 5001060c <__func__.0+0xfc>
40015c96:	2ecd                	jal	40016088 <puts>
40015c98:	0220000f          	fence	r,r
40015c9c:	0220000f          	fence	r,r
40015ca0:	300207b7          	lui	a5,0x30020
40015ca4:	4705                	li	a4,1
40015ca6:	cfd8                	sw	a4,28(a5)
40015ca8:	4fcc                	lw	a1,28(a5)
40015caa:	8199                	srl	a1,a1,0x6
40015cac:	899d                	and	a1,a1,7
40015cae:	4611                	li	a2,4
40015cb0:	06c58863          	beq	a1,a2,40015d20 <mailbox_send_data+0x122>
40015cb4:	50010537          	lui	a0,0x50010
40015cb8:	62850513          	add	a0,a0,1576 # 50010628 <__func__.0+0x118>
40015cbc:	26f9                	jal	4001608a <printf>
40015cbe:	547d                	li	s0,-1
40015cc0:	8522                	mv	a0,s0
40015cc2:	50b2                	lw	ra,44(sp)
40015cc4:	5422                	lw	s0,40(sp)
40015cc6:	5492                	lw	s1,36(sp)
40015cc8:	5902                	lw	s2,32(sp)
40015cca:	49f2                	lw	s3,28(sp)
40015ccc:	4a62                	lw	s4,24(sp)
40015cce:	4ad2                	lw	s5,20(sp)
40015cd0:	6145                	add	sp,sp,48
40015cd2:	8082                	ret
40015cd4:	0009a583          	lw	a1,0(s3)
40015cd8:	5d0a0513          	add	a0,s4,1488 # 500105d0 <__func__.0+0xc0>
40015cdc:	267d                	jal	4001608a <printf>
40015cde:	01547363          	bgeu	s0,s5,40015ce4 <mailbox_send_data+0xe6>
40015ce2:	4411                	li	s0,4
40015ce4:	1471                	add	s0,s0,-4
40015ce6:	b7b5                	j	40015c52 <mailbox_send_data+0x54>
40015ce8:	40f485b3          	sub	a1,s1,a5
40015cec:	00b87363          	bgeu	a6,a1,40015cf2 <mailbox_send_data+0xf4>
40015cf0:	4591                	li	a1,4
40015cf2:	4701                	li	a4,0
40015cf4:	4601                	li	a2,0
40015cf6:	00f90333          	add	t1,s2,a5
40015cfa:	00e30533          	add	a0,t1,a4
40015cfe:	00371893          	sll	a7,a4,0x3
40015d02:	00054503          	lbu	a0,0(a0)
40015d06:	01151533          	sll	a0,a0,a7
40015d0a:	0705                	add	a4,a4,1 # 30020001 <mfdc+0x3001f808>
40015d0c:	8e49                	or	a2,a2,a0
40015d0e:	fee596e3          	bne	a1,a4,40015cfa <mailbox_send_data+0xfc>
40015d12:	0220000f          	fence	r,r
40015d16:	0220000f          	fence	r,r
40015d1a:	c290                	sw	a2,0(a3)
40015d1c:	0791                	add	a5,a5,4 # 30020004 <mfdc+0x3001f80b>
40015d1e:	b7b5                	j	40015c8a <mailbox_send_data+0x8c>
40015d20:	50010537          	lui	a0,0x50010
40015d24:	67c50513          	add	a0,a0,1660 # 5001067c <__func__.0+0x16c>
40015d28:	2685                	jal	40016088 <puts>
40015d2a:	bf59                	j	40015cc0 <mailbox_send_data+0xc2>

40015d2c <whisperPutc>:
40015d2c:	1141                	add	sp,sp,-16
40015d2e:	c422                	sw	s0,8(sp)
40015d30:	c606                	sw	ra,12(sp)
40015d32:	47a9                	li	a5,10
40015d34:	842a                	mv	s0,a0
40015d36:	00f51663          	bne	a0,a5,40015d42 <whisperPutc+0x16>
40015d3a:	4535                	li	a0,13
40015d3c:	063010ef          	jal	4001759e <uart_tx>
40015d40:	8522                	mv	a0,s0
40015d42:	05d010ef          	jal	4001759e <uart_tx>
40015d46:	8522                	mv	a0,s0
40015d48:	40b2                	lw	ra,12(sp)
40015d4a:	4422                	lw	s0,8(sp)
40015d4c:	0141                	add	sp,sp,16
40015d4e:	8082                	ret

40015d50 <whisperPuts>:
40015d50:	1141                	add	sp,sp,-16
40015d52:	c422                	sw	s0,8(sp)
40015d54:	c606                	sw	ra,12(sp)
40015d56:	842a                	mv	s0,a0
40015d58:	00044503          	lbu	a0,0(s0)
40015d5c:	e901                	bnez	a0,40015d6c <whisperPuts+0x1c>
40015d5e:	4529                	li	a0,10
40015d60:	37f1                	jal	40015d2c <whisperPutc>
40015d62:	40b2                	lw	ra,12(sp)
40015d64:	4422                	lw	s0,8(sp)
40015d66:	4505                	li	a0,1
40015d68:	0141                	add	sp,sp,16
40015d6a:	8082                	ret
40015d6c:	0405                	add	s0,s0,1
40015d6e:	3f7d                	jal	40015d2c <whisperPutc>
40015d70:	b7e5                	j	40015d58 <whisperPuts+0x8>

40015d72 <whisperPrintUnsigned>:
40015d72:	7139                	add	sp,sp,-64
40015d74:	da26                	sw	s1,52(sp)
40015d76:	d64e                	sw	s3,44(sp)
40015d78:	de06                	sw	ra,60(sp)
40015d7a:	dc22                	sw	s0,56(sp)
40015d7c:	d84a                	sw	s2,48(sp)
40015d7e:	84ae                	mv	s1,a1
40015d80:	89b2                	mv	s3,a2
40015d82:	ed15                	bnez	a0,40015dbe <whisperPrintUnsigned+0x4c>
40015d84:	03000793          	li	a5,48
40015d88:	00f10623          	sb	a5,12(sp)
40015d8c:	4405                	li	s0,1
40015d8e:	8922                	mv	s2,s0
40015d90:	04994963          	blt	s2,s1,40015de2 <whisperPrintUnsigned+0x70>
40015d94:	02040793          	add	a5,s0,32
40015d98:	002784b3          	add	s1,a5,sp
40015d9c:	14ad                	add	s1,s1,-21
40015d9e:	40848933          	sub	s2,s1,s0
40015da2:	0004c503          	lbu	a0,0(s1)
40015da6:	14fd                	add	s1,s1,-1
40015da8:	3751                	jal	40015d2c <whisperPutc>
40015daa:	fe991ce3          	bne	s2,s1,40015da2 <whisperPrintUnsigned+0x30>
40015dae:	8522                	mv	a0,s0
40015db0:	50f2                	lw	ra,60(sp)
40015db2:	5462                	lw	s0,56(sp)
40015db4:	54d2                	lw	s1,52(sp)
40015db6:	5942                	lw	s2,48(sp)
40015db8:	59b2                	lw	s3,44(sp)
40015dba:	6121                	add	sp,sp,64
40015dbc:	8082                	ret
40015dbe:	007c                	add	a5,sp,12
40015dc0:	4401                	li	s0,0
40015dc2:	46a9                	li	a3,10
40015dc4:	4625                	li	a2,9
40015dc6:	02d57733          	remu	a4,a0,a3
40015dca:	85aa                	mv	a1,a0
40015dcc:	0405                	add	s0,s0,1
40015dce:	0785                	add	a5,a5,1
40015dd0:	03070713          	add	a4,a4,48
40015dd4:	fee78fa3          	sb	a4,-1(a5)
40015dd8:	02d55533          	divu	a0,a0,a3
40015ddc:	feb665e3          	bltu	a2,a1,40015dc6 <whisperPrintUnsigned+0x54>
40015de0:	b77d                	j	40015d8e <whisperPrintUnsigned+0x1c>
40015de2:	854e                	mv	a0,s3
40015de4:	37a1                	jal	40015d2c <whisperPutc>
40015de6:	0905                	add	s2,s2,1
40015de8:	b765                	j	40015d90 <whisperPrintUnsigned+0x1e>

40015dea <whisperPrintDecimal>:
40015dea:	7139                	add	sp,sp,-64
40015dec:	da26                	sw	s1,52(sp)
40015dee:	d452                	sw	s4,40(sp)
40015df0:	de06                	sw	ra,60(sp)
40015df2:	dc22                	sw	s0,56(sp)
40015df4:	d84a                	sw	s2,48(sp)
40015df6:	d64e                	sw	s3,44(sp)
40015df8:	84ae                	mv	s1,a1
40015dfa:	8a32                	mv	s4,a2
40015dfc:	02055c63          	bgez	a0,40015e34 <whisperPrintDecimal+0x4a>
40015e00:	40a00533          	neg	a0,a0
40015e04:	fff58493          	add	s1,a1,-1
40015e08:	4905                	li	s2,1
40015e0a:	007c                	add	a5,sp,12
40015e0c:	4401                	li	s0,0
40015e0e:	46a9                	li	a3,10
40015e10:	02d56733          	rem	a4,a0,a3
40015e14:	0405                	add	s0,s0,1
40015e16:	0785                	add	a5,a5,1
40015e18:	02d54533          	div	a0,a0,a3
40015e1c:	03070713          	add	a4,a4,48
40015e20:	fee78fa3          	sb	a4,-1(a5)
40015e24:	f575                	bnez	a0,40015e10 <whisperPrintDecimal+0x26>
40015e26:	00090e63          	beqz	s2,40015e42 <whisperPrintDecimal+0x58>
40015e2a:	02d00513          	li	a0,45
40015e2e:	770010ef          	jal	4001759e <uart_tx>
40015e32:	a801                	j	40015e42 <whisperPrintDecimal+0x58>
40015e34:	e129                	bnez	a0,40015e76 <whisperPrintDecimal+0x8c>
40015e36:	03000793          	li	a5,48
40015e3a:	00f10623          	sb	a5,12(sp)
40015e3e:	4901                	li	s2,0
40015e40:	4405                	li	s0,1
40015e42:	89a2                	mv	s3,s0
40015e44:	0299cb63          	blt	s3,s1,40015e7a <whisperPrintDecimal+0x90>
40015e48:	02040793          	add	a5,s0,32
40015e4c:	002784b3          	add	s1,a5,sp
40015e50:	14ad                	add	s1,s1,-21
40015e52:	408489b3          	sub	s3,s1,s0
40015e56:	0004c503          	lbu	a0,0(s1)
40015e5a:	14fd                	add	s1,s1,-1
40015e5c:	3dc1                	jal	40015d2c <whisperPutc>
40015e5e:	fe999ce3          	bne	s3,s1,40015e56 <whisperPrintDecimal+0x6c>
40015e62:	01240533          	add	a0,s0,s2
40015e66:	50f2                	lw	ra,60(sp)
40015e68:	5462                	lw	s0,56(sp)
40015e6a:	54d2                	lw	s1,52(sp)
40015e6c:	5942                	lw	s2,48(sp)
40015e6e:	59b2                	lw	s3,44(sp)
40015e70:	5a22                	lw	s4,40(sp)
40015e72:	6121                	add	sp,sp,64
40015e74:	8082                	ret
40015e76:	4901                	li	s2,0
40015e78:	bf49                	j	40015e0a <whisperPrintDecimal+0x20>
40015e7a:	8552                	mv	a0,s4
40015e7c:	3d45                	jal	40015d2c <whisperPutc>
40015e7e:	0985                	add	s3,s3,1
40015e80:	b7d1                	j	40015e44 <whisperPrintDecimal+0x5a>

40015e82 <whisperPrintInt>:
40015e82:	47a9                	li	a5,10
40015e84:	00f69563          	bne	a3,a5,40015e8e <whisperPrintInt+0xc>
40015e88:	0ff67613          	zext.b	a2,a2
40015e8c:	bfb9                	j	40015dea <whisperPrintDecimal>
40015e8e:	1101                	add	sp,sp,-32
40015e90:	c84a                	sw	s2,16(sp)
40015e92:	ce06                	sw	ra,28(sp)
40015e94:	cc22                	sw	s0,24(sp)
40015e96:	ca26                	sw	s1,20(sp)
40015e98:	c64e                	sw	s3,12(sp)
40015e9a:	c452                	sw	s4,8(sp)
40015e9c:	47a1                	li	a5,8
40015e9e:	892a                	mv	s2,a0
40015ea0:	02f69f63          	bne	a3,a5,40015ede <whisperPrintInt+0x5c>
40015ea4:	44f9                	li	s1,30
40015ea6:	4781                	li	a5,0
40015ea8:	4401                	li	s0,0
40015eaa:	0fd00993          	li	s3,253
40015eae:	00995533          	srl	a0,s2,s1
40015eb2:	891d                	and	a0,a0,7
40015eb4:	e111                	bnez	a0,40015eb8 <whisperPrintInt+0x36>
40015eb6:	c791                	beqz	a5,40015ec2 <whisperPrintInt+0x40>
40015eb8:	03050513          	add	a0,a0,48
40015ebc:	3d85                	jal	40015d2c <whisperPutc>
40015ebe:	0405                	add	s0,s0,1
40015ec0:	4785                	li	a5,1
40015ec2:	14f5                	add	s1,s1,-3
40015ec4:	0ff4f493          	zext.b	s1,s1
40015ec8:	ff3493e3          	bne	s1,s3,40015eae <whisperPrintInt+0x2c>
40015ecc:	8522                	mv	a0,s0
40015ece:	40f2                	lw	ra,28(sp)
40015ed0:	4462                	lw	s0,24(sp)
40015ed2:	44d2                	lw	s1,20(sp)
40015ed4:	4942                	lw	s2,16(sp)
40015ed6:	49b2                	lw	s3,12(sp)
40015ed8:	4a22                	lw	s4,8(sp)
40015eda:	6105                	add	sp,sp,32
40015edc:	8082                	ret
40015ede:	47c1                	li	a5,16
40015ee0:	547d                	li	s0,-1
40015ee2:	fef695e3          	bne	a3,a5,40015ecc <whisperPrintInt+0x4a>
40015ee6:	44f1                	li	s1,28
40015ee8:	4701                	li	a4,0
40015eea:	4401                	li	s0,0
40015eec:	4a25                	li	s4,9
40015eee:	0fc00993          	li	s3,252
40015ef2:	009957b3          	srl	a5,s2,s1
40015ef6:	8bbd                	and	a5,a5,15
40015ef8:	e791                	bnez	a5,40015f04 <whisperPrintInt+0x82>
40015efa:	e311                	bnez	a4,40015efe <whisperPrintInt+0x7c>
40015efc:	e899                	bnez	s1,40015f12 <whisperPrintInt+0x90>
40015efe:	03078513          	add	a0,a5,48
40015f02:	a029                	j	40015f0c <whisperPrintInt+0x8a>
40015f04:	03778513          	add	a0,a5,55
40015f08:	fefa7be3          	bgeu	s4,a5,40015efe <whisperPrintInt+0x7c>
40015f0c:	3505                	jal	40015d2c <whisperPutc>
40015f0e:	0405                	add	s0,s0,1
40015f10:	4705                	li	a4,1
40015f12:	14f1                	add	s1,s1,-4
40015f14:	0ff4f493          	zext.b	s1,s1
40015f18:	fd349de3          	bne	s1,s3,40015ef2 <whisperPrintInt+0x70>
40015f1c:	bf45                	j	40015ecc <whisperPrintInt+0x4a>

40015f1e <whisperPrintfImpl>:
40015f1e:	7179                	add	sp,sp,-48
40015f20:	d422                	sw	s0,40(sp)
40015f22:	d226                	sw	s1,36(sp)
40015f24:	d04a                	sw	s2,32(sp)
40015f26:	ce4e                	sw	s3,28(sp)
40015f28:	cc52                	sw	s4,24(sp)
40015f2a:	ca56                	sw	s5,20(sp)
40015f2c:	c85a                	sw	s6,16(sp)
40015f2e:	c65e                	sw	s7,12(sp)
40015f30:	c462                	sw	s8,8(sp)
40015f32:	d606                	sw	ra,44(sp)
40015f34:	c266                	sw	s9,4(sp)
40015f36:	c06a                	sw	s10,0(sp)
40015f38:	842a                	mv	s0,a0
40015f3a:	84ae                	mv	s1,a1
40015f3c:	4901                	li	s2,0
40015f3e:	02500993          	li	s3,37
40015f42:	03000a93          	li	s5,48
40015f46:	02d00b13          	li	s6,45
40015f4a:	02a00b93          	li	s7,42
40015f4e:	06f00a13          	li	s4,111
40015f52:	07500c13          	li	s8,117
40015f56:	00044503          	lbu	a0,0(s0)
40015f5a:	e105                	bnez	a0,40015f7a <whisperPrintfImpl+0x5c>
40015f5c:	50b2                	lw	ra,44(sp)
40015f5e:	5422                	lw	s0,40(sp)
40015f60:	854a                	mv	a0,s2
40015f62:	5492                	lw	s1,36(sp)
40015f64:	5902                	lw	s2,32(sp)
40015f66:	49f2                	lw	s3,28(sp)
40015f68:	4a62                	lw	s4,24(sp)
40015f6a:	4ad2                	lw	s5,20(sp)
40015f6c:	4b42                	lw	s6,16(sp)
40015f6e:	4bb2                	lw	s7,12(sp)
40015f70:	4c22                	lw	s8,8(sp)
40015f72:	4c92                	lw	s9,4(sp)
40015f74:	4d02                	lw	s10,0(sp)
40015f76:	6145                	add	sp,sp,48
40015f78:	8082                	ret
40015f7a:	01350663          	beq	a0,s3,40015f86 <whisperPrintfImpl+0x68>
40015f7e:	337d                	jal	40015d2c <whisperPutc>
40015f80:	0905                	add	s2,s2,1
40015f82:	0405                	add	s0,s0,1
40015f84:	bfc9                	j	40015f56 <whisperPrintfImpl+0x38>
40015f86:	00144703          	lbu	a4,1(s0)
40015f8a:	db69                	beqz	a4,40015f5c <whisperPrintfImpl+0x3e>
40015f8c:	0405                	add	s0,s0,1
40015f8e:	02000793          	li	a5,32
40015f92:	01371663          	bne	a4,s3,40015f9e <whisperPrintfImpl+0x80>
40015f96:	854e                	mv	a0,s3
40015f98:	606010ef          	jal	4001759e <uart_tx>
40015f9c:	b7dd                	j	40015f82 <whisperPrintfImpl+0x64>
40015f9e:	863e                	mv	a2,a5
40015fa0:	00044783          	lbu	a5,0(s0)
40015fa4:	8722                	mv	a4,s0
40015fa6:	0405                	add	s0,s0,1
40015fa8:	ff578be3          	beq	a5,s5,40015f9e <whisperPrintfImpl+0x80>
40015fac:	01678363          	beq	a5,s6,40015fb2 <whisperPrintfImpl+0x94>
40015fb0:	843a                	mv	s0,a4
40015fb2:	00044783          	lbu	a5,0(s0)
40015fb6:	03779c63          	bne	a5,s7,40015fee <whisperPrintfImpl+0xd0>
40015fba:	0405                	add	s0,s0,1
40015fbc:	4581                	li	a1,0
40015fbe:	00044783          	lbu	a5,0(s0)
40015fc2:	0b478263          	beq	a5,s4,40016066 <whisperPrintfImpl+0x148>
40015fc6:	04fa6d63          	bltu	s4,a5,40016020 <whisperPrintfImpl+0x102>
40015fca:	06300713          	li	a4,99
40015fce:	0ae78063          	beq	a5,a4,4001606e <whisperPrintfImpl+0x150>
40015fd2:	06400713          	li	a4,100
40015fd6:	06e78c63          	beq	a5,a4,4001604e <whisperPrintfImpl+0x130>
40015fda:	05800713          	li	a4,88
40015fde:	fae792e3          	bne	a5,a4,40015f82 <whisperPrintfImpl+0x64>
40015fe2:	00448c93          	add	s9,s1,4
40015fe6:	46c1                	li	a3,16
40015fe8:	4088                	lw	a0,0(s1)
40015fea:	3d61                	jal	40015e82 <whisperPrintInt>
40015fec:	a0ad                	j	40016056 <whisperPrintfImpl+0x138>
40015fee:	fd078793          	add	a5,a5,-48
40015ff2:	0ff7f793          	zext.b	a5,a5
40015ff6:	4725                	li	a4,9
40015ff8:	4581                	li	a1,0
40015ffa:	fcf762e3          	bltu	a4,a5,40015fbe <whisperPrintfImpl+0xa0>
40015ffe:	4829                	li	a6,10
40016000:	a029                	j	4001600a <whisperPrintfImpl+0xec>
40016002:	030585b3          	mul	a1,a1,a6
40016006:	842a                	mv	s0,a0
40016008:	95be                	add	a1,a1,a5
4001600a:	00044783          	lbu	a5,0(s0)
4001600e:	fd078793          	add	a5,a5,-48
40016012:	0ff7f693          	zext.b	a3,a5
40016016:	00140513          	add	a0,s0,1
4001601a:	fed774e3          	bgeu	a4,a3,40016002 <whisperPrintfImpl+0xe4>
4001601e:	b745                	j	40015fbe <whisperPrintfImpl+0xa0>
40016020:	03878e63          	beq	a5,s8,4001605c <whisperPrintfImpl+0x13e>
40016024:	07800713          	li	a4,120
40016028:	fae78de3          	beq	a5,a4,40015fe2 <whisperPrintfImpl+0xc4>
4001602c:	07300713          	li	a4,115
40016030:	f4e799e3          	bne	a5,a4,40015f82 <whisperPrintfImpl+0x64>
40016034:	00448d13          	add	s10,s1,4
40016038:	8cca                	mv	s9,s2
4001603a:	4084                	lw	s1,0(s1)
4001603c:	412c87b3          	sub	a5,s9,s2
40016040:	97a6                	add	a5,a5,s1
40016042:	0007c503          	lbu	a0,0(a5)
40016046:	e91d                	bnez	a0,4001607c <whisperPrintfImpl+0x15e>
40016048:	84ea                	mv	s1,s10
4001604a:	8966                	mv	s2,s9
4001604c:	bf1d                	j	40015f82 <whisperPrintfImpl+0x64>
4001604e:	4088                	lw	a0,0(s1)
40016050:	00448c93          	add	s9,s1,4
40016054:	3b59                	jal	40015dea <whisperPrintDecimal>
40016056:	992a                	add	s2,s2,a0
40016058:	84e6                	mv	s1,s9
4001605a:	b725                	j	40015f82 <whisperPrintfImpl+0x64>
4001605c:	4088                	lw	a0,0(s1)
4001605e:	00448c93          	add	s9,s1,4
40016062:	3b01                	jal	40015d72 <whisperPrintUnsigned>
40016064:	bfcd                	j	40016056 <whisperPrintfImpl+0x138>
40016066:	00448c93          	add	s9,s1,4
4001606a:	46a1                	li	a3,8
4001606c:	bfb5                	j	40015fe8 <whisperPrintfImpl+0xca>
4001606e:	0004c503          	lbu	a0,0(s1)
40016072:	00448c93          	add	s9,s1,4
40016076:	395d                	jal	40015d2c <whisperPutc>
40016078:	0905                	add	s2,s2,1
4001607a:	bff9                	j	40016058 <whisperPrintfImpl+0x13a>
4001607c:	3945                	jal	40015d2c <whisperPutc>
4001607e:	0c85                	add	s9,s9,1
40016080:	bf75                	j	4001603c <whisperPrintfImpl+0x11e>

40016082 <putchar>:
40016082:	0ff57513          	zext.b	a0,a0
40016086:	b15d                	j	40015d2c <whisperPutc>

40016088 <puts>:
40016088:	b1e1                	j	40015d50 <whisperPuts>

4001608a <printf>:
4001608a:	7139                	add	sp,sp,-64
4001608c:	d22e                	sw	a1,36(sp)
4001608e:	104c                	add	a1,sp,36
40016090:	ce06                	sw	ra,28(sp)
40016092:	d432                	sw	a2,40(sp)
40016094:	d636                	sw	a3,44(sp)
40016096:	d83a                	sw	a4,48(sp)
40016098:	da3e                	sw	a5,52(sp)
4001609a:	dc42                	sw	a6,56(sp)
4001609c:	de46                	sw	a7,60(sp)
4001609e:	c62e                	sw	a1,12(sp)
400160a0:	3dbd                	jal	40015f1e <whisperPrintfImpl>
400160a2:	40f2                	lw	ra,28(sp)
400160a4:	6121                	add	sp,sp,64
400160a6:	8082                	ret

400160a8 <check_spi_status>:
400160a8:	200006b7          	lui	a3,0x20000
400160ac:	1141                	add	sp,sp,-16
400160ae:	200007b7          	lui	a5,0x20000
400160b2:	30030637          	lui	a2,0x30030
400160b6:	68a9                	lui	a7,0xa
400160b8:	30030337          	lui	t1,0x30030
400160bc:	c422                	sw	s0,8(sp)
400160be:	06d1                	add	a3,a3,20 # 20000014 <mfdc+0x1ffff81b>
400160c0:	4298                	lw	a4,0(a3)
400160c2:	c606                	sw	ra,12(sp)
400160c4:	5bc0                	lw	s0,52(a5)
400160c6:	03000fb7          	lui	t6,0x3000
400160ca:	01000f37          	lui	t5,0x1000
400160ce:	02878813          	add	a6,a5,40 # 20000028 <mfdc+0x1ffff82f>
400160d2:	64060613          	add	a2,a2,1600 # 30030640 <mfdc+0x3002fe47>
400160d6:	c4088893          	add	a7,a7,-960 # 9c40 <mfdc+0x9447>
400160da:	64830313          	add	t1,t1,1608 # 30030648 <mfdc+0x3002fe4f>
400160de:	01f777b3          	and	a5,a4,t6
400160e2:	07e79c63          	bne	a5,t5,4001615a <check_spi_status+0xb2>
400160e6:	200007b7          	lui	a5,0x20000
400160ea:	07d1                	add	a5,a5,20 # 20000014 <mfdc+0x1ffff81b>
400160ec:	00171693          	sll	a3,a4,0x1
400160f0:	0a06c263          	bltz	a3,40016194 <check_spi_status+0xec>
400160f4:	439c                	lw	a5,0(a5)
400160f6:	cc31                	beqz	s0,40016152 <check_spi_status+0xaa>
400160f8:	50010537          	lui	a0,0x50010
400160fc:	85a2                	mv	a1,s0
400160fe:	6c850513          	add	a0,a0,1736 # 500106c8 <__func__.0+0x1b8>
40016102:	3761                	jal	4001608a <printf>
40016104:	01047793          	and	a5,s0,16
40016108:	c791                	beqz	a5,40016114 <check_spi_status+0x6c>
4001610a:	50010537          	lui	a0,0x50010
4001610e:	6e050513          	add	a0,a0,1760 # 500106e0 <__func__.0+0x1d0>
40016112:	3f9d                	jal	40016088 <puts>
40016114:	00847793          	and	a5,s0,8
40016118:	c791                	beqz	a5,40016124 <check_spi_status+0x7c>
4001611a:	50010537          	lui	a0,0x50010
4001611e:	6f450513          	add	a0,a0,1780 # 500106f4 <__func__.0+0x1e4>
40016122:	379d                	jal	40016088 <puts>
40016124:	02047793          	and	a5,s0,32
40016128:	c791                	beqz	a5,40016134 <check_spi_status+0x8c>
4001612a:	50010537          	lui	a0,0x50010
4001612e:	70450513          	add	a0,a0,1796 # 50010704 <__func__.0+0x1f4>
40016132:	3f99                	jal	40016088 <puts>
40016134:	00247793          	and	a5,s0,2
40016138:	c791                	beqz	a5,40016144 <check_spi_status+0x9c>
4001613a:	50010537          	lui	a0,0x50010
4001613e:	71850513          	add	a0,a0,1816 # 50010718 <__func__.0+0x208>
40016142:	3799                	jal	40016088 <puts>
40016144:	0220000f          	fence	r,r
40016148:	0220000f          	fence	r,r
4001614c:	200007b7          	lui	a5,0x20000
40016150:	dbc0                	sw	s0,52(a5)
40016152:	40b2                	lw	ra,12(sp)
40016154:	4422                	lw	s0,8(sp)
40016156:	0141                	add	sp,sp,16
40016158:	8082                	ret
4001615a:	00082783          	lw	a5,0(a6)
4001615e:	4208                	lw	a0,0(a2)
40016160:	01150733          	add	a4,a0,a7
40016164:	424c                	lw	a1,4(a2)
40016166:	00a737b3          	sltu	a5,a4,a0
4001616a:	97ae                	add	a5,a5,a1
4001616c:	00e32023          	sw	a4,0(t1)
40016170:	853a                	mv	a0,a4
40016172:	00f32223          	sw	a5,4(t1)
40016176:	00062e03          	lw	t3,0(a2)
4001617a:	00462e83          	lw	t4,4(a2)
4001617e:	00fee863          	bltu	t4,a5,4001618e <check_spi_status+0xe6>
40016182:	01d79463          	bne	a5,t4,4001618a <check_spi_status+0xe2>
40016186:	00ae6463          	bltu	t3,a0,4001618e <check_spi_status+0xe6>
4001618a:	4298                	lw	a4,0(a3)
4001618c:	bf89                	j	400160de <check_spi_status+0x36>
4001618e:	10500073          	wfi
40016192:	b7d5                	j	40016176 <check_spi_status+0xce>
40016194:	4398                	lw	a4,0(a5)
40016196:	bf99                	j	400160ec <check_spi_status+0x44>

40016198 <fifo_rx_wait>:
40016198:	200006b7          	lui	a3,0x20000
4001619c:	3e900713          	li	a4,1001
400161a0:	06d1                	add	a3,a3,20 # 20000014 <mfdc+0x1ffff81b>
400161a2:	429c                	lw	a5,0(a3)
400161a4:	83a1                	srl	a5,a5,0x8
400161a6:	177d                	add	a4,a4,-1
400161a8:	0ff7f793          	zext.b	a5,a5
400161ac:	c709                	beqz	a4,400161b6 <fifo_rx_wait+0x1e>
400161ae:	fef51ae3          	bne	a0,a5,400161a2 <fifo_rx_wait+0xa>
400161b2:	4501                	li	a0,0
400161b4:	8082                	ret
400161b6:	4505                	li	a0,1
400161b8:	8082                	ret

400161ba <spi_command_wait>:
400161ba:	200007b7          	lui	a5,0x20000
400161be:	07d1                	add	a5,a5,20 # 20000014 <mfdc+0x1ffff81b>
400161c0:	4398                	lw	a4,0(a5)
400161c2:	00171693          	sll	a3,a4,0x1
400161c6:	fe06dde3          	bgez	a3,400161c0 <spi_command_wait+0x6>
400161ca:	8082                	ret

400161cc <set_spi_csid>:
400161cc:	0220000f          	fence	r,r
400161d0:	0220000f          	fence	r,r
400161d4:	200007b7          	lui	a5,0x20000
400161d8:	d388                	sw	a0,32(a5)
400161da:	8082                	ret

400161dc <write_tx_fifo>:
400161dc:	20000737          	lui	a4,0x20000
400161e0:	3e800793          	li	a5,1000
400161e4:	0751                	add	a4,a4,20 # 20000014 <mfdc+0x1ffff81b>
400161e6:	4314                	lw	a3,0(a4)
400161e8:	17fd                	add	a5,a5,-1 # 1fffffff <mfdc+0x1ffff806>
400161ea:	cf91                	beqz	a5,40016206 <write_tx_fifo+0x2a>
400161ec:	00269613          	sll	a2,a3,0x2
400161f0:	fe064be3          	bltz	a2,400161e6 <write_tx_fifo+0xa>
400161f4:	0220000f          	fence	r,r
400161f8:	0220000f          	fence	r,r
400161fc:	200007b7          	lui	a5,0x20000
40016200:	d7c8                	sw	a0,44(a5)
40016202:	4501                	li	a0,0
40016204:	8082                	ret
40016206:	557d                	li	a0,-1
40016208:	8082                	ret

4001620a <spi_command>:
4001620a:	20000737          	lui	a4,0x20000
4001620e:	3e800793          	li	a5,1000
40016212:	0751                	add	a4,a4,20 # 20000014 <mfdc+0x1ffff81b>
40016214:	00072803          	lw	a6,0(a4)
40016218:	17fd                	add	a5,a5,-1 # 1fffffff <mfdc+0x1ffff806>
4001621a:	c399                	beqz	a5,40016220 <spi_command+0x16>
4001621c:	fe085ce3          	bgez	a6,40016214 <spi_command+0xa>
40016220:	05a6                	sll	a1,a1,0x9
40016222:	062a                	sll	a2,a2,0xa
40016224:	8e4d                	or	a2,a2,a1
40016226:	8e49                	or	a2,a2,a0
40016228:	06b2                	sll	a3,a3,0xc
4001622a:	8e55                	or	a2,a2,a3
4001622c:	0220000f          	fence	r,r
40016230:	0220000f          	fence	r,r
40016234:	200007b7          	lui	a5,0x20000
40016238:	d3d0                	sw	a2,36(a5)
4001623a:	8082                	ret

4001623c <spi_read_response>:
4001623c:	200007b7          	lui	a5,0x20000
40016240:	3e800713          	li	a4,1000
40016244:	07d1                	add	a5,a5,20 # 20000014 <mfdc+0x1ffff81b>
40016246:	4394                	lw	a3,0(a5)
40016248:	00769613          	sll	a2,a3,0x7
4001624c:	00064963          	bltz	a2,4001625e <spi_read_response+0x22>
40016250:	200007b7          	lui	a5,0x20000
40016254:	5788                	lw	a0,40(a5)
40016256:	8121                	srl	a0,a0,0x8
40016258:	0ff57513          	zext.b	a0,a0
4001625c:	8082                	ret
4001625e:	177d                	add	a4,a4,-1
40016260:	f37d                	bnez	a4,40016246 <spi_read_response+0xa>
40016262:	0ff00513          	li	a0,255
40016266:	8082                	ret

40016268 <end_sim_if_qspi_disabled>:
40016268:	300307b7          	lui	a5,0x30030
4001626c:	0e07a783          	lw	a5,224(a5) # 300300e0 <mfdc+0x3002f8e7>
40016270:	8b89                	and	a5,a5,2
40016272:	e391                	bnez	a5,40016276 <end_sim_if_qspi_disabled+0xe>
40016274:	a001                	j	40016274 <end_sim_if_qspi_disabled+0xc>
40016276:	8082                	ret

40016278 <enable_spi_host>:
40016278:	0220000f          	fence	r,r
4001627c:	0220000f          	fence	r,r
40016280:	a00007b7          	lui	a5,0xa0000
40016284:	20000737          	lui	a4,0x20000
40016288:	07f78793          	add	a5,a5,127 # a000007f <_tbs_der_store_end+0x4ffe105f>
4001628c:	cb1c                	sw	a5,16(a4)
4001628e:	8082                	ret

40016290 <init_qspi>:
40016290:	1141                	add	sp,sp,-16
40016292:	c606                	sw	ra,12(sp)
40016294:	3fd1                	jal	40016268 <end_sim_if_qspi_disabled>
40016296:	40b2                	lw	ra,12(sp)
40016298:	0141                	add	sp,sp,16
4001629a:	bff9                	j	40016278 <enable_spi_host>

4001629c <configure_spi_host_slow>:
4001629c:	200007b7          	lui	a5,0x20000
400162a0:	07f1                	add	a5,a5,28 # 2000001c <mfdc+0x1ffff823>
400162a2:	e501                	bnez	a0,400162aa <configure_spi_host_slow+0xe>
400162a4:	200007b7          	lui	a5,0x20000
400162a8:	07e1                	add	a5,a5,24 # 20000018 <mfdc+0x1ffff81f>
400162aa:	0220000f          	fence	r,r
400162ae:	0220000f          	fence	r,r
400162b2:	c0000737          	lui	a4,0xc0000
400162b6:	03170713          	add	a4,a4,49 # c0000031 <_tbs_der_store_end+0x6ffe1011>
400162ba:	c398                	sw	a4,0(a5)
400162bc:	8082                	ret

400162be <sd_send_cmd>:
400162be:	715d                	add	sp,sp,-80
400162c0:	72fd                	lui	t0,0xfffff
400162c2:	c686                	sw	ra,76(sp)
400162c4:	c4a2                	sw	s0,72(sp)
400162c6:	c2a6                	sw	s1,68(sp)
400162c8:	de4e                	sw	s3,60(sp)
400162ca:	d462                	sw	s8,40(sp)
400162cc:	c0ca                	sw	s2,64(sp)
400162ce:	dc52                	sw	s4,56(sp)
400162d0:	da56                	sw	s5,52(sp)
400162d2:	d85a                	sw	s6,48(sp)
400162d4:	d65e                	sw	s7,44(sp)
400162d6:	d266                	sw	s9,36(sp)
400162d8:	d06a                	sw	s10,32(sp)
400162da:	ce6e                	sw	s11,28(sp)
400162dc:	842a                	mv	s0,a0
400162de:	9116                	add	sp,sp,t0
400162e0:	4501                	li	a0,0
400162e2:	89ae                	mv	s3,a1
400162e4:	8c32                	mv	s8,a2
400162e6:	84b6                	mv	s1,a3
400162e8:	35d5                	jal	400161cc <set_spi_csid>
400162ea:	8522                	mv	a0,s0
400162ec:	3dc5                	jal	400161dc <write_tx_fifo>
400162ee:	4689                	li	a3,2
400162f0:	4601                	li	a2,0
400162f2:	4585                	li	a1,1
400162f4:	4501                	li	a0,0
400162f6:	3f11                	jal	4001620a <spi_command>
400162f8:	0189d513          	srl	a0,s3,0x18
400162fc:	35c5                	jal	400161dc <write_tx_fifo>
400162fe:	4689                	li	a3,2
40016300:	4601                	li	a2,0
40016302:	4585                	li	a1,1
40016304:	4501                	li	a0,0
40016306:	3711                	jal	4001620a <spi_command>
40016308:	0109d513          	srl	a0,s3,0x10
4001630c:	3dc1                	jal	400161dc <write_tx_fifo>
4001630e:	4689                	li	a3,2
40016310:	4601                	li	a2,0
40016312:	4585                	li	a1,1
40016314:	4501                	li	a0,0
40016316:	3dd5                	jal	4001620a <spi_command>
40016318:	0089d513          	srl	a0,s3,0x8
4001631c:	35c1                	jal	400161dc <write_tx_fifo>
4001631e:	4689                	li	a3,2
40016320:	4601                	li	a2,0
40016322:	4585                	li	a1,1
40016324:	4501                	li	a0,0
40016326:	35d5                	jal	4001620a <spi_command>
40016328:	854e                	mv	a0,s3
4001632a:	3d4d                	jal	400161dc <write_tx_fifo>
4001632c:	4501                	li	a0,0
4001632e:	4689                	li	a3,2
40016330:	4601                	li	a2,0
40016332:	4585                	li	a1,1
40016334:	3dd9                	jal	4001620a <spi_command>
40016336:	04000793          	li	a5,64
4001633a:	09500513          	li	a0,149
4001633e:	00f40a63          	beq	s0,a5,40016352 <sd_send_cmd+0x94>
40016342:	04800793          	li	a5,72
40016346:	08700513          	li	a0,135
4001634a:	00f40463          	beq	s0,a5,40016352 <sd_send_cmd+0x94>
4001634e:	0ff00513          	li	a0,255
40016352:	3569                	jal	400161dc <write_tx_fifo>
40016354:	4689                	li	a3,2
40016356:	4601                	li	a2,0
40016358:	4585                	li	a1,1
4001635a:	4501                	li	a0,0
4001635c:	357d                	jal	4001620a <spi_command>
4001635e:	3db1                	jal	400161ba <spi_command_wait>
40016360:	05200793          	li	a5,82
40016364:	12f41e63          	bne	s0,a5,400164a0 <sd_send_cmd+0x1e2>
40016368:	6605                	lui	a2,0x1
4001636a:	4581                	li	a1,0
4001636c:	0808                	add	a0,sp,16
4001636e:	80a5                	srl	s1,s1,0x9
40016370:	4cf020ef          	jal	4001903e <memset>
40016374:	04000413          	li	s0,64
40016378:	557d                	li	a0,-1
4001637a:	147d                	add	s0,s0,-1
4001637c:	3585                	jal	400161dc <write_tx_fifo>
4001637e:	fc6d                	bnez	s0,40016378 <sd_send_cmd+0xba>
40016380:	468d                	li	a3,3
40016382:	4601                	li	a2,0
40016384:	4585                	li	a1,1
40016386:	0ff00513          	li	a0,255
4001638a:	3541                	jal	4001620a <spi_command>
4001638c:	4981                	li	s3,0
4001638e:	3535                	jal	400161ba <spi_command_wait>
40016390:	4a01                	li	s4,0
40016392:	40000a93          	li	s5,1024
40016396:	02999f63          	bne	s3,s1,400163d4 <sd_send_cmd+0x116>
4001639a:	4505                	li	a0,1
4001639c:	3d05                	jal	400161cc <set_spi_csid>
4001639e:	0ff00513          	li	a0,255
400163a2:	3d2d                	jal	400161dc <write_tx_fifo>
400163a4:	4689                	li	a3,2
400163a6:	4601                	li	a2,0
400163a8:	4581                	li	a1,0
400163aa:	4501                	li	a0,0
400163ac:	3db9                	jal	4001620a <spi_command>
400163ae:	4401                	li	s0,0
400163b0:	6285                	lui	t0,0x1
400163b2:	9116                	add	sp,sp,t0
400163b4:	40b6                	lw	ra,76(sp)
400163b6:	8522                	mv	a0,s0
400163b8:	4496                	lw	s1,68(sp)
400163ba:	4426                	lw	s0,72(sp)
400163bc:	4906                	lw	s2,64(sp)
400163be:	59f2                	lw	s3,60(sp)
400163c0:	5a62                	lw	s4,56(sp)
400163c2:	5ad2                	lw	s5,52(sp)
400163c4:	5b42                	lw	s6,48(sp)
400163c6:	5bb2                	lw	s7,44(sp)
400163c8:	5c22                	lw	s8,40(sp)
400163ca:	5c92                	lw	s9,36(sp)
400163cc:	5d02                	lw	s10,32(sp)
400163ce:	4df2                	lw	s11,28(sp)
400163d0:	6161                	add	sp,sp,80
400163d2:	8082                	ret
400163d4:	01010913          	add	s2,sp,16
400163d8:	20000b37          	lui	s6,0x20000
400163dc:	20000bb7          	lui	s7,0x20000
400163e0:	8d4a                	mv	s10,s2
400163e2:	4c81                	li	s9,0
400163e4:	0b51                	add	s6,s6,20 # 20000014 <mfdc+0x1ffff81b>
400163e6:	028b8b93          	add	s7,s7,40 # 20000028 <mfdc+0x1ffff82f>
400163ea:	468d                	li	a3,3
400163ec:	4601                	li	a2,0
400163ee:	4585                	li	a1,1
400163f0:	0ff00513          	li	a0,255
400163f4:	3d19                	jal	4001620a <spi_command>
400163f6:	33d1                	jal	400161ba <spi_command_wait>
400163f8:	04000513          	li	a0,64
400163fc:	3b71                	jal	40016198 <fifo_rx_wait>
400163fe:	8dea                	mv	s11,s10
40016400:	4681                	li	a3,0
40016402:	000b2403          	lw	s0,0(s6)
40016406:	010007b7          	lui	a5,0x1000
4001640a:	8c7d                	and	s0,s0,a5
4001640c:	f87d                	bnez	s0,40016402 <sd_send_cmd+0x144>
4001640e:	000ba783          	lw	a5,0(s7)
40016412:	0ff7f613          	zext.b	a2,a5
40016416:	00cda023          	sw	a2,0(s11)
4001641a:	0087d613          	srl	a2,a5,0x8
4001641e:	0ff67613          	zext.b	a2,a2
40016422:	00cda223          	sw	a2,4(s11)
40016426:	0107d613          	srl	a2,a5,0x10
4001642a:	0ff67613          	zext.b	a2,a2
4001642e:	83e1                	srl	a5,a5,0x18
40016430:	00cda423          	sw	a2,8(s11)
40016434:	00fda623          	sw	a5,12(s11)
40016438:	557d                	li	a0,-1
4001643a:	c636                	sw	a3,12(sp)
4001643c:	3345                	jal	400161dc <write_tx_fifo>
4001643e:	46b2                	lw	a3,12(sp)
40016440:	0691                	add	a3,a3,4
40016442:	10000593          	li	a1,256
40016446:	0dc1                	add	s11,s11,16
40016448:	fab69de3          	bne	a3,a1,40016402 <sd_send_cmd+0x144>
4001644c:	9cae                	add	s9,s9,a1
4001644e:	400d0d13          	add	s10,s10,1024
40016452:	f95c9ce3          	bne	s9,s5,400163ea <sd_send_cmd+0x12c>
40016456:	0fe00793          	li	a5,254
4001645a:	00092683          	lw	a3,0(s2)
4001645e:	0405                	add	s0,s0,1
40016460:	02f68e63          	beq	a3,a5,4001649c <sd_send_cmd+0x1de>
40016464:	0911                	add	s2,s2,4
40016466:	ff541ae3          	bne	s0,s5,4001645a <sd_send_cmd+0x19c>
4001646a:	468d                	li	a3,3
4001646c:	4601                	li	a2,0
4001646e:	4585                	li	a1,1
40016470:	0ff00513          	li	a0,255
40016474:	3b59                	jal	4001620a <spi_command>
40016476:	020a0163          	beqz	s4,40016498 <sd_send_cmd+0x1da>
4001647a:	200a0793          	add	a5,s4,512
4001647e:	00faed63          	bltu	s5,a5,40016498 <sd_send_cmd+0x1da>
40016482:	00999513          	sll	a0,s3,0x9
40016486:	010a0793          	add	a5,s4,16
4001648a:	20000613          	li	a2,512
4001648e:	002785b3          	add	a1,a5,sp
40016492:	9562                	add	a0,a0,s8
40016494:	453020ef          	jal	400190e6 <memcpy>
40016498:	0985                	add	s3,s3,1
4001649a:	bdf5                	j	40016396 <sd_send_cmd+0xd8>
4001649c:	8a22                	mv	s4,s0
4001649e:	b7f1                	j	4001646a <sd_send_cmd+0x1ac>
400164a0:	05100793          	li	a5,81
400164a4:	1ef41163          	bne	s0,a5,40016686 <sd_send_cmd+0x3c8>
400164a8:	40000613          	li	a2,1024
400164ac:	4581                	li	a1,0
400164ae:	0808                	add	a0,sp,16
400164b0:	38f020ef          	jal	4001903e <memset>
400164b4:	04000413          	li	s0,64
400164b8:	557d                	li	a0,-1
400164ba:	147d                	add	s0,s0,-1
400164bc:	3305                	jal	400161dc <write_tx_fifo>
400164be:	fc6d                	bnez	s0,400164b8 <sd_send_cmd+0x1fa>
400164c0:	468d                	li	a3,3
400164c2:	4601                	li	a2,0
400164c4:	4585                	li	a1,1
400164c6:	0ff00513          	li	a0,255
400164ca:	3381                	jal	4001620a <spi_command>
400164cc:	31fd                	jal	400161ba <spi_command_wait>
400164ce:	100287b7          	lui	a5,0x10028
400164d2:	4f9c                	lw	a5,24(a5)
400164d4:	468d                	li	a3,3
400164d6:	4601                	li	a2,0
400164d8:	4585                	li	a1,1
400164da:	0ff00513          	li	a0,255
400164de:	3335                	jal	4001620a <spi_command>
400164e0:	39e9                	jal	400161ba <spi_command_wait>
400164e2:	0800                	add	s0,sp,16
400164e4:	04000513          	li	a0,64
400164e8:	20000ab7          	lui	s5,0x20000
400164ec:	20000a37          	lui	s4,0x20000
400164f0:	3165                	jal	40016198 <fifo_rx_wait>
400164f2:	10040993          	add	s3,s0,256
400164f6:	84a2                	mv	s1,s0
400164f8:	0ad1                	add	s5,s5,20 # 20000014 <mfdc+0x1ffff81b>
400164fa:	028a0a13          	add	s4,s4,40 # 20000028 <mfdc+0x1ffff82f>
400164fe:	000aa783          	lw	a5,0(s5)
40016502:	00779713          	sll	a4,a5,0x7
40016506:	fe074ce3          	bltz	a4,400164fe <sd_send_cmd+0x240>
4001650a:	000a2783          	lw	a5,0(s4)
4001650e:	0087d713          	srl	a4,a5,0x8
40016512:	00f48023          	sb	a5,0(s1)
40016516:	00e480a3          	sb	a4,1(s1)
4001651a:	0107d713          	srl	a4,a5,0x10
4001651e:	83e1                	srl	a5,a5,0x18
40016520:	00e48123          	sb	a4,2(s1)
40016524:	00f481a3          	sb	a5,3(s1)
40016528:	557d                	li	a0,-1
4001652a:	0491                	add	s1,s1,4
4001652c:	3945                	jal	400161dc <write_tx_fifo>
4001652e:	fd3498e3          	bne	s1,s3,400164fe <sd_send_cmd+0x240>
40016532:	468d                	li	a3,3
40016534:	4601                	li	a2,0
40016536:	4585                	li	a1,1
40016538:	0ff00513          	li	a0,255
4001653c:	31f9                	jal	4001620a <spi_command>
4001653e:	39b5                	jal	400161ba <spi_command_wait>
40016540:	04000513          	li	a0,64
40016544:	20000ab7          	lui	s5,0x20000
40016548:	20000a37          	lui	s4,0x20000
4001654c:	31b1                	jal	40016198 <fifo_rx_wait>
4001654e:	84a2                	mv	s1,s0
40016550:	0ad1                	add	s5,s5,20 # 20000014 <mfdc+0x1ffff81b>
40016552:	028a0a13          	add	s4,s4,40 # 20000028 <mfdc+0x1ffff82f>
40016556:	000aa783          	lw	a5,0(s5)
4001655a:	00779713          	sll	a4,a5,0x7
4001655e:	fe074ce3          	bltz	a4,40016556 <sd_send_cmd+0x298>
40016562:	000a2783          	lw	a5,0(s4)
40016566:	0087d713          	srl	a4,a5,0x8
4001656a:	10f48023          	sb	a5,256(s1)
4001656e:	10e480a3          	sb	a4,257(s1)
40016572:	0107d713          	srl	a4,a5,0x10
40016576:	83e1                	srl	a5,a5,0x18
40016578:	10e48123          	sb	a4,258(s1)
4001657c:	10f481a3          	sb	a5,259(s1)
40016580:	557d                	li	a0,-1
40016582:	0491                	add	s1,s1,4
40016584:	39a1                	jal	400161dc <write_tx_fifo>
40016586:	fd3498e3          	bne	s1,s3,40016556 <sd_send_cmd+0x298>
4001658a:	468d                	li	a3,3
4001658c:	4601                	li	a2,0
4001658e:	4585                	li	a1,1
40016590:	0ff00513          	li	a0,255
40016594:	399d                	jal	4001620a <spi_command>
40016596:	3115                	jal	400161ba <spi_command_wait>
40016598:	04000513          	li	a0,64
4001659c:	20000ab7          	lui	s5,0x20000
400165a0:	20000a37          	lui	s4,0x20000
400165a4:	3ed5                	jal	40016198 <fifo_rx_wait>
400165a6:	84a2                	mv	s1,s0
400165a8:	0ad1                	add	s5,s5,20 # 20000014 <mfdc+0x1ffff81b>
400165aa:	028a0a13          	add	s4,s4,40 # 20000028 <mfdc+0x1ffff82f>
400165ae:	000aa783          	lw	a5,0(s5)
400165b2:	00779713          	sll	a4,a5,0x7
400165b6:	fe074ce3          	bltz	a4,400165ae <sd_send_cmd+0x2f0>
400165ba:	000a2783          	lw	a5,0(s4)
400165be:	0087d713          	srl	a4,a5,0x8
400165c2:	20f48023          	sb	a5,512(s1)
400165c6:	20e480a3          	sb	a4,513(s1)
400165ca:	0107d713          	srl	a4,a5,0x10
400165ce:	83e1                	srl	a5,a5,0x18
400165d0:	20e48123          	sb	a4,514(s1)
400165d4:	20f481a3          	sb	a5,515(s1)
400165d8:	557d                	li	a0,-1
400165da:	0491                	add	s1,s1,4
400165dc:	3101                	jal	400161dc <write_tx_fifo>
400165de:	fd3498e3          	bne	s1,s3,400165ae <sd_send_cmd+0x2f0>
400165e2:	468d                	li	a3,3
400165e4:	4601                	li	a2,0
400165e6:	4581                	li	a1,0
400165e8:	0ff00513          	li	a0,255
400165ec:	3939                	jal	4001620a <spi_command>
400165ee:	4505                	li	a0,1
400165f0:	3ef1                	jal	400161cc <set_spi_csid>
400165f2:	36e1                	jal	400161ba <spi_command_wait>
400165f4:	04000513          	li	a0,64
400165f8:	20000ab7          	lui	s5,0x20000
400165fc:	20000a37          	lui	s4,0x20000
40016600:	3e61                	jal	40016198 <fifo_rx_wait>
40016602:	0ad1                	add	s5,s5,20 # 20000014 <mfdc+0x1ffff81b>
40016604:	01000b37          	lui	s6,0x1000
40016608:	028a0a13          	add	s4,s4,40 # 20000028 <mfdc+0x1ffff82f>
4001660c:	000aa483          	lw	s1,0(s5)
40016610:	0164f4b3          	and	s1,s1,s6
40016614:	fce5                	bnez	s1,4001660c <sd_send_cmd+0x34e>
40016616:	000a2783          	lw	a5,0(s4)
4001661a:	0087d713          	srl	a4,a5,0x8
4001661e:	30f40023          	sb	a5,768(s0)
40016622:	30e400a3          	sb	a4,769(s0)
40016626:	0107d713          	srl	a4,a5,0x10
4001662a:	83e1                	srl	a5,a5,0x18
4001662c:	30e40123          	sb	a4,770(s0)
40016630:	30f401a3          	sb	a5,771(s0)
40016634:	557d                	li	a0,-1
40016636:	0411                	add	s0,s0,4
40016638:	3655                	jal	400161dc <write_tx_fifo>
4001663a:	fd3419e3          	bne	s0,s3,4001660c <sd_send_cmd+0x34e>
4001663e:	557d                	li	a0,-1
40016640:	3e71                	jal	400161dc <write_tx_fifo>
40016642:	557d                	li	a0,-1
40016644:	3e61                	jal	400161dc <write_tx_fifo>
40016646:	4689                	li	a3,2
40016648:	4581                	li	a1,0
4001664a:	4601                	li	a2,0
4001664c:	451d                	li	a0,7
4001664e:	3e75                	jal	4001620a <spi_command>
40016650:	080c                	add	a1,sp,16
40016652:	0fe00693          	li	a3,254
40016656:	40000713          	li	a4,1024
4001665a:	009587b3          	add	a5,a1,s1
4001665e:	0007c603          	lbu	a2,0(a5) # 10028000 <mfdc+0x10027807>
40016662:	87a6                	mv	a5,s1
40016664:	0485                	add	s1,s1,1
40016666:	00d61d63          	bne	a2,a3,40016680 <sd_send_cmd+0x3c2>
4001666a:	20178793          	add	a5,a5,513
4001666e:	d4f760e3          	bltu	a4,a5,400163ae <sd_send_cmd+0xf0>
40016672:	20000613          	li	a2,512
40016676:	95a6                	add	a1,a1,s1
40016678:	8562                	mv	a0,s8
4001667a:	26d020ef          	jal	400190e6 <memcpy>
4001667e:	bb05                	j	400163ae <sd_send_cmd+0xf0>
40016680:	fce49de3          	bne	s1,a4,4001665a <sd_send_cmd+0x39c>
40016684:	b32d                	j	400163ae <sd_send_cmd+0xf0>
40016686:	4685                	li	a3,1
40016688:	8536                	mv	a0,a3
4001668a:	4601                	li	a2,0
4001668c:	4581                	li	a1,0
4001668e:	3eb5                	jal	4001620a <spi_command>
40016690:	4505                	li	a0,1
40016692:	3e2d                	jal	400161cc <set_spi_csid>
40016694:	361d                	jal	400161ba <spi_command_wait>
40016696:	365d                	jal	4001623c <spi_read_response>
40016698:	842a                	mv	s0,a0
4001669a:	0ff00513          	li	a0,255
4001669e:	3e3d                	jal	400161dc <write_tx_fifo>
400166a0:	4689                	li	a3,2
400166a2:	4601                	li	a2,0
400166a4:	4581                	li	a1,0
400166a6:	4501                	li	a0,0
400166a8:	368d                	jal	4001620a <spi_command>
400166aa:	b319                	j	400163b0 <sd_send_cmd+0xf2>

400166ac <sendpulse>:
400166ac:	1141                	add	sp,sp,-16
400166ae:	557d                	li	a0,-1
400166b0:	c606                	sw	ra,12(sp)
400166b2:	362d                	jal	400161dc <write_tx_fifo>
400166b4:	40b2                	lw	ra,12(sp)
400166b6:	4689                	li	a3,2
400166b8:	4601                	li	a2,0
400166ba:	4581                	li	a1,0
400166bc:	450d                	li	a0,3
400166be:	0141                	add	sp,sp,16
400166c0:	b6a9                	j	4001620a <spi_command>

400166c2 <init_sd_card>:
400166c2:	1141                	add	sp,sp,-16
400166c4:	c606                	sw	ra,12(sp)
400166c6:	c422                	sw	s0,8(sp)
400166c8:	c226                	sw	s1,4(sp)
400166ca:	c04a                	sw	s2,0(sp)
400166cc:	3675                	jal	40016278 <enable_spi_host>
400166ce:	4501                	li	a0,0
400166d0:	36f1                	jal	4001629c <configure_spi_host_slow>
400166d2:	4505                	li	a0,1
400166d4:	36e1                	jal	4001629c <configure_spi_host_slow>
400166d6:	4505                	li	a0,1
400166d8:	af5ff0ef          	jal	400161cc <set_spi_csid>
400166dc:	4451                	li	s0,20
400166de:	37f9                	jal	400166ac <sendpulse>
400166e0:	4905                	li	s2,1
400166e2:	37e9                	jal	400166ac <sendpulse>
400166e4:	54fd                	li	s1,-1
400166e6:	37d9                	jal	400166ac <sendpulse>
400166e8:	4681                	li	a3,0
400166ea:	4601                	li	a2,0
400166ec:	4581                	li	a1,0
400166ee:	04000513          	li	a0,64
400166f2:	36f1                	jal	400162be <sd_send_cmd>
400166f4:	07251563          	bne	a0,s2,4001675e <init_sd_card+0x9c>
400166f8:	4485                	li	s1,1
400166fa:	4681                	li	a3,0
400166fc:	4601                	li	a2,0
400166fe:	1aa00593          	li	a1,426
40016702:	04800513          	li	a0,72
40016706:	3e65                	jal	400162be <sd_send_cmd>
40016708:	06950763          	beq	a0,s1,40016776 <init_sd_card+0xb4>
4001670c:	fff40793          	add	a5,s0,-1
40016710:	e02d                	bnez	s0,40016772 <init_sd_card+0xb0>
40016712:	4681                	li	a3,0
40016714:	4601                	li	a2,0
40016716:	4581                	li	a1,0
40016718:	06900513          	li	a0,105
4001671c:	364d                	jal	400162be <sd_send_cmd>
4001671e:	00a4b433          	sltu	s0,s1,a0
40016722:	40800433          	neg	s0,s0
40016726:	fd847413          	and	s0,s0,-40
4001672a:	06940413          	add	s0,s0,105
4001672e:	3e800493          	li	s1,1000
40016732:	597d                	li	s2,-1
40016734:	4681                	li	a3,0
40016736:	4601                	li	a2,0
40016738:	4581                	li	a1,0
4001673a:	8522                	mv	a0,s0
4001673c:	3649                	jal	400162be <sd_send_cmd>
4001673e:	c92d                	beqz	a0,400167b0 <init_sd_card+0xee>
40016740:	14fd                	add	s1,s1,-1
40016742:	ff2499e3          	bne	s1,s2,40016734 <init_sd_card+0x72>
40016746:	4681                	li	a3,0
40016748:	4601                	li	a2,0
4001674a:	20000593          	li	a1,512
4001674e:	05000513          	li	a0,80
40016752:	36b5                	jal	400162be <sd_send_cmd>
40016754:	00a03533          	snez	a0,a0
40016758:	40a00533          	neg	a0,a0
4001675c:	a029                	j	40016766 <init_sd_card+0xa4>
4001675e:	147d                	add	s0,s0,-1
40016760:	f89414e3          	bne	s0,s1,400166e8 <init_sd_card+0x26>
40016764:	557d                	li	a0,-1
40016766:	40b2                	lw	ra,12(sp)
40016768:	4422                	lw	s0,8(sp)
4001676a:	4492                	lw	s1,4(sp)
4001676c:	4902                	lw	s2,0(sp)
4001676e:	0141                	add	sp,sp,16
40016770:	8082                	ret
40016772:	843e                	mv	s0,a5
40016774:	b759                	j	400166fa <init_sd_card+0x38>
40016776:	3e900493          	li	s1,1001
4001677a:	4405                	li	s0,1
4001677c:	4681                	li	a3,0
4001677e:	4601                	li	a2,0
40016780:	4581                	li	a1,0
40016782:	07700513          	li	a0,119
40016786:	b39ff0ef          	jal	400162be <sd_send_cmd>
4001678a:	02851163          	bne	a0,s0,400167ac <init_sd_card+0xea>
4001678e:	4681                	li	a3,0
40016790:	4601                	li	a2,0
40016792:	400005b7          	lui	a1,0x40000
40016796:	06900513          	li	a0,105
4001679a:	b25ff0ef          	jal	400162be <sd_send_cmd>
4001679e:	c501                	beqz	a0,400167a6 <init_sd_card+0xe4>
400167a0:	14fd                	add	s1,s1,-1
400167a2:	fce9                	bnez	s1,4001677c <init_sd_card+0xba>
400167a4:	4401                	li	s0,0
400167a6:	fff40513          	add	a0,s0,-1
400167aa:	bf75                	j	40016766 <init_sd_card+0xa4>
400167ac:	f975                	bnez	a0,400167a0 <init_sd_card+0xde>
400167ae:	bfdd                	j	400167a4 <init_sd_card+0xe2>
400167b0:	d8d5                	beqz	s1,40016764 <init_sd_card+0xa2>
400167b2:	bf51                	j	40016746 <init_sd_card+0x84>

400167b4 <read_sd_card>:
400167b4:	1101                	add	sp,sp,-32
400167b6:	c64e                	sw	s3,12(sp)
400167b8:	89b6                	mv	s3,a3
400167ba:	cc22                	sw	s0,24(sp)
400167bc:	ca26                	sw	s1,20(sp)
400167be:	c84a                	sw	s2,16(sp)
400167c0:	ce06                	sw	ra,28(sp)
400167c2:	842a                	mv	s0,a0
400167c4:	84ae                	mv	s1,a1
400167c6:	8932                	mv	s2,a2
400167c8:	8e1ff0ef          	jal	400160a8 <check_spi_status>
400167cc:	00099f63          	bnez	s3,400167ea <read_sd_card+0x36>
400167d0:	4681                	li	a3,0
400167d2:	8626                	mv	a2,s1
400167d4:	85a2                	mv	a1,s0
400167d6:	05100513          	li	a0,81
400167da:	4462                	lw	s0,24(sp)
400167dc:	40f2                	lw	ra,28(sp)
400167de:	44d2                	lw	s1,20(sp)
400167e0:	4942                	lw	s2,16(sp)
400167e2:	49b2                	lw	s3,12(sp)
400167e4:	6105                	add	sp,sp,32
400167e6:	ad9ff06f          	j	400162be <sd_send_cmd>
400167ea:	86ca                	mv	a3,s2
400167ec:	8626                	mv	a2,s1
400167ee:	85a2                	mv	a1,s0
400167f0:	05200513          	li	a0,82
400167f4:	b7dd                	j	400167da <read_sd_card+0x26>

400167f6 <sha256_flow_produce>:
400167f6:	1141                	add	sp,sp,-16
400167f8:	10028737          	lui	a4,0x10028
400167fc:	c422                	sw	s0,8(sp)
400167fe:	c606                	sw	ra,12(sp)
40016800:	842e                	mv	s0,a1
40016802:	0761                	add	a4,a4,24 # 10028018 <mfdc+0x1002781f>
40016804:	431c                	lw	a5,0(a4)
40016806:	8b85                	and	a5,a5,1
40016808:	dff5                	beqz	a5,40016804 <sha256_flow_produce+0xe>
4001680a:	100287b7          	lui	a5,0x10028
4001680e:	10028737          	lui	a4,0x10028
40016812:	08078793          	add	a5,a5,128 # 10028080 <mfdc+0x10027887>
40016816:	0c070713          	add	a4,a4,192 # 100280c0 <mfdc+0x100278c7>
4001681a:	86be                	mv	a3,a5
4001681c:	4150                	lw	a2,4(a0)
4001681e:	0791                	add	a5,a5,4
40016820:	c290                	sw	a2,0(a3)
40016822:	0511                	add	a0,a0,4
40016824:	fee79be3          	bne	a5,a4,4001681a <sha256_flow_produce+0x24>
40016828:	50010537          	lui	a0,0x50010
4001682c:	040a                	sll	s0,s0,0x2
4001682e:	72850513          	add	a0,a0,1832 # 50010728 <__func__.0+0x218>
40016832:	8811                	and	s0,s0,4
40016834:	855ff0ef          	jal	40016088 <puts>
40016838:	00146413          	or	s0,s0,1
4001683c:	0220000f          	fence	r,r
40016840:	0220000f          	fence	r,r
40016844:	100287b7          	lui	a5,0x10028
40016848:	cb80                	sw	s0,16(a5)
4001684a:	01878713          	add	a4,a5,24 # 10028018 <mfdc+0x1002781f>
4001684e:	431c                	lw	a5,0(a4)
40016850:	8b89                	and	a5,a5,2
40016852:	dff5                	beqz	a5,4001684e <sha256_flow_produce+0x58>
40016854:	50010537          	lui	a0,0x50010
40016858:	73850513          	add	a0,a0,1848 # 50010738 <__func__.0+0x228>
4001685c:	82dff0ef          	jal	40016088 <puts>
40016860:	100287b7          	lui	a5,0x10028
40016864:	1007a783          	lw	a5,256(a5) # 10028100 <mfdc+0x10027907>
40016868:	100287b7          	lui	a5,0x10028
4001686c:	1047a783          	lw	a5,260(a5) # 10028104 <mfdc+0x1002790b>
40016870:	100287b7          	lui	a5,0x10028
40016874:	1087a783          	lw	a5,264(a5) # 10028108 <mfdc+0x1002790f>
40016878:	100287b7          	lui	a5,0x10028
4001687c:	10c7a783          	lw	a5,268(a5) # 1002810c <mfdc+0x10027913>
40016880:	100287b7          	lui	a5,0x10028
40016884:	1107a783          	lw	a5,272(a5) # 10028110 <mfdc+0x10027917>
40016888:	100287b7          	lui	a5,0x10028
4001688c:	1147a783          	lw	a5,276(a5) # 10028114 <mfdc+0x1002791b>
40016890:	100287b7          	lui	a5,0x10028
40016894:	1187a783          	lw	a5,280(a5) # 10028118 <mfdc+0x1002791f>
40016898:	40b2                	lw	ra,12(sp)
4001689a:	4422                	lw	s0,8(sp)
4001689c:	100287b7          	lui	a5,0x10028
400168a0:	11c7a783          	lw	a5,284(a5) # 1002811c <mfdc+0x10027923>
400168a4:	0141                	add	sp,sp,16
400168a6:	8082                	ret

400168a8 <sha384_core>:
400168a8:	ff0107b7          	lui	a5,0xff010
400168ac:	d0010113          	add	sp,sp,-768
400168b0:	f0078793          	add	a5,a5,-256 # ff00ff00 <_tbs_der_store_end+0xaeff0ee0>
400168b4:	c0be                	sw	a5,64(sp)
400168b6:	00ff07b7          	lui	a5,0xff0
400168ba:	0ff78793          	add	a5,a5,255 # ff00ff <mfdc+0xfef906>
400168be:	2f712023          	sw	s7,736(sp)
400168c2:	2e812e23          	sw	s0,764(sp)
400168c6:	2e912c23          	sw	s1,760(sp)
400168ca:	2f212a23          	sw	s2,756(sp)
400168ce:	2f312823          	sw	s3,752(sp)
400168d2:	2f412623          	sw	s4,748(sp)
400168d6:	2f512423          	sw	s5,744(sp)
400168da:	2f612223          	sw	s6,740(sp)
400168de:	2d812e23          	sw	s8,732(sp)
400168e2:	2d912c23          	sw	s9,728(sp)
400168e6:	2da12a23          	sw	s10,724(sp)
400168ea:	2db12823          	sw	s11,720(sp)
400168ee:	c4aa                	sw	a0,72(sp)
400168f0:	c6ae                	sw	a1,76(sp)
400168f2:	4b81                	li	s7,0
400168f4:	c2be                	sw	a5,68(sp)
400168f6:	47b6                	lw	a5,76(sp)
400168f8:	02fbed63          	bltu	s7,a5,40016932 <sha384_core+0x8a>
400168fc:	2fc12403          	lw	s0,764(sp)
40016900:	2f812483          	lw	s1,760(sp)
40016904:	2f412903          	lw	s2,756(sp)
40016908:	2f012983          	lw	s3,752(sp)
4001690c:	2ec12a03          	lw	s4,748(sp)
40016910:	2e812a83          	lw	s5,744(sp)
40016914:	2e412b03          	lw	s6,740(sp)
40016918:	2e012b83          	lw	s7,736(sp)
4001691c:	2dc12c03          	lw	s8,732(sp)
40016920:	2d812c83          	lw	s9,728(sp)
40016924:	2d412d03          	lw	s10,724(sp)
40016928:	2d012d83          	lw	s11,720(sp)
4001692c:	30010113          	add	sp,sp,768
40016930:	8082                	ret
40016932:	47a6                	lw	a5,72(sp)
40016934:	4581                	li	a1,0
40016936:	01778533          	add	a0,a5,s7
4001693a:	00b507b3          	add	a5,a0,a1
4001693e:	43d4                	lw	a3,4(a5)
40016940:	0007a803          	lw	a6,0(a5)
40016944:	0106d713          	srl	a4,a3,0x10
40016948:	01081793          	sll	a5,a6,0x10
4001694c:	8fd9                	or	a5,a5,a4
4001694e:	7741                	lui	a4,0xffff0
40016950:	8f7d                	and	a4,a4,a5
40016952:	01085813          	srl	a6,a6,0x10
40016956:	07c2                	sll	a5,a5,0x10
40016958:	01076733          	or	a4,a4,a6
4001695c:	06c2                	sll	a3,a3,0x10
4001695e:	83c1                	srl	a5,a5,0x10
40016960:	8fd5                	or	a5,a5,a3
40016962:	0186d813          	srl	a6,a3,0x18
40016966:	00871693          	sll	a3,a4,0x8
4001696a:	4406                	lw	s0,64(sp)
4001696c:	01871893          	sll	a7,a4,0x18
40016970:	00d866b3          	or	a3,a6,a3
40016974:	00879813          	sll	a6,a5,0x8
40016978:	83a1                	srl	a5,a5,0x8
4001697a:	00887833          	and	a6,a6,s0
4001697e:	8ee1                	and	a3,a3,s0
40016980:	00f8e7b3          	or	a5,a7,a5
40016984:	4416                	lw	s0,68(sp)
40016986:	8321                	srl	a4,a4,0x8
40016988:	8fe1                	and	a5,a5,s0
4001698a:	8f61                	and	a4,a4,s0
4001698c:	05058413          	add	s0,a1,80 # 40000050 <mfdc+0x3ffff857>
40016990:	002408b3          	add	a7,s0,sp
40016994:	00f867b3          	or	a5,a6,a5
40016998:	8ed9                	or	a3,a3,a4
4001699a:	00f8a023          	sw	a5,0(a7)
4001699e:	00d8a223          	sw	a3,4(a7)
400169a2:	05a1                	add	a1,a1,8
400169a4:	08000793          	li	a5,128
400169a8:	f8f599e3          	bne	a1,a5,4001693a <sha384_core+0x92>
400169ac:	0894                	add	a3,sp,80
400169ae:	46cc                	lw	a1,12(a3)
400169b0:	4698                	lw	a4,8(a3)
400169b2:	00175813          	srl	a6,a4,0x1
400169b6:	01f59793          	sll	a5,a1,0x1f
400169ba:	0015d313          	srl	t1,a1,0x1
400169be:	0107e7b3          	or	a5,a5,a6
400169c2:	01f71813          	sll	a6,a4,0x1f
400169c6:	00686833          	or	a6,a6,t1
400169ca:	01859e13          	sll	t3,a1,0x18
400169ce:	00875313          	srl	t1,a4,0x8
400169d2:	006e6e33          	or	t3,t3,t1
400169d6:	0085de93          	srl	t4,a1,0x8
400169da:	01871313          	sll	t1,a4,0x18
400169de:	01d36333          	or	t1,t1,t4
400169e2:	00684833          	xor	a6,a6,t1
400169e6:	831d                	srl	a4,a4,0x7
400169e8:	01959313          	sll	t1,a1,0x19
400169ec:	00e36733          	or	a4,t1,a4
400169f0:	01c7c7b3          	xor	a5,a5,t3
400169f4:	819d                	srl	a1,a1,0x7
400169f6:	8fb9                	xor	a5,a5,a4
400169f8:	00b84833          	xor	a6,a6,a1
400169fc:	4298                	lw	a4,0(a3)
400169fe:	46ac                	lw	a1,72(a3)
40016a00:	04c6ae03          	lw	t3,76(a3)
40016a04:	0046a303          	lw	t1,4(a3)
40016a08:	95ba                	add	a1,a1,a4
40016a0a:	00e5b733          	sltu	a4,a1,a4
40016a0e:	9372                	add	t1,t1,t3
40016a10:	933a                	add	t1,t1,a4
40016a12:	95be                	add	a1,a1,a5
40016a14:	0746a883          	lw	a7,116(a3)
40016a18:	5aa8                	lw	a0,112(a3)
40016a1a:	00f5b7b3          	sltu	a5,a1,a5
40016a1e:	981a                	add	a6,a6,t1
40016a20:	01078733          	add	a4,a5,a6
40016a24:	01355813          	srl	a6,a0,0x13
40016a28:	00d89793          	sll	a5,a7,0xd
40016a2c:	0138d313          	srl	t1,a7,0x13
40016a30:	0107e7b3          	or	a5,a5,a6
40016a34:	00d51813          	sll	a6,a0,0xd
40016a38:	00686833          	or	a6,a6,t1
40016a3c:	01d8de13          	srl	t3,a7,0x1d
40016a40:	00351313          	sll	t1,a0,0x3
40016a44:	006e6e33          	or	t3,t3,t1
40016a48:	00389e93          	sll	t4,a7,0x3
40016a4c:	01d55313          	srl	t1,a0,0x1d
40016a50:	01d36333          	or	t1,t1,t4
40016a54:	00684833          	xor	a6,a6,t1
40016a58:	8119                	srl	a0,a0,0x6
40016a5a:	01a89313          	sll	t1,a7,0x1a
40016a5e:	00a36533          	or	a0,t1,a0
40016a62:	01c7c7b3          	xor	a5,a5,t3
40016a66:	8fa9                	xor	a5,a5,a0
40016a68:	0068d893          	srl	a7,a7,0x6
40016a6c:	97ae                	add	a5,a5,a1
40016a6e:	01184533          	xor	a0,a6,a7
40016a72:	00b7b5b3          	sltu	a1,a5,a1
40016a76:	972a                	add	a4,a4,a0
40016a78:	95ba                	add	a1,a1,a4
40016a7a:	08068713          	add	a4,a3,128
40016a7e:	c31c                	sw	a5,0(a4)
40016a80:	c34c                	sw	a1,4(a4)
40016a82:	06a1                	add	a3,a3,8
40016a84:	0c9c                	add	a5,sp,592
40016a86:	f2d794e3          	bne	a5,a3,400169ae <sha384_core+0x106>
40016a8a:	425c                	lw	a5,4(a2)
40016a8c:	cc3e                	sw	a5,24(sp)
40016a8e:	465c                	lw	a5,12(a2)
40016a90:	ce3e                	sw	a5,28(sp)
40016a92:	4a5c                	lw	a5,20(a2)
40016a94:	d03e                	sw	a5,32(sp)
40016a96:	4e1c                	lw	a5,24(a2)
40016a98:	c23e                	sw	a5,4(sp)
40016a9a:	4e5c                	lw	a5,28(a2)
40016a9c:	d23e                	sw	a5,36(sp)
40016a9e:	521c                	lw	a5,32(a2)
40016aa0:	c43e                	sw	a5,8(sp)
40016aa2:	525c                	lw	a5,36(a2)
40016aa4:	d43e                	sw	a5,40(sp)
40016aa6:	561c                	lw	a5,40(a2)
40016aa8:	c63e                	sw	a5,12(sp)
40016aaa:	565c                	lw	a5,44(a2)
40016aac:	d63e                	sw	a5,44(sp)
40016aae:	5a1c                	lw	a5,48(a2)
40016ab0:	c83e                	sw	a5,16(sp)
40016ab2:	5a5c                	lw	a5,52(a2)
40016ab4:	d83e                	sw	a5,48(sp)
40016ab6:	5e1c                	lw	a5,56(a2)
40016ab8:	ca3e                	sw	a5,20(sp)
40016aba:	5e5c                	lw	a5,60(a2)
40016abc:	4204                	lw	s1,0(a2)
40016abe:	4600                	lw	s0,8(a2)
40016ac0:	01062383          	lw	t2,16(a2) # 1010 <mfdc+0x817>
40016ac4:	da3e                	sw	a5,52(sp)
40016ac6:	4352                	lw	t1,20(sp)
40016ac8:	8d3e                	mv	s10,a5
40016aca:	4fc2                	lw	t6,16(sp)
40016acc:	5c42                	lw	s8,48(sp)
40016ace:	42b2                	lw	t0,12(sp)
40016ad0:	4792                	lw	a5,4(sp)
40016ad2:	dc3e                	sw	a5,56(sp)
40016ad4:	5792                	lw	a5,36(sp)
40016ad6:	5cb2                	lw	s9,44(sp)
40016ad8:	46a2                	lw	a3,8(sp)
40016ada:	5522                	lw	a0,40(sp)
40016adc:	de3e                	sw	a5,60(sp)
40016ade:	8e9e                	mv	t4,t2
40016ae0:	5982                	lw	s3,32(sp)
40016ae2:	8f22                	mv	t5,s0
40016ae4:	4a72                	lw	s4,28(sp)
40016ae6:	85a6                	mv	a1,s1
40016ae8:	48e2                	lw	a7,24(sp)
40016aea:	4a81                	li	s5,0
40016aec:	500117b7          	lui	a5,0x50011
40016af0:	88078713          	add	a4,a5,-1920 # 50010880 <k>
40016af4:	050a8793          	add	a5,s5,80
40016af8:	9756                	add	a4,a4,s5
40016afa:	00278e33          	add	t3,a5,sp
40016afe:	00472803          	lw	a6,4(a4) # ffff0004 <_tbs_der_store_end+0xaffd0fe4>
40016b02:	431c                	lw	a5,0(a4)
40016b04:	000e2703          	lw	a4,0(t3)
40016b08:	973e                	add	a4,a4,a5
40016b0a:	004e2e03          	lw	t3,4(t3)
40016b0e:	9872                	add	a6,a6,t3
40016b10:	00f737b3          	sltu	a5,a4,a5
40016b14:	fff6cb13          	not	s6,a3
40016b18:	97c2                	add	a5,a5,a6
40016b1a:	01fb7b33          	and	s6,s6,t6
40016b1e:	fff54913          	not	s2,a0
40016b22:	0056f833          	and	a6,a3,t0
40016b26:	01897933          	and	s2,s2,s8
40016b2a:	010b4833          	xor	a6,s6,a6
40016b2e:	01957e33          	and	t3,a0,s9
40016b32:	01c94e33          	xor	t3,s2,t3
40016b36:	983a                	add	a6,a6,a4
40016b38:	97f2                	add	a5,a5,t3
40016b3a:	00e83733          	sltu	a4,a6,a4
40016b3e:	973e                	add	a4,a4,a5
40016b40:	01251913          	sll	s2,a0,0x12
40016b44:	00e6d793          	srl	a5,a3,0xe
40016b48:	00f96933          	or	s2,s2,a5
40016b4c:	01269e13          	sll	t3,a3,0x12
40016b50:	00e55793          	srl	a5,a0,0xe
40016b54:	00fe6e33          	or	t3,t3,a5
40016b58:	00e51b13          	sll	s6,a0,0xe
40016b5c:	0126d793          	srl	a5,a3,0x12
40016b60:	00fb6b33          	or	s6,s6,a5
40016b64:	01255d93          	srl	s11,a0,0x12
40016b68:	00e69793          	sll	a5,a3,0xe
40016b6c:	01b7e7b3          	or	a5,a5,s11
40016b70:	01694933          	xor	s2,s2,s6
40016b74:	00fe4e33          	xor	t3,t3,a5
40016b78:	01769b13          	sll	s6,a3,0x17
40016b7c:	00955793          	srl	a5,a0,0x9
40016b80:	0167e7b3          	or	a5,a5,s6
40016b84:	01751d93          	sll	s11,a0,0x17
40016b88:	0096db13          	srl	s6,a3,0x9
40016b8c:	01bb6b33          	or	s6,s6,s11
40016b90:	00f947b3          	xor	a5,s2,a5
40016b94:	016e4e33          	xor	t3,t3,s6
40016b98:	97c2                	add	a5,a5,a6
40016b9a:	0107b833          	sltu	a6,a5,a6
40016b9e:	9772                	add	a4,a4,t3
40016ba0:	933e                	add	t1,t1,a5
40016ba2:	9742                	add	a4,a4,a6
40016ba4:	976a                	add	a4,a4,s10
40016ba6:	00f337b3          	sltu	a5,t1,a5
40016baa:	97ba                	add	a5,a5,a4
40016bac:	00489813          	sll	a6,a7,0x4
40016bb0:	01c5d713          	srl	a4,a1,0x1c
40016bb4:	00e86833          	or	a6,a6,a4
40016bb8:	00459e13          	sll	t3,a1,0x4
40016bbc:	01c8d713          	srl	a4,a7,0x1c
40016bc0:	00ee6e33          	or	t3,t3,a4
40016bc4:	0028d913          	srl	s2,a7,0x2
40016bc8:	01e59713          	sll	a4,a1,0x1e
40016bcc:	00e96933          	or	s2,s2,a4
40016bd0:	01e89b13          	sll	s6,a7,0x1e
40016bd4:	0025d713          	srl	a4,a1,0x2
40016bd8:	01676733          	or	a4,a4,s6
40016bdc:	01284833          	xor	a6,a6,s2
40016be0:	00ee4e33          	xor	t3,t3,a4
40016be4:	0078d913          	srl	s2,a7,0x7
40016be8:	01959713          	sll	a4,a1,0x19
40016bec:	00e96933          	or	s2,s2,a4
40016bf0:	01989b13          	sll	s6,a7,0x19
40016bf4:	0075d713          	srl	a4,a1,0x7
40016bf8:	01676733          	or	a4,a4,s6
40016bfc:	01df4d33          	xor	s10,t5,t4
40016c00:	00ee4e33          	xor	t3,t3,a4
40016c04:	00bd7d33          	and	s10,s10,a1
40016c08:	013a4b33          	xor	s6,s4,s3
40016c0c:	01df7733          	and	a4,t5,t4
40016c10:	01284833          	xor	a6,a6,s2
40016c14:	011b7b33          	and	s6,s6,a7
40016c18:	00ed4733          	xor	a4,s10,a4
40016c1c:	013a7933          	and	s2,s4,s3
40016c20:	012b4933          	xor	s2,s6,s2
40016c24:	9742                	add	a4,a4,a6
40016c26:	9e4a                	add	t3,t3,s2
40016c28:	01073833          	sltu	a6,a4,a6
40016c2c:	9872                	add	a6,a6,t3
40016c2e:	5e62                	lw	t3,56(sp)
40016c30:	01c30933          	add	s2,t1,t3
40016c34:	971a                	add	a4,a4,t1
40016c36:	5e72                	lw	t3,60(sp)
40016c38:	00693b33          	sltu	s6,s2,t1
40016c3c:	9e3e                	add	t3,t3,a5
40016c3e:	00673333          	sltu	t1,a4,t1
40016c42:	97c2                	add	a5,a5,a6
40016c44:	0aa1                	add	s5,s5,8
40016c46:	dc76                	sw	t4,56(sp)
40016c48:	de4e                	sw	s3,60(sp)
40016c4a:	28000813          	li	a6,640
40016c4e:	979a                	add	a5,a5,t1
40016c50:	9b72                	add	s6,s6,t3
40016c52:	837e                	mv	t1,t6
40016c54:	8d62                	mv	s10,s8
40016c56:	0b0a9063          	bne	s5,a6,40016cf6 <sha384_core+0x44e>
40016c5a:	9726                	add	a4,a4,s1
40016c5c:	4862                	lw	a6,24(sp)
40016c5e:	009734b3          	sltu	s1,a4,s1
40016c62:	97c2                	add	a5,a5,a6
40016c64:	94be                	add	s1,s1,a5
40016c66:	95a2                	add	a1,a1,s0
40016c68:	47f2                	lw	a5,28(sp)
40016c6a:	97c6                	add	a5,a5,a7
40016c6c:	0085b433          	sltu	s0,a1,s0
40016c70:	943e                	add	s0,s0,a5
40016c72:	9f1e                	add	t5,t5,t2
40016c74:	5782                	lw	a5,32(sp)
40016c76:	97d2                	add	a5,a5,s4
40016c78:	007f33b3          	sltu	t2,t5,t2
40016c7c:	93be                	add	t2,t2,a5
40016c7e:	4792                	lw	a5,4(sp)
40016c80:	9ebe                	add	t4,t4,a5
40016c82:	c218                	sw	a4,0(a2)
40016c84:	5712                	lw	a4,36(sp)
40016c86:	974e                	add	a4,a4,s3
40016c88:	00feb7b3          	sltu	a5,t4,a5
40016c8c:	97ba                	add	a5,a5,a4
40016c8e:	ce5c                	sw	a5,28(a2)
40016c90:	47a2                	lw	a5,8(sp)
40016c92:	993e                	add	s2,s2,a5
40016c94:	5722                	lw	a4,40(sp)
40016c96:	975a                	add	a4,a4,s6
40016c98:	00f937b3          	sltu	a5,s2,a5
40016c9c:	97ba                	add	a5,a5,a4
40016c9e:	d25c                	sw	a5,36(a2)
40016ca0:	47b2                	lw	a5,12(sp)
40016ca2:	96be                	add	a3,a3,a5
40016ca4:	5732                	lw	a4,44(sp)
40016ca6:	972a                	add	a4,a4,a0
40016ca8:	00f6b7b3          	sltu	a5,a3,a5
40016cac:	97ba                	add	a5,a5,a4
40016cae:	d65c                	sw	a5,44(a2)
40016cb0:	47c2                	lw	a5,16(sp)
40016cb2:	92be                	add	t0,t0,a5
40016cb4:	5742                	lw	a4,48(sp)
40016cb6:	9766                	add	a4,a4,s9
40016cb8:	00f2b7b3          	sltu	a5,t0,a5
40016cbc:	97ba                	add	a5,a5,a4
40016cbe:	da5c                	sw	a5,52(a2)
40016cc0:	47d2                	lw	a5,20(sp)
40016cc2:	9fbe                	add	t6,t6,a5
40016cc4:	5752                	lw	a4,52(sp)
40016cc6:	00ffb7b3          	sltu	a5,t6,a5
40016cca:	9762                	add	a4,a4,s8
40016ccc:	97ba                	add	a5,a5,a4
40016cce:	c244                	sw	s1,4(a2)
40016cd0:	c60c                	sw	a1,8(a2)
40016cd2:	c640                	sw	s0,12(a2)
40016cd4:	01e62823          	sw	t5,16(a2)
40016cd8:	00762a23          	sw	t2,20(a2)
40016cdc:	01d62c23          	sw	t4,24(a2)
40016ce0:	03262023          	sw	s2,32(a2)
40016ce4:	d614                	sw	a3,40(a2)
40016ce6:	02562823          	sw	t0,48(a2)
40016cea:	03f62c23          	sw	t6,56(a2)
40016cee:	de5c                	sw	a5,60(a2)
40016cf0:	080b8b93          	add	s7,s7,128
40016cf4:	b109                	j	400168f6 <sha384_core+0x4e>
40016cf6:	8f96                	mv	t6,t0
40016cf8:	8c66                	mv	s8,s9
40016cfa:	82b6                	mv	t0,a3
40016cfc:	8caa                	mv	s9,a0
40016cfe:	8efa                	mv	t4,t5
40016d00:	89d2                	mv	s3,s4
40016d02:	8f2e                	mv	t5,a1
40016d04:	8a46                	mv	s4,a7
40016d06:	86ca                	mv	a3,s2
40016d08:	855a                	mv	a0,s6
40016d0a:	85ba                	mv	a1,a4
40016d0c:	88be                	mv	a7,a5
40016d0e:	bbf9                	j	40016aec <sha384_core+0x244>

40016d10 <sha384_digest>:
40016d10:	7129                	add	sp,sp,-320
40016d12:	12812c23          	sw	s0,312(sp)
40016d16:	01058413          	add	s0,a1,16
40016d1a:	13412423          	sw	s4,296(sp)
40016d1e:	13612023          	sw	s6,288(sp)
40016d22:	8a36                	mv	s4,a3
40016d24:	07f47b13          	and	s6,s0,127
40016d28:	08000693          	li	a3,128
40016d2c:	416686b3          	sub	a3,a3,s6
40016d30:	13312623          	sw	s3,300(sp)
40016d34:	07000993          	li	s3,112
40016d38:	00d9b9b3          	sltu	s3,s3,a3
40016d3c:	12912a23          	sw	s1,308(sp)
40016d40:	13212823          	sw	s2,304(sp)
40016d44:	11712e23          	sw	s7,284(sp)
40016d48:	099e                	sll	s3,s3,0x7
40016d4a:	12112e23          	sw	ra,316(sp)
40016d4e:	13512223          	sw	s5,292(sp)
40016d52:	11812c23          	sw	s8,280(sp)
40016d56:	8baa                	mv	s7,a0
40016d58:	84ae                	mv	s1,a1
40016d5a:	8932                	mv	s2,a2
40016d5c:	08098993          	add	s3,s3,128
40016d60:	9436                	add	s0,s0,a3
40016d62:	000a0b63          	beqz	s4,40016d78 <sha384_digest+0x68>
40016d66:	50010537          	lui	a0,0x50010
40016d6a:	862e                	mv	a2,a1
40016d6c:	874e                	mv	a4,s3
40016d6e:	85a2                	mv	a1,s0
40016d70:	7ac50513          	add	a0,a0,1964 # 500107ac <__func__.0+0x29c>
40016d74:	b16ff0ef          	jal	4001608a <printf>
40016d78:	500117b7          	lui	a5,0x50011
40016d7c:	2307a703          	lw	a4,560(a5) # 50011230 <__func__.2+0x5b0>
40016d80:	2347a783          	lw	a5,564(a5)
40016d84:	00f92223          	sw	a5,4(s2)
40016d88:	500117b7          	lui	a5,0x50011
40016d8c:	00e92023          	sw	a4,0(s2)
40016d90:	2387a703          	lw	a4,568(a5) # 50011238 <__func__.2+0x5b8>
40016d94:	23c7a783          	lw	a5,572(a5)
40016d98:	00f92623          	sw	a5,12(s2)
40016d9c:	500117b7          	lui	a5,0x50011
40016da0:	00e92423          	sw	a4,8(s2)
40016da4:	2407a703          	lw	a4,576(a5) # 50011240 <__func__.2+0x5c0>
40016da8:	2447a783          	lw	a5,580(a5)
40016dac:	00f92a23          	sw	a5,20(s2)
40016db0:	500117b7          	lui	a5,0x50011
40016db4:	00e92823          	sw	a4,16(s2)
40016db8:	2487a703          	lw	a4,584(a5) # 50011248 <__func__.2+0x5c8>
40016dbc:	24c7a783          	lw	a5,588(a5)
40016dc0:	00f92e23          	sw	a5,28(s2)
40016dc4:	500117b7          	lui	a5,0x50011
40016dc8:	00e92c23          	sw	a4,24(s2)
40016dcc:	2507a703          	lw	a4,592(a5) # 50011250 <__func__.2+0x5d0>
40016dd0:	2547a783          	lw	a5,596(a5)
40016dd4:	02f92223          	sw	a5,36(s2)
40016dd8:	500117b7          	lui	a5,0x50011
40016ddc:	02e92023          	sw	a4,32(s2)
40016de0:	2587a703          	lw	a4,600(a5) # 50011258 <__func__.2+0x5d8>
40016de4:	25c7a783          	lw	a5,604(a5)
40016de8:	02f92623          	sw	a5,44(s2)
40016dec:	500117b7          	lui	a5,0x50011
40016df0:	02e92423          	sw	a4,40(s2)
40016df4:	2607a703          	lw	a4,608(a5) # 50011260 <__func__.2+0x5e0>
40016df8:	2647a783          	lw	a5,612(a5)
40016dfc:	02f92a23          	sw	a5,52(s2)
40016e00:	500117b7          	lui	a5,0x50011
40016e04:	02e92823          	sw	a4,48(s2)
40016e08:	41340c33          	sub	s8,s0,s3
40016e0c:	2687a703          	lw	a4,616(a5) # 50011268 <__func__.2+0x5e8>
40016e10:	26c7a783          	lw	a5,620(a5)
40016e14:	02e92c23          	sw	a4,56(s2)
40016e18:	02f92e23          	sw	a5,60(s2)
40016e1c:	864a                	mv	a2,s2
40016e1e:	85e2                	mv	a1,s8
40016e20:	855e                	mv	a0,s7
40016e22:	a87ff0ef          	jal	400168a8 <sha384_core>
40016e26:	000a0863          	beqz	s4,40016e36 <sha384_digest+0x126>
40016e2a:	50011537          	lui	a0,0x50011
40016e2e:	80050513          	add	a0,a0,-2048 # 50010800 <__func__.0+0x2f0>
40016e32:	a56ff0ef          	jal	40016088 <puts>
40016e36:	40848433          	sub	s0,s1,s0
40016e3a:	944e                	add	s0,s0,s3
40016e3c:	01010a93          	add	s5,sp,16
40016e40:	8622                	mv	a2,s0
40016e42:	018b85b3          	add	a1,s7,s8
40016e46:	8556                	mv	a0,s5
40016e48:	29e020ef          	jal	400190e6 <memcpy>
40016e4c:	11040793          	add	a5,s0,272
40016e50:	978a                	add	a5,a5,sp
40016e52:	f8000713          	li	a4,-128
40016e56:	00140513          	add	a0,s0,1
40016e5a:	41640433          	sub	s0,s0,s6
40016e5e:	f0e78023          	sb	a4,-256(a5)
40016e62:	08840413          	add	s0,s0,136
40016e66:	4601                	li	a2,0
40016e68:	00a46663          	bltu	s0,a0,40016e74 <sha384_digest+0x164>
40016e6c:	08700613          	li	a2,135
40016e70:	41660633          	sub	a2,a2,s6
40016e74:	4581                	li	a1,0
40016e76:	9556                	add	a0,a0,s5
40016e78:	1c6020ef          	jal	4001903e <memset>
40016e7c:	00349793          	sll	a5,s1,0x3
40016e80:	83c1                	srl	a5,a5,0x10
40016e82:	04ce                	sll	s1,s1,0x13
40016e84:	8cdd                	or	s1,s1,a5
40016e86:	ff010737          	lui	a4,0xff010
40016e8a:	00849793          	sll	a5,s1,0x8
40016e8e:	f0070713          	add	a4,a4,-256 # ff00ff00 <_tbs_der_store_end+0xaeff0ee0>
40016e92:	8ff9                	and	a5,a5,a4
40016e94:	00ff0737          	lui	a4,0xff0
40016e98:	80a1                	srl	s1,s1,0x8
40016e9a:	0ff70713          	add	a4,a4,255 # ff00ff <mfdc+0xfef906>
40016e9e:	8cf9                	and	s1,s1,a4
40016ea0:	4621                	li	a2,8
40016ea2:	8fc5                	or	a5,a5,s1
40016ea4:	00c105b3          	add	a1,sp,a2
40016ea8:	008a8533          	add	a0,s5,s0
40016eac:	c402                	sw	zero,8(sp)
40016eae:	c63e                	sw	a5,12(sp)
40016eb0:	236020ef          	jal	400190e6 <memcpy>
40016eb4:	000a0863          	beqz	s4,40016ec4 <sha384_digest+0x1b4>
40016eb8:	50011537          	lui	a0,0x50011
40016ebc:	83050513          	add	a0,a0,-2000 # 50010830 <__func__.0+0x320>
40016ec0:	9c8ff0ef          	jal	40016088 <puts>
40016ec4:	864a                	mv	a2,s2
40016ec6:	85ce                	mv	a1,s3
40016ec8:	8556                	mv	a0,s5
40016eca:	9dfff0ef          	jal	400168a8 <sha384_core>
40016ece:	020a0d63          	beqz	s4,40016f08 <sha384_digest+0x1f8>
40016ed2:	13812403          	lw	s0,312(sp)
40016ed6:	50011537          	lui	a0,0x50011
40016eda:	13c12083          	lw	ra,316(sp)
40016ede:	13412483          	lw	s1,308(sp)
40016ee2:	13012903          	lw	s2,304(sp)
40016ee6:	12c12983          	lw	s3,300(sp)
40016eea:	12812a03          	lw	s4,296(sp)
40016eee:	12412a83          	lw	s5,292(sp)
40016ef2:	12012b03          	lw	s6,288(sp)
40016ef6:	11c12b83          	lw	s7,284(sp)
40016efa:	11812c03          	lw	s8,280(sp)
40016efe:	85050513          	add	a0,a0,-1968 # 50010850 <__func__.0+0x340>
40016f02:	6131                	add	sp,sp,320
40016f04:	984ff06f          	j	40016088 <puts>
40016f08:	13c12083          	lw	ra,316(sp)
40016f0c:	13812403          	lw	s0,312(sp)
40016f10:	13412483          	lw	s1,308(sp)
40016f14:	13012903          	lw	s2,304(sp)
40016f18:	12c12983          	lw	s3,300(sp)
40016f1c:	12812a03          	lw	s4,296(sp)
40016f20:	12412a83          	lw	s5,292(sp)
40016f24:	12012b03          	lw	s6,288(sp)
40016f28:	11c12b83          	lw	s7,284(sp)
40016f2c:	11812c03          	lw	s8,280(sp)
40016f30:	6131                	add	sp,sp,320
40016f32:	8082                	ret

40016f34 <delay_second.constprop.0>:
40016f34:	300305b7          	lui	a1,0x30030
40016f38:	64058593          	add	a1,a1,1600 # 30030640 <mfdc+0x3002fe47>
40016f3c:	02626737          	lui	a4,0x2626
40016f40:	4190                	lw	a2,0(a1)
40016f42:	a0070713          	add	a4,a4,-1536 # 2625a00 <mfdc+0x2625207>
40016f46:	9732                	add	a4,a4,a2
40016f48:	41d4                	lw	a3,4(a1)
40016f4a:	00c737b3          	sltu	a5,a4,a2
40016f4e:	863a                	mv	a2,a4
40016f50:	30030737          	lui	a4,0x30030
40016f54:	97b6                	add	a5,a5,a3
40016f56:	64c72423          	sw	a2,1608(a4) # 30030648 <mfdc+0x3002fe4f>
40016f5a:	64f72623          	sw	a5,1612(a4)
40016f5e:	0005a803          	lw	a6,0(a1)
40016f62:	0045a883          	lw	a7,4(a1)
40016f66:	00f8e763          	bltu	a7,a5,40016f74 <delay_second.constprop.0+0x40>
40016f6a:	01179463          	bne	a5,a7,40016f72 <delay_second.constprop.0+0x3e>
40016f6e:	00c86363          	bltu	a6,a2,40016f74 <delay_second.constprop.0+0x40>
40016f72:	8082                	ret
40016f74:	10500073          	wfi
40016f78:	b7dd                	j	40016f5e <delay_second.constprop.0+0x2a>

40016f7a <sha_init>:
40016f7a:	1141                	add	sp,sp,-16
40016f7c:	c422                	sw	s0,8(sp)
40016f7e:	842a                	mv	s0,a0
40016f80:	85aa                	mv	a1,a0
40016f82:	040a                	sll	s0,s0,0x2
40016f84:	50011537          	lui	a0,0x50011
40016f88:	b0050513          	add	a0,a0,-1280 # 50010b00 <k+0x280>
40016f8c:	8831                	and	s0,s0,12
40016f8e:	c606                	sw	ra,12(sp)
40016f90:	00146413          	or	s0,s0,1
40016f94:	8f6ff0ef          	jal	4001608a <printf>
40016f98:	0220000f          	fence	r,r
40016f9c:	0220000f          	fence	r,r
40016fa0:	100207b7          	lui	a5,0x10020
40016fa4:	cb80                	sw	s0,16(a5)
40016fa6:	40b2                	lw	ra,12(sp)
40016fa8:	4422                	lw	s0,8(sp)
40016faa:	0141                	add	sp,sp,16
40016fac:	8082                	ret

40016fae <sha_next>:
40016fae:	1141                	add	sp,sp,-16
40016fb0:	c422                	sw	s0,8(sp)
40016fb2:	842a                	mv	s0,a0
40016fb4:	85aa                	mv	a1,a0
40016fb6:	040a                	sll	s0,s0,0x2
40016fb8:	50011537          	lui	a0,0x50011
40016fbc:	b2450513          	add	a0,a0,-1244 # 50010b24 <k+0x2a4>
40016fc0:	8831                	and	s0,s0,12
40016fc2:	c606                	sw	ra,12(sp)
40016fc4:	00246413          	or	s0,s0,2
40016fc8:	8c2ff0ef          	jal	4001608a <printf>
40016fcc:	0220000f          	fence	r,r
40016fd0:	0220000f          	fence	r,r
40016fd4:	100207b7          	lui	a5,0x10020
40016fd8:	cb80                	sw	s0,16(a5)
40016fda:	40b2                	lw	ra,12(sp)
40016fdc:	4422                	lw	s0,8(sp)
40016fde:	0141                	add	sp,sp,16
40016fe0:	8082                	ret

40016fe2 <sha_next_last>:
40016fe2:	1141                	add	sp,sp,-16
40016fe4:	c422                	sw	s0,8(sp)
40016fe6:	842a                	mv	s0,a0
40016fe8:	85aa                	mv	a1,a0
40016fea:	040a                	sll	s0,s0,0x2
40016fec:	50011537          	lui	a0,0x50011
40016ff0:	b4850513          	add	a0,a0,-1208 # 50010b48 <k+0x2c8>
40016ff4:	8831                	and	s0,s0,12
40016ff6:	c606                	sw	ra,12(sp)
40016ff8:	02246413          	or	s0,s0,34
40016ffc:	88eff0ef          	jal	4001608a <printf>
40017000:	0220000f          	fence	r,r
40017004:	0220000f          	fence	r,r
40017008:	100207b7          	lui	a5,0x10020
4001700c:	cb80                	sw	s0,16(a5)
4001700e:	40b2                	lw	ra,12(sp)
40017010:	4422                	lw	s0,8(sp)
40017012:	0141                	add	sp,sp,16
40017014:	8082                	ret

40017016 <measure_soc>:
40017016:	710d                	add	sp,sp,-352
40017018:	14912a23          	sw	s1,340(sp)
4001701c:	84ae                	mv	s1,a1
4001701e:	500105b7          	lui	a1,0x50010
40017022:	15612023          	sw	s6,320(sp)
40017026:	04000613          	li	a2,64
4001702a:	00058593          	mv	a1,a1
4001702e:	8b2a                	mv	s6,a0
40017030:	1008                	add	a0,sp,32
40017032:	14112e23          	sw	ra,348(sp)
40017036:	14812c23          	sw	s0,344(sp)
4001703a:	15212823          	sw	s2,336(sp)
4001703e:	15312623          	sw	s3,332(sp)
40017042:	15412423          	sw	s4,328(sp)
40017046:	15512223          	sw	s5,324(sp)
4001704a:	13712e23          	sw	s7,316(sp)
4001704e:	13812c23          	sw	s8,312(sp)
40017052:	13912a23          	sw	s9,308(sp)
40017056:	13a12823          	sw	s10,304(sp)
4001705a:	13b12623          	sw	s11,300(sp)
4001705e:	088020ef          	jal	400190e6 <memcpy>
40017062:	08000613          	li	a2,128
40017066:	4581                	li	a1,0
40017068:	1108                	add	a0,sp,160
4001706a:	c802                	sw	zero,16(sp)
4001706c:	ca02                	sw	zero,20(sp)
4001706e:	cc02                	sw	zero,24(sp)
40017070:	ce02                	sw	zero,28(sp)
40017072:	06010993          	add	s3,sp,96
40017076:	7c9010ef          	jal	4001903e <memset>
4001707a:	04000613          	li	a2,64
4001707e:	4581                	li	a1,0
40017080:	854e                	mv	a0,s3
40017082:	7bd010ef          	jal	4001903e <memset>
40017086:	500115b7          	lui	a1,0x50011
4001708a:	50010537          	lui	a0,0x50010
4001708e:	0e300613          	li	a2,227
40017092:	c8058593          	add	a1,a1,-896 # 50010c80 <__func__.2>
40017096:	16450513          	add	a0,a0,356 # 50010164 <trap_msg+0x7c>
4001709a:	ff1fe0ef          	jal	4001608a <printf>
4001709e:	01d4da93          	srl	s5,s1,0x1d
400170a2:	00349b93          	sll	s7,s1,0x3
400170a6:	01010913          	add	s2,sp,16
400170aa:	4401                	li	s0,0
400170ac:	04000a13          	li	s4,64
400170b0:	8622                	mv	a2,s0
400170b2:	855e                	mv	a0,s7
400170b4:	85d6                	mv	a1,s5
400170b6:	695010ef          	jal	40018f4a <__lshrdi3>
400170ba:	00a907a3          	sb	a0,15(s2)
400170be:	0421                	add	s0,s0,8
400170c0:	197d                	add	s2,s2,-1
400170c2:	ff4417e3          	bne	s0,s4,400170b0 <measure_soc+0x9a>
400170c6:	09048a13          	add	s4,s1,144
400170ca:	10020737          	lui	a4,0x10020
400170ce:	f80a7a13          	and	s4,s4,-128
400170d2:	0761                	add	a4,a4,24 # 10020018 <mfdc+0x1001f81f>
400170d4:	431c                	lw	a5,0(a4)
400170d6:	8b85                	and	a5,a5,1
400170d8:	dff5                	beqz	a5,400170d4 <measure_soc+0xbe>
400170da:	450d                	li	a0,3
400170dc:	3d79                	jal	40016f7a <sha_init>
400170de:	4a81                	li	s5,0
400170e0:	4b81                	li	s7,0
400170e2:	4401                	li	s0,0
400170e4:	08000c13          	li	s8,128
400170e8:	f8000c93          	li	s9,-128
400170ec:	07f00d13          	li	s10,127
400170f0:	4dbd                	li	s11,15
400170f2:	01447c63          	bgeu	s0,s4,4001710a <measure_soc+0xf4>
400170f6:	08000613          	li	a2,128
400170fa:	4581                	li	a1,0
400170fc:	1108                	add	a0,sp,160
400170fe:	741010ef          	jal	4001903e <memset>
40017102:	408487b3          	sub	a5,s1,s0
40017106:	0ef4fd63          	bgeu	s1,a5,40017200 <measure_soc+0x1ea>
4001710a:	352d                	jal	40016f34 <delay_second.constprop.0>
4001710c:	100207b7          	lui	a5,0x10020
40017110:	10020737          	lui	a4,0x10020
40017114:	894e                	mv	s2,s3
40017116:	86ce                	mv	a3,s3
40017118:	10078793          	add	a5,a5,256 # 10020100 <mfdc+0x1001f907>
4001711c:	14070713          	add	a4,a4,320 # 10020140 <mfdc+0x1001f947>
40017120:	863e                	mv	a2,a5
40017122:	4210                	lw	a2,0(a2)
40017124:	c290                	sw	a2,0(a3)
40017126:	0791                	add	a5,a5,4
40017128:	0691                	add	a3,a3,4
4001712a:	fee79be3          	bne	a5,a4,40017120 <measure_soc+0x10a>
4001712e:	50011537          	lui	a0,0x50011
40017132:	b7450513          	add	a0,a0,-1164 # 50010b74 <k+0x2f4>
40017136:	f53fe0ef          	jal	40016088 <puts>
4001713a:	04098493          	add	s1,s3,64
4001713e:	844e                	mv	s0,s3
40017140:	50011a37          	lui	s4,0x50011
40017144:	400c                	lw	a1,0(s0)
40017146:	b90a0513          	add	a0,s4,-1136 # 50010b90 <k+0x310>
4001714a:	0411                	add	s0,s0,4
4001714c:	f3ffe0ef          	jal	4001608a <printf>
40017150:	fe849ae3          	bne	s1,s0,40017144 <measure_soc+0x12e>
40017154:	4529                	li	a0,10
40017156:	f2dfe0ef          	jal	40016082 <putchar>
4001715a:	50011537          	lui	a0,0x50011
4001715e:	b9850513          	add	a0,a0,-1128 # 50010b98 <k+0x318>
40017162:	1000                	add	s0,sp,32
40017164:	f25fe0ef          	jal	40016088 <puts>
40017168:	84a2                	mv	s1,s0
4001716a:	408c                	lw	a1,0(s1)
4001716c:	b90a0513          	add	a0,s4,-1136
40017170:	0491                	add	s1,s1,4
40017172:	f19fe0ef          	jal	4001608a <printf>
40017176:	fe999ae3          	bne	s3,s1,4001716a <measure_soc+0x154>
4001717a:	4529                	li	a0,10
4001717c:	f07fe0ef          	jal	40016082 <putchar>
40017180:	50011537          	lui	a0,0x50011
40017184:	bb450513          	add	a0,a0,-1100 # 50010bb4 <k+0x334>
40017188:	f01fe0ef          	jal	40016088 <puts>
4001718c:	4481                	li	s1,0
4001718e:	4785                	li	a5,1
40017190:	50011a37          	lui	s4,0x50011
40017194:	49c1                	li	s3,16
40017196:	00092603          	lw	a2,0(s2)
4001719a:	4014                	lw	a3,0(s0)
4001719c:	00d60863          	beq	a2,a3,400171ac <measure_soc+0x196>
400171a0:	85a6                	mv	a1,s1
400171a2:	bd0a0513          	add	a0,s4,-1072 # 50010bd0 <k+0x350>
400171a6:	ee5fe0ef          	jal	4001608a <printf>
400171aa:	4781                	li	a5,0
400171ac:	0485                	add	s1,s1,1
400171ae:	0911                	add	s2,s2,4
400171b0:	0411                	add	s0,s0,4
400171b2:	ff3492e3          	bne	s1,s3,40017196 <measure_soc+0x180>
400171b6:	0e078463          	beqz	a5,4001729e <measure_soc+0x288>
400171ba:	50011537          	lui	a0,0x50011
400171be:	c1050513          	add	a0,a0,-1008 # 50010c10 <k+0x390>
400171c2:	ec7fe0ef          	jal	40016088 <puts>
400171c6:	4501                	li	a0,0
400171c8:	15c12083          	lw	ra,348(sp)
400171cc:	15812403          	lw	s0,344(sp)
400171d0:	15412483          	lw	s1,340(sp)
400171d4:	15012903          	lw	s2,336(sp)
400171d8:	14c12983          	lw	s3,332(sp)
400171dc:	14812a03          	lw	s4,328(sp)
400171e0:	14412a83          	lw	s5,324(sp)
400171e4:	14012b03          	lw	s6,320(sp)
400171e8:	13c12b83          	lw	s7,316(sp)
400171ec:	13812c03          	lw	s8,312(sp)
400171f0:	13412c83          	lw	s9,308(sp)
400171f4:	13012d03          	lw	s10,304(sp)
400171f8:	12c12d83          	lw	s11,300(sp)
400171fc:	6135                	add	sp,sp,352
400171fe:	8082                	ret
40017200:	cfbd                	beqz	a5,4001727e <measure_soc+0x268>
40017202:	893e                	mv	s2,a5
40017204:	00fc7463          	bgeu	s8,a5,4001720c <measure_soc+0x1f6>
40017208:	08000913          	li	s2,128
4001720c:	008b05b3          	add	a1,s6,s0
40017210:	864a                	mv	a2,s2
40017212:	1108                	add	a0,sp,160
40017214:	c63e                	sw	a5,12(sp)
40017216:	6d1010ef          	jal	400190e6 <memcpy>
4001721a:	47b2                	lw	a5,12(sp)
4001721c:	944a                	add	s0,s0,s2
4001721e:	02fd6463          	bltu	s10,a5,40017246 <measure_soc+0x230>
40017222:	11090793          	add	a5,s2,272
40017226:	0818                	add	a4,sp,16
40017228:	97ba                	add	a5,a5,a4
4001722a:	f9978023          	sb	s9,-128(a5)
4001722e:	412d0933          	sub	s2,s10,s2
40017232:	4b85                	li	s7,1
40017234:	012df963          	bgeu	s11,s2,40017246 <measure_soc+0x230>
40017238:	4641                	li	a2,16
4001723a:	85ba                	mv	a1,a4
4001723c:	0a08                	add	a0,sp,272
4001723e:	6a9010ef          	jal	400190e6 <memcpy>
40017242:	08040413          	add	s0,s0,128
40017246:	100207b7          	lui	a5,0x10020
4001724a:	10020737          	lui	a4,0x10020
4001724e:	1114                	add	a3,sp,160
40017250:	08078793          	add	a5,a5,128 # 10020080 <mfdc+0x1001f887>
40017254:	10070713          	add	a4,a4,256 # 10020100 <mfdc+0x1001f907>
40017258:	863e                	mv	a2,a5
4001725a:	428c                	lw	a1,0(a3)
4001725c:	0791                	add	a5,a5,4
4001725e:	c20c                	sw	a1,0(a2)
40017260:	0691                	add	a3,a3,4
40017262:	fee79be3          	bne	a5,a4,40017258 <measure_soc+0x242>
40017266:	450d                	li	a0,3
40017268:	020a9563          	bnez	s5,40017292 <measure_soc+0x27c>
4001726c:	3339                	jal	40016f7a <sha_init>
4001726e:	10020737          	lui	a4,0x10020
40017272:	0a85                	add	s5,s5,1
40017274:	0761                	add	a4,a4,24 # 10020018 <mfdc+0x1001f81f>
40017276:	431c                	lw	a5,0(a4)
40017278:	8b89                	and	a5,a5,2
4001727a:	dff5                	beqz	a5,40017276 <measure_soc+0x260>
4001727c:	bd9d                	j	400170f2 <measure_soc+0xdc>
4001727e:	000b8463          	beqz	s7,40017286 <measure_soc+0x270>
40017282:	01849463          	bne	s1,s8,4001728a <measure_soc+0x274>
40017286:	0b910023          	sb	s9,160(sp)
4001728a:	4641                	li	a2,16
4001728c:	00c105b3          	add	a1,sp,a2
40017290:	b775                	j	4001723c <measure_soc+0x226>
40017292:	01447463          	bgeu	s0,s4,4001729a <measure_soc+0x284>
40017296:	3b21                	jal	40016fae <sha_next>
40017298:	bfd9                	j	4001726e <measure_soc+0x258>
4001729a:	33a1                	jal	40016fe2 <sha_next_last>
4001729c:	bfc9                	j	4001726e <measure_soc+0x258>
4001729e:	50011537          	lui	a0,0x50011
400172a2:	c2850513          	add	a0,a0,-984 # 50010c28 <k+0x3a8>
400172a6:	de3fe0ef          	jal	40016088 <puts>
400172aa:	557d                	li	a0,-1
400172ac:	bf31                	j	400171c8 <measure_soc+0x1b2>

400172ae <measure_fmc>:
400172ae:	710d                	add	sp,sp,-352
400172b0:	14912a23          	sw	s1,340(sp)
400172b4:	84ae                	mv	s1,a1
400172b6:	500105b7          	lui	a1,0x50010
400172ba:	15612023          	sw	s6,320(sp)
400172be:	04000613          	li	a2,64
400172c2:	08058593          	add	a1,a1,128 # 50010080 <_data_vma_start+0x80>
400172c6:	8b2a                	mv	s6,a0
400172c8:	1008                	add	a0,sp,32
400172ca:	14112e23          	sw	ra,348(sp)
400172ce:	14812c23          	sw	s0,344(sp)
400172d2:	15212823          	sw	s2,336(sp)
400172d6:	15312623          	sw	s3,332(sp)
400172da:	15412423          	sw	s4,328(sp)
400172de:	15512223          	sw	s5,324(sp)
400172e2:	13712e23          	sw	s7,316(sp)
400172e6:	13812c23          	sw	s8,312(sp)
400172ea:	13912a23          	sw	s9,308(sp)
400172ee:	13a12823          	sw	s10,304(sp)
400172f2:	13b12623          	sw	s11,300(sp)
400172f6:	5f1010ef          	jal	400190e6 <memcpy>
400172fa:	08000613          	li	a2,128
400172fe:	4581                	li	a1,0
40017300:	1108                	add	a0,sp,160
40017302:	c802                	sw	zero,16(sp)
40017304:	ca02                	sw	zero,20(sp)
40017306:	cc02                	sw	zero,24(sp)
40017308:	ce02                	sw	zero,28(sp)
4001730a:	06010993          	add	s3,sp,96
4001730e:	531010ef          	jal	4001903e <memset>
40017312:	04000613          	li	a2,64
40017316:	4581                	li	a1,0
40017318:	854e                	mv	a0,s3
4001731a:	525010ef          	jal	4001903e <memset>
4001731e:	500115b7          	lui	a1,0x50011
40017322:	50010537          	lui	a0,0x50010
40017326:	1e700613          	li	a2,487
4001732a:	c7458593          	add	a1,a1,-908 # 50010c74 <__func__.0>
4001732e:	16450513          	add	a0,a0,356 # 50010164 <trap_msg+0x7c>
40017332:	d59fe0ef          	jal	4001608a <printf>
40017336:	01d4da93          	srl	s5,s1,0x1d
4001733a:	00349b93          	sll	s7,s1,0x3
4001733e:	01010913          	add	s2,sp,16
40017342:	4401                	li	s0,0
40017344:	04000a13          	li	s4,64
40017348:	8622                	mv	a2,s0
4001734a:	855e                	mv	a0,s7
4001734c:	85d6                	mv	a1,s5
4001734e:	3fd010ef          	jal	40018f4a <__lshrdi3>
40017352:	00a907a3          	sb	a0,15(s2)
40017356:	0421                	add	s0,s0,8
40017358:	197d                	add	s2,s2,-1
4001735a:	ff4417e3          	bne	s0,s4,40017348 <measure_fmc+0x9a>
4001735e:	09048a13          	add	s4,s1,144
40017362:	10020737          	lui	a4,0x10020
40017366:	f80a7a13          	and	s4,s4,-128
4001736a:	0761                	add	a4,a4,24 # 10020018 <mfdc+0x1001f81f>
4001736c:	431c                	lw	a5,0(a4)
4001736e:	8b85                	and	a5,a5,1
40017370:	dff5                	beqz	a5,4001736c <measure_fmc+0xbe>
40017372:	4a81                	li	s5,0
40017374:	4b81                	li	s7,0
40017376:	4401                	li	s0,0
40017378:	08000c13          	li	s8,128
4001737c:	f8000c93          	li	s9,-128
40017380:	07f00d13          	li	s10,127
40017384:	4dbd                	li	s11,15
40017386:	01447c63          	bgeu	s0,s4,4001739e <measure_fmc+0xf0>
4001738a:	08000613          	li	a2,128
4001738e:	4581                	li	a1,0
40017390:	1108                	add	a0,sp,160
40017392:	4ad010ef          	jal	4001903e <memset>
40017396:	408487b3          	sub	a5,s1,s0
4001739a:	0ef4fe63          	bgeu	s1,a5,40017496 <measure_fmc+0x1e8>
4001739e:	b97ff0ef          	jal	40016f34 <delay_second.constprop.0>
400173a2:	100207b7          	lui	a5,0x10020
400173a6:	10020737          	lui	a4,0x10020
400173aa:	894e                	mv	s2,s3
400173ac:	86ce                	mv	a3,s3
400173ae:	10078793          	add	a5,a5,256 # 10020100 <mfdc+0x1001f907>
400173b2:	14070713          	add	a4,a4,320 # 10020140 <mfdc+0x1001f947>
400173b6:	863e                	mv	a2,a5
400173b8:	4210                	lw	a2,0(a2)
400173ba:	c290                	sw	a2,0(a3)
400173bc:	0791                	add	a5,a5,4
400173be:	0691                	add	a3,a3,4
400173c0:	fee79be3          	bne	a5,a4,400173b6 <measure_fmc+0x108>
400173c4:	50011537          	lui	a0,0x50011
400173c8:	c3c50513          	add	a0,a0,-964 # 50010c3c <k+0x3bc>
400173cc:	cbdfe0ef          	jal	40016088 <puts>
400173d0:	04098493          	add	s1,s3,64
400173d4:	844e                	mv	s0,s3
400173d6:	50011a37          	lui	s4,0x50011
400173da:	400c                	lw	a1,0(s0)
400173dc:	b90a0513          	add	a0,s4,-1136 # 50010b90 <k+0x310>
400173e0:	0411                	add	s0,s0,4
400173e2:	ca9fe0ef          	jal	4001608a <printf>
400173e6:	fe849ae3          	bne	s1,s0,400173da <measure_fmc+0x12c>
400173ea:	4529                	li	a0,10
400173ec:	c97fe0ef          	jal	40016082 <putchar>
400173f0:	50011537          	lui	a0,0x50011
400173f4:	c5850513          	add	a0,a0,-936 # 50010c58 <k+0x3d8>
400173f8:	1000                	add	s0,sp,32
400173fa:	c8ffe0ef          	jal	40016088 <puts>
400173fe:	84a2                	mv	s1,s0
40017400:	408c                	lw	a1,0(s1)
40017402:	b90a0513          	add	a0,s4,-1136
40017406:	0491                	add	s1,s1,4
40017408:	c83fe0ef          	jal	4001608a <printf>
4001740c:	fe999ae3          	bne	s3,s1,40017400 <measure_fmc+0x152>
40017410:	4529                	li	a0,10
40017412:	c71fe0ef          	jal	40016082 <putchar>
40017416:	50011537          	lui	a0,0x50011
4001741a:	bb450513          	add	a0,a0,-1100 # 50010bb4 <k+0x334>
4001741e:	c6bfe0ef          	jal	40016088 <puts>
40017422:	4481                	li	s1,0
40017424:	4785                	li	a5,1
40017426:	50011a37          	lui	s4,0x50011
4001742a:	49c1                	li	s3,16
4001742c:	00092603          	lw	a2,0(s2)
40017430:	4014                	lw	a3,0(s0)
40017432:	00d60863          	beq	a2,a3,40017442 <measure_fmc+0x194>
40017436:	85a6                	mv	a1,s1
40017438:	bd0a0513          	add	a0,s4,-1072 # 50010bd0 <k+0x350>
4001743c:	c4ffe0ef          	jal	4001608a <printf>
40017440:	4781                	li	a5,0
40017442:	0485                	add	s1,s1,1
40017444:	0911                	add	s2,s2,4
40017446:	0411                	add	s0,s0,4
40017448:	ff3492e3          	bne	s1,s3,4001742c <measure_fmc+0x17e>
4001744c:	0e078763          	beqz	a5,4001753a <measure_fmc+0x28c>
40017450:	50011537          	lui	a0,0x50011
40017454:	c1050513          	add	a0,a0,-1008 # 50010c10 <k+0x390>
40017458:	c31fe0ef          	jal	40016088 <puts>
4001745c:	4501                	li	a0,0
4001745e:	15c12083          	lw	ra,348(sp)
40017462:	15812403          	lw	s0,344(sp)
40017466:	15412483          	lw	s1,340(sp)
4001746a:	15012903          	lw	s2,336(sp)
4001746e:	14c12983          	lw	s3,332(sp)
40017472:	14812a03          	lw	s4,328(sp)
40017476:	14412a83          	lw	s5,324(sp)
4001747a:	14012b03          	lw	s6,320(sp)
4001747e:	13c12b83          	lw	s7,316(sp)
40017482:	13812c03          	lw	s8,312(sp)
40017486:	13412c83          	lw	s9,308(sp)
4001748a:	13012d03          	lw	s10,304(sp)
4001748e:	12c12d83          	lw	s11,300(sp)
40017492:	6135                	add	sp,sp,352
40017494:	8082                	ret
40017496:	c3c1                	beqz	a5,40017516 <measure_fmc+0x268>
40017498:	893e                	mv	s2,a5
4001749a:	00fc7463          	bgeu	s8,a5,400174a2 <measure_fmc+0x1f4>
4001749e:	08000913          	li	s2,128
400174a2:	008b05b3          	add	a1,s6,s0
400174a6:	864a                	mv	a2,s2
400174a8:	1108                	add	a0,sp,160
400174aa:	c63e                	sw	a5,12(sp)
400174ac:	43b010ef          	jal	400190e6 <memcpy>
400174b0:	47b2                	lw	a5,12(sp)
400174b2:	944a                	add	s0,s0,s2
400174b4:	02fd6463          	bltu	s10,a5,400174dc <measure_fmc+0x22e>
400174b8:	11090793          	add	a5,s2,272
400174bc:	0818                	add	a4,sp,16
400174be:	97ba                	add	a5,a5,a4
400174c0:	f9978023          	sb	s9,-128(a5)
400174c4:	412d0933          	sub	s2,s10,s2
400174c8:	4b85                	li	s7,1
400174ca:	012df963          	bgeu	s11,s2,400174dc <measure_fmc+0x22e>
400174ce:	4641                	li	a2,16
400174d0:	85ba                	mv	a1,a4
400174d2:	0a08                	add	a0,sp,272
400174d4:	413010ef          	jal	400190e6 <memcpy>
400174d8:	08040413          	add	s0,s0,128
400174dc:	100207b7          	lui	a5,0x10020
400174e0:	10020737          	lui	a4,0x10020
400174e4:	1114                	add	a3,sp,160
400174e6:	08078793          	add	a5,a5,128 # 10020080 <mfdc+0x1001f887>
400174ea:	10070713          	add	a4,a4,256 # 10020100 <mfdc+0x1001f907>
400174ee:	863e                	mv	a2,a5
400174f0:	428c                	lw	a1,0(a3)
400174f2:	0791                	add	a5,a5,4
400174f4:	c20c                	sw	a1,0(a2)
400174f6:	0691                	add	a3,a3,4
400174f8:	fee79be3          	bne	a5,a4,400174ee <measure_fmc+0x240>
400174fc:	450d                	li	a0,3
400174fe:	020a9663          	bnez	s5,4001752a <measure_fmc+0x27c>
40017502:	a79ff0ef          	jal	40016f7a <sha_init>
40017506:	10020737          	lui	a4,0x10020
4001750a:	0a85                	add	s5,s5,1
4001750c:	0761                	add	a4,a4,24 # 10020018 <mfdc+0x1001f81f>
4001750e:	431c                	lw	a5,0(a4)
40017510:	8b89                	and	a5,a5,2
40017512:	dff5                	beqz	a5,4001750e <measure_fmc+0x260>
40017514:	bd8d                	j	40017386 <measure_fmc+0xd8>
40017516:	000b8463          	beqz	s7,4001751e <measure_fmc+0x270>
4001751a:	01849463          	bne	s1,s8,40017522 <measure_fmc+0x274>
4001751e:	0b910023          	sb	s9,160(sp)
40017522:	4641                	li	a2,16
40017524:	00c105b3          	add	a1,sp,a2
40017528:	b76d                	j	400174d2 <measure_fmc+0x224>
4001752a:	01447563          	bgeu	s0,s4,40017534 <measure_fmc+0x286>
4001752e:	a81ff0ef          	jal	40016fae <sha_next>
40017532:	bfd1                	j	40017506 <measure_fmc+0x258>
40017534:	aafff0ef          	jal	40016fe2 <sha_next_last>
40017538:	b7f9                	j	40017506 <measure_fmc+0x258>
4001753a:	50011537          	lui	a0,0x50011
4001753e:	c2850513          	add	a0,a0,-984 # 50010c28 <k+0x3a8>
40017542:	b47fe0ef          	jal	40016088 <puts>
40017546:	557d                	li	a0,-1
40017548:	bf19                	j	4001745e <measure_fmc+0x1b0>

4001754a <soc_ifc_set_flow_status_field>:
4001754a:	1141                	add	sp,sp,-16
4001754c:	c422                	sw	s0,8(sp)
4001754e:	85aa                	mv	a1,a0
40017550:	842a                	mv	s0,a0
40017552:	50011537          	lui	a0,0x50011
40017556:	c8c50513          	add	a0,a0,-884 # 50010c8c <__func__.2+0xc>
4001755a:	c606                	sw	ra,12(sp)
4001755c:	b2ffe0ef          	jal	4001608a <printf>
40017560:	300307b7          	lui	a5,0x30030
40017564:	5fdc                	lw	a5,60(a5)
40017566:	00841693          	sll	a3,s0,0x8
4001756a:	00f46733          	or	a4,s0,a5
4001756e:	c691                	beqz	a3,4001757a <soc_ifc_set_flow_status_field+0x30>
40017570:	ff000737          	lui	a4,0xff000
40017574:	8ff9                	and	a5,a5,a4
40017576:	0087e733          	or	a4,a5,s0
4001757a:	0220000f          	fence	r,r
4001757e:	0220000f          	fence	r,r
40017582:	300307b7          	lui	a5,0x30030
40017586:	40b2                	lw	ra,12(sp)
40017588:	4422                	lw	s0,8(sp)
4001758a:	dfd8                	sw	a4,60(a5)
4001758c:	0141                	add	sp,sp,16
4001758e:	8082                	ret

40017590 <soc_ifc_read_mbox_cmd>:
40017590:	1141                	add	sp,sp,-16
40017592:	300207b7          	lui	a5,0x30020
40017596:	478c                	lw	a1,8(a5)
40017598:	47c8                	lw	a0,12(a5)
4001759a:	0141                	add	sp,sp,16
4001759c:	8082                	ret

4001759e <uart_tx>:
4001759e:	20001737          	lui	a4,0x20001
400175a2:	0751                	add	a4,a4,20 # 20001014 <mfdc+0x2000081b>
400175a4:	431c                	lw	a5,0(a4)
400175a6:	8b85                	and	a5,a5,1
400175a8:	fff5                	bnez	a5,400175a4 <uart_tx+0x6>
400175aa:	0220000f          	fence	r,r
400175ae:	0220000f          	fence	r,r
400175b2:	200017b7          	lui	a5,0x20001
400175b6:	cfc8                	sw	a0,28(a5)
400175b8:	8082                	ret

400175ba <enable_uart>:
400175ba:	0220000f          	fence	r,r
400175be:	0220000f          	fence	r,r
400175c2:	0bcb07b7          	lui	a5,0xbcb0
400175c6:	20001737          	lui	a4,0x20001
400175ca:	078d                	add	a5,a5,3 # bcb0003 <mfdc+0xbcaf80a>
400175cc:	cb1c                	sw	a5,16(a4)
400175ce:	8082                	ret

400175d0 <end_sim_if_uart_disabled>:
400175d0:	300307b7          	lui	a5,0x30030
400175d4:	0e07a783          	lw	a5,224(a5) # 300300e0 <mfdc+0x3002f8e7>
400175d8:	8ba1                	and	a5,a5,8
400175da:	e391                	bnez	a5,400175de <end_sim_if_uart_disabled+0xe>
400175dc:	a001                	j	400175dc <end_sim_if_uart_disabled+0xc>
400175de:	8082                	ret

400175e0 <init_uart>:
400175e0:	1141                	add	sp,sp,-16
400175e2:	c606                	sw	ra,12(sp)
400175e4:	37f5                	jal	400175d0 <end_sim_if_uart_disabled>
400175e6:	40b2                	lw	ra,12(sp)
400175e8:	0141                	add	sp,sp,16
400175ea:	bfc1                	j	400175ba <enable_uart>

400175ec <asn1_write_tag>:
400175ec:	411c                	lw	a5,0(a0)
400175ee:	1141                	add	sp,sp,-16
400175f0:	c422                	sw	s0,8(sp)
400175f2:	c226                	sw	s1,4(sp)
400175f4:	c606                	sw	ra,12(sp)
400175f6:	84b6                	mv	s1,a3
400175f8:	00178693          	add	a3,a5,1
400175fc:	872e                	mv	a4,a1
400175fe:	c114                	sw	a3,0(a0)
40017600:	00e78023          	sb	a4,0(a5)
40017604:	07f00693          	li	a3,127
40017608:	842a                	mv	s0,a0
4001760a:	85b2                	mv	a1,a2
4001760c:	0ff4f713          	zext.b	a4,s1
40017610:	411c                	lw	a5,0(a0)
40017612:	0296e363          	bltu	a3,s1,40017638 <asn1_write_tag+0x4c>
40017616:	00178693          	add	a3,a5,1
4001761a:	c014                	sw	a3,0(s0)
4001761c:	00e78023          	sb	a4,0(a5)
40017620:	8626                	mv	a2,s1
40017622:	4008                	lw	a0,0(s0)
40017624:	2c3010ef          	jal	400190e6 <memcpy>
40017628:	401c                	lw	a5,0(s0)
4001762a:	97a6                	add	a5,a5,s1
4001762c:	c01c                	sw	a5,0(s0)
4001762e:	40b2                	lw	ra,12(sp)
40017630:	4422                	lw	s0,8(sp)
40017632:	4492                	lw	s1,4(sp)
40017634:	0141                	add	sp,sp,16
40017636:	8082                	ret
40017638:	00178693          	add	a3,a5,1
4001763c:	c114                	sw	a3,0(a0)
4001763e:	f8200693          	li	a3,-126
40017642:	00d78023          	sb	a3,0(a5)
40017646:	411c                	lw	a5,0(a0)
40017648:	00178693          	add	a3,a5,1
4001764c:	c114                	sw	a3,0(a0)
4001764e:	0084d693          	srl	a3,s1,0x8
40017652:	00d78023          	sb	a3,0(a5)
40017656:	411c                	lw	a5,0(a0)
40017658:	bf7d                	j	40017616 <asn1_write_tag+0x2a>

4001765a <encode_dn>:
4001765a:	7161                	add	sp,sp,-432
4001765c:	1a912223          	sw	s1,420(sp)
40017660:	1b212023          	sw	s2,416(sp)
40017664:	19412c23          	sw	s4,408(sp)
40017668:	45500793          	li	a5,1109
4001766c:	01010a13          	add	s4,sp,16
40017670:	84ae                	mv	s1,a1
40017672:	468d                	li	a3,3
40017674:	860a                	mv	a2,sp
40017676:	892a                	mv	s2,a0
40017678:	4599                	li	a1,6
4001767a:	0048                	add	a0,sp,4
4001767c:	1a112623          	sw	ra,428(sp)
40017680:	19312e23          	sw	s3,412(sp)
40017684:	1a812423          	sw	s0,424(sp)
40017688:	00f11023          	sh	a5,0(sp)
4001768c:	00d10123          	sb	a3,2(sp)
40017690:	c252                	sw	s4,4(sp)
40017692:	3fa9                	jal	400175ec <asn1_write_tag>
40017694:	8526                	mv	a0,s1
40017696:	33d010ef          	jal	400191d2 <strlen>
4001769a:	86aa                	mv	a3,a0
4001769c:	8626                	mv	a2,s1
4001769e:	0048                	add	a0,sp,4
400176a0:	45b1                	li	a1,12
400176a2:	37a9                	jal	400175ec <asn1_write_tag>
400176a4:	4692                	lw	a3,4(sp)
400176a6:	09010993          	add	s3,sp,144
400176aa:	414686b3          	sub	a3,a3,s4
400176ae:	8652                	mv	a2,s4
400176b0:	0028                	add	a0,sp,8
400176b2:	03000593          	li	a1,48
400176b6:	c44e                	sw	s3,8(sp)
400176b8:	3f15                	jal	400175ec <asn1_write_tag>
400176ba:	46a2                	lw	a3,8(sp)
400176bc:	0a04                	add	s1,sp,272
400176be:	413686b3          	sub	a3,a3,s3
400176c2:	864e                	mv	a2,s3
400176c4:	0068                	add	a0,sp,12
400176c6:	03100593          	li	a1,49
400176ca:	c626                	sw	s1,12(sp)
400176cc:	3705                	jal	400175ec <asn1_write_tag>
400176ce:	46b2                	lw	a3,12(sp)
400176d0:	8e85                	sub	a3,a3,s1
400176d2:	8626                	mv	a2,s1
400176d4:	854a                	mv	a0,s2
400176d6:	03000593          	li	a1,48
400176da:	3f09                	jal	400175ec <asn1_write_tag>
400176dc:	1ac12083          	lw	ra,428(sp)
400176e0:	1a812403          	lw	s0,424(sp)
400176e4:	1a412483          	lw	s1,420(sp)
400176e8:	1a012903          	lw	s2,416(sp)
400176ec:	19c12983          	lw	s3,412(sp)
400176f0:	19812a03          	lw	s4,408(sp)
400176f4:	615d                	add	sp,sp,432
400176f6:	8082                	ret

400176f8 <convert_le32_to_be_bytes>:
400176f8:	4781                	li	a5,0
400176fa:	00c79363          	bne	a5,a2,40017700 <convert_le32_to_be_bytes+0x8>
400176fe:	8082                	ret
40017700:	00279713          	sll	a4,a5,0x2
40017704:	972e                	add	a4,a4,a1
40017706:	4318                	lw	a4,0(a4)
40017708:	01875693          	srl	a3,a4,0x18
4001770c:	00d50023          	sb	a3,0(a0)
40017710:	01075693          	srl	a3,a4,0x10
40017714:	00d500a3          	sb	a3,1(a0)
40017718:	00875693          	srl	a3,a4,0x8
4001771c:	00d50123          	sb	a3,2(a0)
40017720:	00e501a3          	sb	a4,3(a0)
40017724:	0785                	add	a5,a5,1
40017726:	0511                	add	a0,a0,4
40017728:	bfc9                	j	400176fa <convert_le32_to_be_bytes+0x2>

4001772a <generate_intermediate_tbs_der>:
4001772a:	81010113          	add	sp,sp,-2032
4001772e:	7e112623          	sw	ra,2028(sp)
40017732:	7f212023          	sw	s2,2016(sp)
40017736:	7e812423          	sw	s0,2024(sp)
4001773a:	7e912223          	sw	s1,2020(sp)
4001773e:	7d312e23          	sw	s3,2012(sp)
40017742:	7d412c23          	sw	s4,2008(sp)
40017746:	7d512a23          	sw	s5,2004(sp)
4001774a:	7d612823          	sw	s6,2000(sp)
4001774e:	7d712623          	sw	s7,1996(sp)
40017752:	7d812423          	sw	s8,1992(sp)
40017756:	7d912223          	sw	s9,1988(sp)
4001775a:	7da12023          	sw	s10,1984(sp)
4001775e:	7bb12e23          	sw	s11,1980(sp)
40017762:	c0010113          	add	sp,sp,-1024
40017766:	8bb2                	mv	s7,a2
40017768:	3b010a93          	add	s5,sp,944
4001776c:	6605                	lui	a2,0x1
4001776e:	8caa                	mv	s9,a0
40017770:	80060613          	add	a2,a2,-2048 # 800 <mfdc+0x7>
40017774:	89ae                	mv	s3,a1
40017776:	8556                	mv	a0,s5
40017778:	4581                	li	a1,0
4001777a:	8b36                	mv	s6,a3
4001777c:	8c42                	mv	s8,a6
4001777e:	84ba                	mv	s1,a4
40017780:	8a3e                	mv	s4,a5
40017782:	6405                	lui	s0,0x1
40017784:	0bb010ef          	jal	4001903e <memset>
40017788:	0818                	add	a4,sp,16
4001778a:	ba040793          	add	a5,s0,-1120 # ba0 <mfdc+0x3a7>
4001778e:	97ba                	add	a5,a5,a4
40017790:	40878433          	sub	s0,a5,s0
40017794:	010207b7          	lui	a5,0x1020
40017798:	50040913          	add	s2,s0,1280
4001779c:	3a078793          	add	a5,a5,928 # 10203a0 <mfdc+0x101fba7>
400177a0:	00f92e23          	sw	a5,28(s2)
400177a4:	500115b7          	lui	a1,0x50011
400177a8:	53c40793          	add	a5,s0,1340
400177ac:	4631                	li	a2,12
400177ae:	cc858593          	add	a1,a1,-824 # 50010cc8 <__func__.2+0x48>
400177b2:	853e                	mv	a0,a5
400177b4:	4d89                	li	s11,2
400177b6:	c63e                	sw	a5,12(sp)
400177b8:	53b40023          	sb	s11,1312(s0)
400177bc:	12b010ef          	jal	400190e6 <memcpy>
400177c0:	56840793          	add	a5,s0,1384
400177c4:	500115b7          	lui	a1,0x50011
400177c8:	02400613          	li	a2,36
400177cc:	cd858593          	add	a1,a1,-808 # 50010cd8 <__func__.2+0x58>
400177d0:	853e                	mv	a0,a5
400177d2:	c63e                	sw	a5,12(sp)
400177d4:	113010ef          	jal	400190e6 <memcpy>
400177d8:	40000793          	li	a5,1024
400177dc:	05e00613          	li	a2,94
400177e0:	4581                	li	a1,0
400177e2:	6a040513          	add	a0,s0,1696
400177e6:	68f42e23          	sw	a5,1692(s0)
400177ea:	055010ef          	jal	4001903e <memset>
400177ee:	500115b7          	lui	a1,0x50011
400177f2:	461d                	li	a2,7
400177f4:	d0058593          	add	a1,a1,-768 # 50010d00 <__func__.2+0x80>
400177f8:	53440513          	add	a0,s0,1332
400177fc:	0eb010ef          	jal	400190e6 <memcpy>
40017800:	000487b7          	lui	a5,0x48
40017804:	12b78793          	add	a5,a5,299 # 4812b <mfdc+0x47932>
40017808:	02f92223          	sw	a5,36(s2)
4001780c:	02000613          	li	a2,32
40017810:	02200793          	li	a5,34
40017814:	4581                	li	a1,0
40017816:	54840513          	add	a0,s0,1352
4001781a:	52f40423          	sb	a5,1320(s0)
4001781e:	021010ef          	jal	4001903e <memset>
40017822:	10000613          	li	a2,256
40017826:	4581                	li	a1,0
40017828:	70040513          	add	a0,s0,1792
4001782c:	013010ef          	jal	4001903e <memset>
40017830:	61440793          	add	a5,s0,1556
40017834:	853e                	mv	a0,a5
40017836:	04400613          	li	a2,68
4001783a:	4581                	li	a1,0
4001783c:	c63e                	sw	a5,12(sp)
4001783e:	65840d13          	add	s10,s0,1624
40017842:	7fc010ef          	jal	4001903e <memset>
40017846:	04400613          	li	a2,68
4001784a:	4581                	li	a1,0
4001784c:	856a                	mv	a0,s10
4001784e:	7f0010ef          	jal	4001903e <memset>
40017852:	500105b7          	lui	a1,0x50010
40017856:	40200793          	li	a5,1026
4001785a:	02800613          	li	a2,40
4001785e:	0c058593          	add	a1,a1,192 # 500100c0 <_data_vma_start+0xc0>
40017862:	58c40513          	add	a0,s0,1420
40017866:	02f92623          	sw	a5,44(s2)
4001786a:	52041823          	sh	zero,1328(s0)
4001786e:	079010ef          	jal	400190e6 <memcpy>
40017872:	020c8163          	beqz	s9,40017894 <generate_intermediate_tbs_der+0x16a>
40017876:	00098f63          	beqz	s3,40017894 <generate_intermediate_tbs_der+0x16a>
4001787a:	000b8d63          	beqz	s7,40017894 <generate_intermediate_tbs_der+0x16a>
4001787e:	000b0b63          	beqz	s6,40017894 <generate_intermediate_tbs_der+0x16a>
40017882:	c889                	beqz	s1,40017894 <generate_intermediate_tbs_der+0x16a>
40017884:	000a0863          	beqz	s4,40017894 <generate_intermediate_tbs_der+0x16a>
40017888:	000a2703          	lw	a4,0(s4)
4001788c:	7ff00793          	li	a5,2047
40017890:	04e7e863          	bltu	a5,a4,400178e0 <generate_intermediate_tbs_der+0x1b6>
40017894:	50011537          	lui	a0,0x50011
40017898:	cb450513          	add	a0,a0,-844 # 50010cb4 <__func__.2+0x34>
4001789c:	fecfe0ef          	jal	40016088 <puts>
400178a0:	557d                	li	a0,-1
400178a2:	40010113          	add	sp,sp,1024
400178a6:	7ec12083          	lw	ra,2028(sp)
400178aa:	7e812403          	lw	s0,2024(sp)
400178ae:	7e412483          	lw	s1,2020(sp)
400178b2:	7e012903          	lw	s2,2016(sp)
400178b6:	7dc12983          	lw	s3,2012(sp)
400178ba:	7d812a03          	lw	s4,2008(sp)
400178be:	7d412a83          	lw	s5,2004(sp)
400178c2:	7d012b03          	lw	s6,2000(sp)
400178c6:	7cc12b83          	lw	s7,1996(sp)
400178ca:	7c812c03          	lw	s8,1992(sp)
400178ce:	7c412c83          	lw	s9,1988(sp)
400178d2:	7c012d03          	lw	s10,1984(sp)
400178d6:	7bc12d83          	lw	s11,1980(sp)
400178da:	7f010113          	add	sp,sp,2032
400178de:	8082                	ret
400178e0:	85e6                	mv	a1,s9
400178e2:	4631                	li	a2,12
400178e4:	12c8                	add	a0,sp,356
400178e6:	3d09                	jal	400176f8 <convert_le32_to_be_bytes>
400178e8:	85ce                	mv	a1,s3
400178ea:	4631                	li	a2,12
400178ec:	0b48                	add	a0,sp,404
400178ee:	3529                	jal	400176f8 <convert_le32_to_be_bytes>
400178f0:	03000613          	li	a2,48
400178f4:	5b440593          	add	a1,s0,1460
400178f8:	69e40513          	add	a0,s0,1694
400178fc:	7ea010ef          	jal	400190e6 <memcpy>
40017900:	03000613          	li	a2,48
40017904:	5e440593          	add	a1,s0,1508
40017908:	6ce40513          	add	a0,s0,1742
4001790c:	7da010ef          	jal	400190e6 <memcpy>
40017910:	0f810c93          	add	s9,sp,248
40017914:	1968                	add	a0,sp,188
40017916:	469d                	li	a3,7
40017918:	11d0                	add	a2,sp,228
4001791a:	4599                	li	a1,6
4001791c:	01992623          	sw	s9,12(s2)
40017920:	ccdff0ef          	jal	400175ec <asn1_write_tag>
40017924:	4695                	li	a3,5
40017926:	09d0                	add	a2,sp,212
40017928:	4599                	li	a1,6
4001792a:	1968                	add	a0,sp,188
4001792c:	cc1ff0ef          	jal	400175ec <asn1_write_tag>
40017930:	00c92683          	lw	a3,12(s2)
40017934:	2b010993          	add	s3,sp,688
40017938:	419686b3          	sub	a3,a3,s9
4001793c:	8666                	mv	a2,s9
4001793e:	0188                	add	a0,sp,192
40017940:	03000593          	li	a1,48
40017944:	01392823          	sw	s3,16(s2)
40017948:	ca5ff0ef          	jal	400175ec <asn1_write_tag>
4001794c:	06200693          	li	a3,98
40017950:	04f0                	add	a2,sp,588
40017952:	458d                	li	a1,3
40017954:	0188                	add	a0,sp,192
40017956:	c97ff0ef          	jal	400175ec <asn1_write_tag>
4001795a:	01092683          	lw	a3,16(s2)
4001795e:	413686b3          	sub	a3,a3,s3
40017962:	8636                	mv	a2,a3
40017964:	85ce                	mv	a1,s3
40017966:	03a8                	add	a0,sp,456
40017968:	c636                	sw	a3,12(sp)
4001796a:	77c010ef          	jal	400190e6 <memcpy>
4001796e:	04400613          	li	a2,68
40017972:	61440593          	add	a1,s0,1556
40017976:	4b040513          	add	a0,s0,1200
4001797a:	76c010ef          	jal	400190e6 <memcpy>
4001797e:	85ea                	mv	a1,s10
40017980:	04400613          	li	a2,68
40017984:	46040513          	add	a0,s0,1120
40017988:	75e010ef          	jal	400190e6 <memcpy>
4001798c:	0810                	add	a2,sp,16
4001798e:	4585                	li	a1,1
40017990:	1088                	add	a0,sp,96
40017992:	e65fe0ef          	jal	400167f6 <sha256_flow_produce>
40017996:	65c42783          	lw	a5,1628(s0)
4001799a:	52f41723          	sh	a5,1326(s0)
4001799e:	000a2603          	lw	a2,0(s4)
400179a2:	83c1                	srl	a5,a5,0x10
400179a4:	4581                	li	a1,0
400179a6:	8526                	mv	a0,s1
400179a8:	52f41823          	sh	a5,1328(s0)
400179ac:	4d15                	li	s10,5
400179ae:	690010ef          	jal	4001903e <memset>
400179b2:	866a                	mv	a2,s10
400179b4:	51c40593          	add	a1,s0,1308
400179b8:	8526                	mv	a0,s1
400179ba:	72c010ef          	jal	400190e6 <memcpy>
400179be:	4619                	li	a2,6
400179c0:	52c40593          	add	a1,s0,1324
400179c4:	01a48533          	add	a0,s1,s10
400179c8:	71e010ef          	jal	400190e6 <memcpy>
400179cc:	4631                	li	a2,12
400179ce:	53c40593          	add	a1,s0,1340
400179d2:	00b48513          	add	a0,s1,11
400179d6:	710010ef          	jal	400190e6 <memcpy>
400179da:	0c410c93          	add	s9,sp,196
400179de:	01748793          	add	a5,s1,23
400179e2:	85de                	mv	a1,s7
400179e4:	8566                	mv	a0,s9
400179e6:	00f92a23          	sw	a5,20(s2)
400179ea:	c71ff0ef          	jal	4001765a <encode_dn>
400179ee:	01492783          	lw	a5,20(s2)
400179f2:	02400613          	li	a2,36
400179f6:	56840593          	add	a1,s0,1384
400179fa:	853e                	mv	a0,a5
400179fc:	6ea010ef          	jal	400190e6 <memcpy>
40017a00:	02450793          	add	a5,a0,36
40017a04:	85da                	mv	a1,s6
40017a06:	8566                	mv	a0,s9
40017a08:	00f92a23          	sw	a5,20(s2)
40017a0c:	c4fff0ef          	jal	4001765a <encode_dn>
40017a10:	46b2                	lw	a3,12(sp)
40017a12:	864e                	mv	a2,s3
40017a14:	03000593          	li	a1,48
40017a18:	8566                	mv	a0,s9
40017a1a:	bd3ff0ef          	jal	400175ec <asn1_write_tag>
40017a1e:	040c1363          	bnez	s8,40017a64 <generate_intermediate_tbs_der+0x33a>
40017a22:	5ba409a3          	sb	s10,1459(s0)
40017a26:	02800693          	li	a3,40
40017a2a:	1a70                	add	a2,sp,316
40017a2c:	0a300593          	li	a1,163
40017a30:	01c8                	add	a0,sp,196
40017a32:	bbbff0ef          	jal	400175ec <asn1_write_tag>
40017a36:	469e                	lw	a3,196(sp)
40017a38:	8e85                	sub	a3,a3,s1
40017a3a:	00da2023          	sw	a3,0(s4)
40017a3e:	8626                	mv	a2,s1
40017a40:	03000593          	li	a1,48
40017a44:	01a8                	add	a0,sp,200
40017a46:	c5d6                	sw	s5,200(sp)
40017a48:	ba5ff0ef          	jal	400175ec <asn1_write_tag>
40017a4c:	442e                	lw	s0,200(sp)
40017a4e:	41540433          	sub	s0,s0,s5
40017a52:	8622                	mv	a2,s0
40017a54:	85d6                	mv	a1,s5
40017a56:	8526                	mv	a0,s1
40017a58:	68e010ef          	jal	400190e6 <memcpy>
40017a5c:	4501                	li	a0,0
40017a5e:	008a2023          	sw	s0,0(s4)
40017a62:	b581                	j	400178a2 <generate_intermediate_tbs_der+0x178>
40017a64:	4785                	li	a5,1
40017a66:	00fc1663          	bne	s8,a5,40017a72 <generate_intermediate_tbs_der+0x348>
40017a6a:	4791                	li	a5,4
40017a6c:	5af409a3          	sb	a5,1459(s0)
40017a70:	bf5d                	j	40017a26 <generate_intermediate_tbs_der+0x2fc>
40017a72:	470d                	li	a4,3
40017a74:	01bc1563          	bne	s8,s11,40017a7e <generate_intermediate_tbs_der+0x354>
40017a78:	16e101a3          	sb	a4,355(sp)
40017a7c:	b76d                	j	40017a26 <generate_intermediate_tbs_der+0x2fc>
40017a7e:	faec14e3          	bne	s8,a4,40017a26 <generate_intermediate_tbs_der+0x2fc>
40017a82:	4789                	li	a5,2
40017a84:	16f101a3          	sb	a5,355(sp)
40017a88:	bf79                	j	40017a26 <generate_intermediate_tbs_der+0x2fc>

40017a8a <add_signature_to_cert>:
40017a8a:	710d                	add	sp,sp,-352
40017a8c:	15212823          	sw	s2,336(sp)
40017a90:	15512223          	sw	s5,324(sp)
40017a94:	892e                	mv	s2,a1
40017a96:	8aaa                	mv	s5,a0
40017a98:	85b2                	mv	a1,a2
40017a9a:	0828                	add	a0,sp,24
40017a9c:	03000613          	li	a2,48
40017aa0:	14112e23          	sw	ra,348(sp)
40017aa4:	14812c23          	sw	s0,344(sp)
40017aa8:	14912a23          	sw	s1,340(sp)
40017aac:	8436                	mv	s0,a3
40017aae:	84ba                	mv	s1,a4
40017ab0:	15312623          	sw	s3,332(sp)
40017ab4:	15412423          	sw	s4,328(sp)
40017ab8:	89be                	mv	s3,a5
40017aba:	c3fff0ef          	jal	400176f8 <convert_le32_to_be_bytes>
40017abe:	85a2                	mv	a1,s0
40017ac0:	03000613          	li	a2,48
40017ac4:	00a8                	add	a0,sp,72
40017ac6:	c33ff0ef          	jal	400176f8 <convert_le32_to_be_bytes>
40017aca:	03000413          	li	s0,48
40017ace:	00448a13          	add	s4,s1,4
40017ad2:	864a                	mv	a2,s2
40017ad4:	85d6                	mv	a1,s5
40017ad6:	00848023          	sb	s0,0(s1)
40017ada:	8552                	mv	a0,s4
40017adc:	60a010ef          	jal	400190e6 <memcpy>
40017ae0:	4631                	li	a2,12
40017ae2:	500115b7          	lui	a1,0x50011
40017ae6:	cc858593          	add	a1,a1,-824 # 50010cc8 <__func__.2+0x48>
40017aea:	00c10533          	add	a0,sp,a2
40017aee:	5f8010ef          	jal	400190e6 <memcpy>
40017af2:	4631                	li	a2,12
40017af4:	9952                	add	s2,s2,s4
40017af6:	00c105b3          	add	a1,sp,a2
40017afa:	854a                	mv	a0,s2
40017afc:	5ea010ef          	jal	400190e6 <memcpy>
40017b00:	4789                	li	a5,2
40017b02:	06f10d23          	sb	a5,122(sp)
40017b06:	01810783          	lb	a5,24(sp)
40017b0a:	06811c23          	sh	s0,120(sp)
40017b0e:	0e07d363          	bgez	a5,40017bf4 <add_signature_to_cert+0x16a>
40017b12:	03100793          	li	a5,49
40017b16:	8622                	mv	a2,s0
40017b18:	082c                	add	a1,sp,24
40017b1a:	07d10513          	add	a0,sp,125
40017b1e:	06f10da3          	sb	a5,123(sp)
40017b22:	06010e23          	sb	zero,124(sp)
40017b26:	0ad10413          	add	s0,sp,173
40017b2a:	5bc010ef          	jal	400190e6 <memcpy>
40017b2e:	4789                	li	a5,2
40017b30:	00f40023          	sb	a5,0(s0)
40017b34:	04810783          	lb	a5,72(sp)
40017b38:	0c07d763          	bgez	a5,40017c06 <add_signature_to_cert+0x17c>
40017b3c:	03100793          	li	a5,49
40017b40:	00f400a3          	sb	a5,1(s0)
40017b44:	00040123          	sb	zero,2(s0)
40017b48:	00340513          	add	a0,s0,3
40017b4c:	03000613          	li	a2,48
40017b50:	00ac                	add	a1,sp,72
40017b52:	594010ef          	jal	400190e6 <memcpy>
40017b56:	03340413          	add	s0,s0,51
40017b5a:	07810a93          	add	s5,sp,120
40017b5e:	41540633          	sub	a2,s0,s5
40017b62:	1679                	add	a2,a2,-2
40017b64:	07f00713          	li	a4,127
40017b68:	0ff67793          	zext.b	a5,a2
40017b6c:	0ac76963          	bltu	a4,a2,40017c1e <add_signature_to_cert+0x194>
40017b70:	06f10ca3          	sb	a5,121(sp)
40017b74:	478d                	li	a5,3
40017b76:	41540433          	sub	s0,s0,s5
40017b7a:	00f90623          	sb	a5,12(s2)
40017b7e:	07f00693          	li	a3,127
40017b82:	00140793          	add	a5,s0,1
40017b86:	0ff7f713          	zext.b	a4,a5
40017b8a:	0af6e863          	bltu	a3,a5,40017c3a <add_signature_to_cert+0x1b0>
40017b8e:	00e90793          	add	a5,s2,14
40017b92:	00e906a3          	sb	a4,13(s2)
40017b96:	00178713          	add	a4,a5,1
40017b9a:	8622                	mv	a2,s0
40017b9c:	00078023          	sb	zero,0(a5)
40017ba0:	853a                	mv	a0,a4
40017ba2:	85d6                	mv	a1,s5
40017ba4:	542010ef          	jal	400190e6 <memcpy>
40017ba8:	942a                	add	s0,s0,a0
40017baa:	40940633          	sub	a2,s0,s1
40017bae:	1671                	add	a2,a2,-4
40017bb0:	07f00713          	li	a4,127
40017bb4:	0ff67793          	zext.b	a5,a2
40017bb8:	08c76a63          	bltu	a4,a2,40017c4c <add_signature_to_cert+0x1c2>
40017bbc:	00f480a3          	sb	a5,1(s1)
40017bc0:	85d2                	mv	a1,s4
40017bc2:	00248513          	add	a0,s1,2
40017bc6:	3ac010ef          	jal	40018f72 <memmove>
40017bca:	1479                	add	s0,s0,-2
40017bcc:	8c05                	sub	s0,s0,s1
40017bce:	0089a023          	sw	s0,0(s3)
40017bd2:	15c12083          	lw	ra,348(sp)
40017bd6:	15812403          	lw	s0,344(sp)
40017bda:	15412483          	lw	s1,340(sp)
40017bde:	15012903          	lw	s2,336(sp)
40017be2:	14c12983          	lw	s3,332(sp)
40017be6:	14812a03          	lw	s4,328(sp)
40017bea:	14412a83          	lw	s5,324(sp)
40017bee:	4501                	li	a0,0
40017bf0:	6135                	add	sp,sp,352
40017bf2:	8082                	ret
40017bf4:	8622                	mv	a2,s0
40017bf6:	082c                	add	a1,sp,24
40017bf8:	18e8                	add	a0,sp,124
40017bfa:	06810da3          	sb	s0,123(sp)
40017bfe:	4e8010ef          	jal	400190e6 <memcpy>
40017c02:	1160                	add	s0,sp,172
40017c04:	b72d                	j	40017b2e <add_signature_to_cert+0xa4>
40017c06:	03000613          	li	a2,48
40017c0a:	00c400a3          	sb	a2,1(s0)
40017c0e:	00240513          	add	a0,s0,2
40017c12:	00ac                	add	a1,sp,72
40017c14:	4d2010ef          	jal	400190e6 <memcpy>
40017c18:	03240413          	add	s0,s0,50
40017c1c:	bf3d                	j	40017b5a <add_signature_to_cert+0xd0>
40017c1e:	f8100713          	li	a4,-127
40017c22:	07a10593          	add	a1,sp,122
40017c26:	07b10513          	add	a0,sp,123
40017c2a:	06e10ca3          	sb	a4,121(sp)
40017c2e:	06f10d23          	sb	a5,122(sp)
40017c32:	0405                	add	s0,s0,1
40017c34:	33e010ef          	jal	40018f72 <memmove>
40017c38:	bf35                	j	40017b74 <add_signature_to_cert+0xea>
40017c3a:	f8100793          	li	a5,-127
40017c3e:	00f906a3          	sb	a5,13(s2)
40017c42:	00e90723          	sb	a4,14(s2)
40017c46:	00f90793          	add	a5,s2,15
40017c4a:	b7b1                	j	40017b96 <add_signature_to_cert+0x10c>
40017c4c:	0ff00713          	li	a4,255
40017c50:	00c76963          	bltu	a4,a2,40017c62 <add_signature_to_cert+0x1d8>
40017c54:	f8100713          	li	a4,-127
40017c58:	00e480a3          	sb	a4,1(s1)
40017c5c:	00f48123          	sb	a5,2(s1)
40017c60:	b7b5                	j	40017bcc <add_signature_to_cert+0x142>
40017c62:	f8200713          	li	a4,-126
40017c66:	8221                	srl	a2,a2,0x8
40017c68:	00e480a3          	sb	a4,1(s1)
40017c6c:	00c48123          	sb	a2,2(s1)
40017c70:	00f481a3          	sb	a5,3(s1)
40017c74:	bfa1                	j	40017bcc <add_signature_to_cert+0x142>

40017c76 <ldevid>:
40017c76:	72f9                	lui	t0,0xffffe
40017c78:	c5010113          	add	sp,sp,-944
40017c7c:	6785                	lui	a5,0x1
40017c7e:	3a112623          	sw	ra,940(sp)
40017c82:	37078793          	add	a5,a5,880 # 1370 <mfdc+0xb77>
40017c86:	3a812423          	sw	s0,936(sp)
40017c8a:	3a912223          	sw	s1,932(sp)
40017c8e:	3b212023          	sw	s2,928(sp)
40017c92:	39312e23          	sw	s3,924(sp)
40017c96:	39412c23          	sw	s4,920(sp)
40017c9a:	6985                	lui	s3,0x1
40017c9c:	39512a23          	sw	s5,916(sp)
40017ca0:	39612823          	sw	s6,912(sp)
40017ca4:	39712623          	sw	s7,908(sp)
40017ca8:	39812423          	sw	s8,904(sp)
40017cac:	39912223          	sw	s9,900(sp)
40017cb0:	39a12023          	sw	s10,896(sp)
40017cb4:	37b12e23          	sw	s11,892(sp)
40017cb8:	9116                	add	sp,sp,t0
40017cba:	002784b3          	add	s1,a5,sp
40017cbe:	80098913          	add	s2,s3,-2048 # 800 <mfdc+0x7>
40017cc2:	864a                	mv	a2,s2
40017cc4:	4581                	li	a1,0
40017cc6:	80048513          	add	a0,s1,-2048
40017cca:	374010ef          	jal	4001903e <memset>
40017cce:	1e80                	add	s0,sp,880
40017cd0:	864e                	mv	a2,s3
40017cd2:	4581                	li	a1,0
40017cd4:	8526                	mv	a0,s1
40017cd6:	03242623          	sw	s2,44(s0)
40017cda:	364010ef          	jal	4001903e <memset>
40017cde:	08200613          	li	a2,130
40017ce2:	4581                	li	a1,0
40017ce4:	2da40513          	add	a0,s0,730
40017ce8:	35c40913          	add	s2,s0,860
40017cec:	03342823          	sw	s3,48(s0)
40017cf0:	34e010ef          	jal	4001903e <memset>
40017cf4:	4485                	li	s1,1
40017cf6:	4d99                	li	s11,6
40017cf8:	08400613          	li	a2,132
40017cfc:	4581                	li	a1,0
40017cfe:	854a                	mv	a0,s2
40017d00:	2c940c23          	sb	s1,728(s0)
40017d04:	2db40ca3          	sb	s11,729(s0)
40017d08:	336010ef          	jal	4001903e <memset>
40017d0c:	500115b7          	lui	a1,0x50011
40017d10:	462d                	li	a2,11
40017d12:	d0c58593          	add	a1,a1,-756 # 50010d0c <__func__.2+0x8c>
40017d16:	6d010513          	add	a0,sp,1744
40017d1a:	3cc010ef          	jal	400190e6 <memcpy>
40017d1e:	3e040a93          	add	s5,s0,992
40017d22:	08400613          	li	a2,132
40017d26:	4581                	li	a1,0
40017d28:	8556                	mv	a0,s5
40017d2a:	314010ef          	jal	4001903e <memset>
40017d2e:	08200613          	li	a2,130
40017d32:	4581                	li	a1,0
40017d34:	46640513          	add	a0,s0,1126
40017d38:	306010ef          	jal	4001903e <memset>
40017d3c:	f9040d13          	add	s10,s0,-112
40017d40:	2d840593          	add	a1,s0,728
40017d44:	08400613          	li	a2,132
40017d48:	856a                	mv	a0,s10
40017d4a:	f0040c93          	add	s9,s0,-256
40017d4e:	46940223          	sb	s1,1124(s0)
40017d52:	47b402a3          	sb	s11,1125(s0)
40017d56:	390010ef          	jal	400190e6 <memcpy>
40017d5a:	85ca                	mv	a1,s2
40017d5c:	08400613          	li	a2,132
40017d60:	8566                	mv	a0,s9
40017d62:	384010ef          	jal	400190e6 <memcpy>
40017d66:	e7040c13          	add	s8,s0,-400
40017d6a:	85d6                	mv	a1,s5
40017d6c:	08400613          	li	a2,132
40017d70:	8562                	mv	a0,s8
40017d72:	374010ef          	jal	400190e6 <memcpy>
40017d76:	de040b13          	add	s6,s0,-544
40017d7a:	46440b93          	add	s7,s0,1124
40017d7e:	85de                	mv	a1,s7
40017d80:	08400613          	li	a2,132
40017d84:	855a                	mv	a0,s6
40017d86:	360010ef          	jal	400190e6 <memcpy>
40017d8a:	86da                	mv	a3,s6
40017d8c:	8662                	mv	a2,s8
40017d8e:	85e6                	mv	a1,s9
40017d90:	856a                	mv	a0,s10
40017d92:	cc1fd0ef          	jal	40015a52 <hmac_flow>
40017d96:	50011537          	lui	a0,0x50011
40017d9a:	d1850513          	add	a0,a0,-744 # 50010d18 <__func__.2+0x98>
40017d9e:	aeafe0ef          	jal	40016088 <puts>
40017da2:	08200613          	li	a2,130
40017da6:	4581                	li	a1,0
40017da8:	4ea40513          	add	a0,s0,1258
40017dac:	292010ef          	jal	4001903e <memset>
40017db0:	08200613          	li	a2,130
40017db4:	4581                	li	a1,0
40017db6:	56e40513          	add	a0,s0,1390
40017dba:	4e940423          	sb	s1,1256(s0)
40017dbe:	4fb404a3          	sb	s11,1257(s0)
40017dc2:	27c010ef          	jal	4001903e <memset>
40017dc6:	4e840593          	add	a1,s0,1256
40017dca:	08400613          	li	a2,132
40017dce:	856a                	mv	a0,s10
40017dd0:	56940623          	sb	s1,1388(s0)
40017dd4:	569406a3          	sb	s1,1389(s0)
40017dd8:	30e010ef          	jal	400190e6 <memcpy>
40017ddc:	56c40593          	add	a1,s0,1388
40017de0:	08400613          	li	a2,132
40017de4:	8566                	mv	a0,s9
40017de6:	300010ef          	jal	400190e6 <memcpy>
40017dea:	85d6                	mv	a1,s5
40017dec:	08400613          	li	a2,132
40017df0:	8562                	mv	a0,s8
40017df2:	2f4010ef          	jal	400190e6 <memcpy>
40017df6:	85de                	mv	a1,s7
40017df8:	08400613          	li	a2,132
40017dfc:	855a                	mv	a0,s6
40017dfe:	2e8010ef          	jal	400190e6 <memcpy>
40017e02:	86da                	mv	a3,s6
40017e04:	8662                	mv	a2,s8
40017e06:	85e6                	mv	a1,s9
40017e08:	856a                	mv	a0,s10
40017e0a:	c49fd0ef          	jal	40015a52 <hmac_flow>
40017e0e:	50011537          	lui	a0,0x50011
40017e12:	d4450513          	add	a0,a0,-700 # 50010d44 <__func__.2+0xc4>
40017e16:	a72fe0ef          	jal	40016088 <puts>
40017e1a:	50011537          	lui	a0,0x50011
40017e1e:	d7450513          	add	a0,a0,-652 # 50010d74 <__func__.2+0xf4>
40017e22:	a66fe0ef          	jal	40016088 <puts>
40017e26:	0220000f          	fence	r,r
40017e2a:	0220000f          	fence	r,r
40017e2e:	100187b7          	lui	a5,0x10018
40017e32:	0791                	add	a5,a5,4 # 10018004 <mfdc+0x1001780b>
40017e34:	4711                	li	a4,4
40017e36:	c398                	sw	a4,0(a5)
40017e38:	4398                	lw	a4,0(a5)
40017e3a:	8b11                	and	a4,a4,4
40017e3c:	ff75                	bnez	a4,40017e38 <ldevid+0x1c2>
40017e3e:	50011537          	lui	a0,0x50011
40017e42:	da050513          	add	a0,a0,-608 # 50010da0 <__func__.2+0x120>
40017e46:	1e80                	add	s0,sp,880
40017e48:	a40fe0ef          	jal	40016088 <puts>
40017e4c:	08200613          	li	a2,130
40017e50:	4581                	li	a1,0
40017e52:	5f240513          	add	a0,s0,1522
40017e56:	1e8010ef          	jal	4001903e <memset>
40017e5a:	67440a13          	add	s4,s0,1652
40017e5e:	4485                	li	s1,1
40017e60:	4799                	li	a5,6
40017e62:	08400613          	li	a2,132
40017e66:	4581                	li	a1,0
40017e68:	8552                	mv	a0,s4
40017e6a:	5ef408a3          	sb	a5,1521(s0)
40017e6e:	5e940823          	sb	s1,1520(s0)
40017e72:	1cc010ef          	jal	4001903e <memset>
40017e76:	6785                	lui	a5,0x1
40017e78:	9e878793          	add	a5,a5,-1560 # 9e8 <mfdc+0x1ef>
40017e7c:	500115b7          	lui	a1,0x50011
40017e80:	00278533          	add	a0,a5,sp
40017e84:	4639                	li	a2,14
40017e86:	dc458593          	add	a1,a1,-572 # 50010dc4 <__func__.2+0x144>
40017e8a:	25c010ef          	jal	400190e6 <memcpy>
40017e8e:	6f840993          	add	s3,s0,1784
40017e92:	08400613          	li	a2,132
40017e96:	4581                	li	a1,0
40017e98:	854e                	mv	a0,s3
40017e9a:	1a4010ef          	jal	4001903e <memset>
40017e9e:	08200613          	li	a2,130
40017ea2:	4581                	li	a1,0
40017ea4:	77e40513          	add	a0,s0,1918
40017ea8:	196010ef          	jal	4001903e <memset>
40017eac:	490d                	li	s2,3
40017eae:	5f040593          	add	a1,s0,1520
40017eb2:	08400613          	li	a2,132
40017eb6:	f9040513          	add	a0,s0,-112
40017eba:	76940e23          	sb	s1,1916(s0)
40017ebe:	77240ea3          	sb	s2,1917(s0)
40017ec2:	224010ef          	jal	400190e6 <memcpy>
40017ec6:	85d2                	mv	a1,s4
40017ec8:	08400613          	li	a2,132
40017ecc:	f0040513          	add	a0,s0,-256
40017ed0:	216010ef          	jal	400190e6 <memcpy>
40017ed4:	85ce                	mv	a1,s3
40017ed6:	08400613          	li	a2,132
40017eda:	e7040513          	add	a0,s0,-400
40017ede:	208010ef          	jal	400190e6 <memcpy>
40017ee2:	77c40593          	add	a1,s0,1916
40017ee6:	08400613          	li	a2,132
40017eea:	de040513          	add	a0,s0,-544
40017eee:	1f8010ef          	jal	400190e6 <memcpy>
40017ef2:	0a94                	add	a3,sp,336
40017ef4:	1390                	add	a2,sp,480
40017ef6:	1c8c                	add	a1,sp,624
40017ef8:	0608                	add	a0,sp,768
40017efa:	b59fd0ef          	jal	40015a52 <hmac_flow>
40017efe:	50011537          	lui	a0,0x50011
40017f02:	dd450513          	add	a0,a0,-556 # 50010dd4 <__func__.2+0x154>
40017f06:	982fe0ef          	jal	40016088 <puts>
40017f0a:	03200613          	li	a2,50
40017f0e:	4581                	li	a1,0
40017f10:	06640513          	add	a0,s0,102
40017f14:	12a010ef          	jal	4001903e <memset>
40017f18:	03400613          	li	a2,52
40017f1c:	4581                	li	a1,0
40017f1e:	09840513          	add	a0,s0,152
40017f22:	06940223          	sb	s1,100(s0)
40017f26:	072402a3          	sb	s2,101(s0)
40017f2a:	114010ef          	jal	4001903e <memset>
40017f2e:	03400613          	li	a2,52
40017f32:	4581                	li	a1,0
40017f34:	0cc40513          	add	a0,s0,204
40017f38:	106010ef          	jal	4001903e <memset>
40017f3c:	03200613          	li	a2,50
40017f40:	4581                	li	a1,0
40017f42:	10240513          	add	a0,s0,258
40017f46:	0f8010ef          	jal	4001903e <memset>
40017f4a:	4795                	li	a5,5
40017f4c:	03400613          	li	a2,52
40017f50:	4581                	li	a1,0
40017f52:	13440513          	add	a0,s0,308
40017f56:	10f400a3          	sb	a5,257(s0)
40017f5a:	10940023          	sb	s1,256(s0)
40017f5e:	0e0010ef          	jal	4001903e <memset>
40017f62:	03400613          	li	a2,52
40017f66:	4581                	li	a1,0
40017f68:	16840513          	add	a0,s0,360
40017f6c:	12940a23          	sb	s1,308(s0)
40017f70:	0ce010ef          	jal	4001903e <memset>
40017f74:	4d810793          	add	a5,sp,1240
40017f78:	4a410713          	add	a4,sp,1188
40017f7c:	47010693          	add	a3,sp,1136
40017f80:	43c10613          	add	a2,sp,1084
40017f84:	40810593          	add	a1,sp,1032
40017f88:	0fc8                	add	a0,sp,980
40017f8a:	16940423          	sb	s1,360(s0)
40017f8e:	b74fd0ef          	jal	40015302 <ecc_keygen_flow>
40017f92:	50011537          	lui	a0,0x50011
40017f96:	e0050513          	add	a0,a0,-512 # 50010e00 <__func__.2+0x180>
40017f9a:	8eefe0ef          	jal	40016088 <puts>
40017f9e:	0220000f          	fence	r,r
40017fa2:	0220000f          	fence	r,r
40017fa6:	100187b7          	lui	a5,0x10018
40017faa:	07b1                	add	a5,a5,12 # 1001800c <mfdc+0x10017813>
40017fac:	4711                	li	a4,4
40017fae:	c398                	sw	a4,0(a5)
40017fb0:	4380                	lw	s0,0(a5)
40017fb2:	8811                	and	s0,s0,4
40017fb4:	fc75                	bnez	s0,40017fb0 <ldevid+0x33a>
40017fb6:	50011537          	lui	a0,0x50011
40017fba:	e3c50513          	add	a0,a0,-452 # 50010e3c <__func__.2+0x1bc>
40017fbe:	8cafe0ef          	jal	40016088 <puts>
40017fc2:	4a810493          	add	s1,sp,1192
40017fc6:	4dc10593          	add	a1,sp,1244
40017fca:	468d                	li	a3,3
40017fcc:	4609                	li	a2,2
40017fce:	8526                	mv	a0,s1
40017fd0:	c62e                	sw	a1,12(sp)
40017fd2:	996fd0ef          	jal	40015168 <store_to_datavault>
40017fd6:	6785                	lui	a5,0x1
40017fd8:	b7078793          	add	a5,a5,-1168 # b70 <mfdc+0x377>
40017fdc:	00278a33          	add	s4,a5,sp
40017fe0:	500116b7          	lui	a3,0x50011
40017fe4:	50011637          	lui	a2,0x50011
40017fe8:	4805                	li	a6,1
40017fea:	0f7c                	add	a5,sp,924
40017fec:	8752                	mv	a4,s4
40017fee:	e6068693          	add	a3,a3,-416 # 50010e60 <__func__.2+0x1e0>
40017ff2:	e7460613          	add	a2,a2,-396 # 50010e74 <__func__.2+0x1f4>
40017ff6:	45b2                	lw	a1,12(sp)
40017ff8:	8526                	mv	a0,s1
40017ffa:	f30ff0ef          	jal	4001772a <generate_intermediate_tbs_der>
40017ffe:	892a                	mv	s2,a0
40018000:	30051563          	bnez	a0,4001830a <ldevid+0x694>
40018004:	6785                	lui	a5,0x1
40018006:	80078793          	add	a5,a5,-2048 # 800 <mfdc+0x7>
4001800a:	39c12583          	lw	a1,924(sp)
4001800e:	37010993          	add	s3,sp,880
40018012:	2eb7ec63          	bltu	a5,a1,4001830a <ldevid+0x694>
40018016:	500114b7          	lui	s1,0x50011
4001801a:	e8848513          	add	a0,s1,-376 # 50010e88 <__func__.2+0x208>
4001801e:	86cfe0ef          	jal	4001608a <printf>
40018022:	50011537          	lui	a0,0x50011
40018026:	e9c50513          	add	a0,a0,-356 # 50010e9c <__func__.2+0x21c>
4001802a:	85efe0ef          	jal	40016088 <puts>
4001802e:	4abd                	li	s5,15
40018030:	50011b37          	lui	s6,0x50011
40018034:	50011bb7          	lui	s7,0x50011
40018038:	50011c37          	lui	s8,0x50011
4001803c:	02c9a783          	lw	a5,44(s3)
40018040:	2af96563          	bltu	s2,a5,400182ea <ldevid+0x674>
40018044:	4529                	li	a0,10
40018046:	83cfe0ef          	jal	40016082 <putchar>
4001804a:	5001f7b7          	lui	a5,0x5001f
4001804e:	02c9aa83          	lw	s5,44(s3)
40018052:	82078793          	add	a5,a5,-2016 # 5001e820 <tbs_der_store>
40018056:	4685                	li	a3,1
40018058:	40d78623          	sb	a3,1036(a5)
4001805c:	4157a423          	sw	s5,1032(a5)
40018060:	6785                	lui	a5,0x1
40018062:	b7078793          	add	a5,a5,-1168 # b70 <mfdc+0x377>
40018066:	00278a33          	add	s4,a5,sp
4001806a:	5001f537          	lui	a0,0x5001f
4001806e:	8656                	mv	a2,s5
40018070:	85d2                	mv	a1,s4
40018072:	a2850513          	add	a0,a0,-1496 # 5001ea28 <tbs_der_store+0x208>
40018076:	070010ef          	jal	400190e6 <memcpy>
4001807a:	3a410913          	add	s2,sp,932
4001807e:	4685                	li	a3,1
40018080:	864a                	mv	a2,s2
40018082:	85d6                	mv	a1,s5
40018084:	8552                	mv	a0,s4
40018086:	c8bfe0ef          	jal	40016d10 <sha384_digest>
4001808a:	03400613          	li	a2,52
4001808e:	4581                	li	a1,0
40018090:	19c98513          	add	a0,s3,412
40018094:	7ab000ef          	jal	4001903e <memset>
40018098:	1e94                	add	a3,sp,880
4001809a:	03000513          	li	a0,48
4001809e:	008907b3          	add	a5,s2,s0
400180a2:	4390                	lw	a2,0(a5)
400180a4:	43cc                	lw	a1,4(a5)
400180a6:	28068793          	add	a5,a3,640
400180aa:	d38c                	sw	a1,32(a5)
400180ac:	d3d0                	sw	a2,36(a5)
400180ae:	51010793          	add	a5,sp,1296
400180b2:	97a2                	add	a5,a5,s0
400180b4:	c38c                	sw	a1,0(a5)
400180b6:	c3d0                	sw	a2,4(a5)
400180b8:	0421                	add	s0,s0,8
400180ba:	50c10993          	add	s3,sp,1292
400180be:	fea410e3          	bne	s0,a0,4001809e <ldevid+0x428>
400180c2:	50011537          	lui	a0,0x50011
400180c6:	ed450513          	add	a0,a0,-300 # 50010ed4 <__func__.2+0x254>
400180ca:	fbffd0ef          	jal	40016088 <puts>
400180ce:	53c10413          	add	s0,sp,1340
400180d2:	50011937          	lui	s2,0x50011
400180d6:	0049a583          	lw	a1,4(s3)
400180da:	b9090513          	add	a0,s2,-1136 # 50010b90 <k+0x310>
400180de:	0991                	add	s3,s3,4
400180e0:	fabfd0ef          	jal	4001608a <printf>
400180e4:	fe8999e3          	bne	s3,s0,400180d6 <ldevid+0x460>
400180e8:	4529                	li	a0,10
400180ea:	f99fd0ef          	jal	40016082 <putchar>
400180ee:	03200613          	li	a2,50
400180f2:	4581                	li	a1,0
400180f4:	54210513          	add	a0,sp,1346
400180f8:	747000ef          	jal	4001903e <memset>
400180fc:	479d                	li	a5,7
400180fe:	4985                	li	s3,1
40018100:	03400613          	li	a2,52
40018104:	4581                	li	a1,0
40018106:	57410513          	add	a0,sp,1396
4001810a:	54f100a3          	sb	a5,1345(sp)
4001810e:	55310023          	sb	s3,1344(sp)
40018112:	72d000ef          	jal	4001903e <memset>
40018116:	03400613          	li	a2,52
4001811a:	4581                	li	a1,0
4001811c:	5a810513          	add	a0,sp,1448
40018120:	57310a23          	sb	s3,1396(sp)
40018124:	57410413          	add	s0,sp,1396
40018128:	717000ef          	jal	4001903e <memset>
4001812c:	5a810713          	add	a4,sp,1448
40018130:	86a2                	mv	a3,s0
40018132:	43c10613          	add	a2,sp,1084
40018136:	50c10593          	add	a1,sp,1292
4001813a:	54010513          	add	a0,sp,1344
4001813e:	5b310423          	sb	s3,1448(sp)
40018142:	d1cfd0ef          	jal	4001565e <ecc_signing_flow>
40018146:	50011537          	lui	a0,0x50011
4001814a:	ee450513          	add	a0,a0,-284 # 50010ee4 <__func__.2+0x264>
4001814e:	f3bfd0ef          	jal	40016088 <puts>
40018152:	5a410a13          	add	s4,sp,1444
40018156:	500119b7          	lui	s3,0x50011
4001815a:	404c                	lw	a1,4(s0)
4001815c:	ef498513          	add	a0,s3,-268 # 50010ef4 <__func__.2+0x274>
40018160:	0411                	add	s0,s0,4
40018162:	f29fd0ef          	jal	4001608a <printf>
40018166:	ff441ae3          	bne	s0,s4,4001815a <ldevid+0x4e4>
4001816a:	50011537          	lui	a0,0x50011
4001816e:	efc50513          	add	a0,a0,-260 # 50010efc <__func__.2+0x27c>
40018172:	f17fd0ef          	jal	40016088 <puts>
40018176:	5a810413          	add	s0,sp,1448
4001817a:	5d810a13          	add	s4,sp,1496
4001817e:	404c                	lw	a1,4(s0)
40018180:	ef498513          	add	a0,s3,-268
40018184:	0411                	add	s0,s0,4
40018186:	f05fd0ef          	jal	4001608a <printf>
4001818a:	ff441ae3          	bne	s0,s4,4001817e <ldevid+0x508>
4001818e:	4529                	li	a0,10
40018190:	ef3fd0ef          	jal	40016082 <putchar>
40018194:	0220000f          	fence	r,r
40018198:	0220000f          	fence	r,r
4001819c:	100187b7          	lui	a5,0x10018
400181a0:	07f1                	add	a5,a5,28 # 1001801c <mfdc+0x10017823>
400181a2:	4711                	li	a4,4
400181a4:	c398                	sw	a4,0(a5)
400181a6:	4398                	lw	a4,0(a5)
400181a8:	8b11                	and	a4,a4,4
400181aa:	ff75                	bnez	a4,400181a6 <ldevid+0x530>
400181ac:	50011537          	lui	a0,0x50011
400181b0:	f0c50513          	add	a0,a0,-244 # 50010f0c <__func__.2+0x28c>
400181b4:	ed5fd0ef          	jal	40016088 <puts>
400181b8:	03400613          	li	a2,52
400181bc:	4581                	li	a1,0
400181be:	5dc10513          	add	a0,sp,1500
400181c2:	67d000ef          	jal	4001903e <memset>
400181c6:	03400613          	li	a2,52
400181ca:	4581                	li	a1,0
400181cc:	61010513          	add	a0,sp,1552
400181d0:	66f000ef          	jal	4001903e <memset>
400181d4:	46a5                	li	a3,9
400181d6:	4621                	li	a2,8
400181d8:	61410593          	add	a1,sp,1556
400181dc:	5e010513          	add	a0,sp,1504
400181e0:	870fd0ef          	jal	40015250 <read_from_datavault>
400181e4:	50011537          	lui	a0,0x50011
400181e8:	f3050513          	add	a0,a0,-208 # 50010f30 <__func__.2+0x2b0>
400181ec:	5dc10413          	add	s0,sp,1500
400181f0:	e99fd0ef          	jal	40016088 <puts>
400181f4:	60c10993          	add	s3,sp,1548
400181f8:	404c                	lw	a1,4(s0)
400181fa:	b9090513          	add	a0,s2,-1136
400181fe:	0411                	add	s0,s0,4
40018200:	e8bfd0ef          	jal	4001608a <printf>
40018204:	ff341ae3          	bne	s0,s3,400181f8 <ldevid+0x582>
40018208:	4529                	li	a0,10
4001820a:	e79fd0ef          	jal	40016082 <putchar>
4001820e:	50011537          	lui	a0,0x50011
40018212:	f4850513          	add	a0,a0,-184 # 50010f48 <__func__.2+0x2c8>
40018216:	e73fd0ef          	jal	40016088 <puts>
4001821a:	61010413          	add	s0,sp,1552
4001821e:	64010993          	add	s3,sp,1600
40018222:	404c                	lw	a1,4(s0)
40018224:	b9090513          	add	a0,s2,-1136
40018228:	0411                	add	s0,s0,4
4001822a:	e61fd0ef          	jal	4001608a <printf>
4001822e:	ff341ae3          	bne	s0,s3,40018222 <ldevid+0x5ac>
40018232:	4529                	li	a0,10
40018234:	1e80                	add	s0,sp,880
40018236:	e4dfd0ef          	jal	40016082 <putchar>
4001823a:	03400613          	li	a2,52
4001823e:	19c40593          	add	a1,s0,412
40018242:	da040513          	add	a0,s0,-608
40018246:	6a1000ef          	jal	400190e6 <memcpy>
4001824a:	03400613          	li	a2,52
4001824e:	26c40593          	add	a1,s0,620
40018252:	d6040513          	add	a0,s0,-672
40018256:	691000ef          	jal	400190e6 <memcpy>
4001825a:	03400613          	li	a2,52
4001825e:	2a040593          	add	a1,s0,672
40018262:	d2040513          	add	a0,s0,-736
40018266:	681000ef          	jal	400190e6 <memcpy>
4001826a:	03400613          	li	a2,52
4001826e:	20440593          	add	a1,s0,516
40018272:	ce040513          	add	a0,s0,-800
40018276:	671000ef          	jal	400190e6 <memcpy>
4001827a:	03400613          	li	a2,52
4001827e:	23840593          	add	a1,s0,568
40018282:	ca040513          	add	a0,s0,-864
40018286:	661000ef          	jal	400190e6 <memcpy>
4001828a:	0818                	add	a4,sp,16
4001828c:	0894                	add	a3,sp,80
4001828e:	0910                	add	a2,sp,144
40018290:	098c                	add	a1,sp,208
40018292:	0a08                	add	a0,sp,272
40018294:	e2afd0ef          	jal	400158be <ecc_verifying_flow>
40018298:	e141                	bnez	a0,40018318 <ldevid+0x6a2>
4001829a:	50011537          	lui	a0,0x50011
4001829e:	f6050513          	add	a0,a0,-160 # 50010f60 <__func__.2+0x2e0>
400182a2:	de7fd0ef          	jal	40016088 <puts>
400182a6:	57810913          	add	s2,sp,1400
400182aa:	5ac10993          	add	s3,sp,1452
400182ae:	4685                	li	a3,1
400182b0:	4601                	li	a2,0
400182b2:	85ce                	mv	a1,s3
400182b4:	854a                	mv	a0,s2
400182b6:	eb3fc0ef          	jal	40015168 <store_to_datavault>
400182ba:	6505                	lui	a0,0x1
400182bc:	37050793          	add	a5,a0,880 # 1370 <mfdc+0xb77>
400182c0:	00278a33          	add	s4,a5,sp
400182c4:	b7050513          	add	a0,a0,-1168
400182c8:	864a                	mv	a2,s2
400182ca:	171c                	add	a5,sp,928
400182cc:	8752                	mv	a4,s4
400182ce:	86ce                	mv	a3,s3
400182d0:	544c                	lw	a1,44(s0)
400182d2:	950a                	add	a0,a0,sp
400182d4:	fb6ff0ef          	jal	40017a8a <add_signature_to_cert>
400182d8:	892a                	mv	s2,a0
400182da:	c531                	beqz	a0,40018326 <ldevid+0x6b0>
400182dc:	50011537          	lui	a0,0x50011
400182e0:	eb450513          	add	a0,a0,-332 # 50010eb4 <__func__.2+0x234>
400182e4:	da5fd0ef          	jal	40016088 <puts>
400182e8:	a001                	j	400182e8 <ldevid+0x672>
400182ea:	012a07b3          	add	a5,s4,s2
400182ee:	0007c603          	lbu	a2,0(a5)
400182f2:	cd4b0593          	add	a1,s6,-812 # 50010cd4 <__func__.2+0x54>
400182f6:	00cae463          	bltu	s5,a2,400182fe <ldevid+0x688>
400182fa:	d08b8593          	add	a1,s7,-760 # 50010d08 <__func__.2+0x88>
400182fe:	eacc0513          	add	a0,s8,-340 # 50010eac <__func__.2+0x22c>
40018302:	d89fd0ef          	jal	4001608a <printf>
40018306:	0905                	add	s2,s2,1
40018308:	bb15                	j	4001803c <ldevid+0x3c6>
4001830a:	50011537          	lui	a0,0x50011
4001830e:	eb450513          	add	a0,a0,-332 # 50010eb4 <__func__.2+0x234>
40018312:	d77fd0ef          	jal	40016088 <puts>
40018316:	a001                	j	40018316 <ldevid+0x6a0>
40018318:	50011537          	lui	a0,0x50011
4001831c:	f8450513          	add	a0,a0,-124 # 50010f84 <__func__.2+0x304>
40018320:	d69fd0ef          	jal	40016088 <puts>
40018324:	a001                	j	40018324 <ldevid+0x6ae>
40018326:	580c                	lw	a1,48(s0)
40018328:	6785                	lui	a5,0x1
4001832a:	fab7e9e3          	bltu	a5,a1,400182dc <ldevid+0x666>
4001832e:	e8848513          	add	a0,s1,-376
40018332:	d59fd0ef          	jal	4001608a <printf>
40018336:	50011537          	lui	a0,0x50011
4001833a:	fa450513          	add	a0,a0,-92 # 50010fa4 <__func__.2+0x324>
4001833e:	d4bfd0ef          	jal	40016088 <puts>
40018342:	44bd                	li	s1,15
40018344:	500119b7          	lui	s3,0x50011
40018348:	50011ab7          	lui	s5,0x50011
4001834c:	50011b37          	lui	s6,0x50011
40018350:	581c                	lw	a5,48(s0)
40018352:	06f96963          	bltu	s2,a5,400183c4 <ldevid+0x74e>
40018356:	4529                	li	a0,10
40018358:	d2bfd0ef          	jal	40016082 <putchar>
4001835c:	5001e7b7          	lui	a5,0x5001e
40018360:	5810                	lw	a2,48(s0)
40018362:	00078793          	mv	a5,a5
40018366:	4705                	li	a4,1
40018368:	40c7a423          	sw	a2,1032(a5) # 5001e408 <cert_store+0x408>
4001836c:	40e78623          	sb	a4,1036(a5)
40018370:	6785                	lui	a5,0x1
40018372:	37078793          	add	a5,a5,880 # 1370 <mfdc+0xb77>
40018376:	5001e537          	lui	a0,0x5001e
4001837a:	002785b3          	add	a1,a5,sp
4001837e:	20850513          	add	a0,a0,520 # 5001e208 <cert_store+0x208>
40018382:	565000ef          	jal	400190e6 <memcpy>
40018386:	6289                	lui	t0,0x2
40018388:	9116                	add	sp,sp,t0
4001838a:	3ac12083          	lw	ra,940(sp)
4001838e:	3a812403          	lw	s0,936(sp)
40018392:	3a412483          	lw	s1,932(sp)
40018396:	3a012903          	lw	s2,928(sp)
4001839a:	39c12983          	lw	s3,924(sp)
4001839e:	39812a03          	lw	s4,920(sp)
400183a2:	39412a83          	lw	s5,916(sp)
400183a6:	39012b03          	lw	s6,912(sp)
400183aa:	38c12b83          	lw	s7,908(sp)
400183ae:	38812c03          	lw	s8,904(sp)
400183b2:	38412c83          	lw	s9,900(sp)
400183b6:	38012d03          	lw	s10,896(sp)
400183ba:	37c12d83          	lw	s11,892(sp)
400183be:	3b010113          	add	sp,sp,944
400183c2:	8082                	ret
400183c4:	012a07b3          	add	a5,s4,s2
400183c8:	0007c603          	lbu	a2,0(a5)
400183cc:	cd498593          	add	a1,s3,-812 # 50010cd4 <__func__.2+0x54>
400183d0:	00c4e463          	bltu	s1,a2,400183d8 <ldevid+0x762>
400183d4:	d08a8593          	add	a1,s5,-760 # 50010d08 <__func__.2+0x88>
400183d8:	eacb0513          	add	a0,s6,-340 # 50010eac <__func__.2+0x22c>
400183dc:	caffd0ef          	jal	4001608a <printf>
400183e0:	0905                	add	s2,s2,1
400183e2:	b7bd                	j	40018350 <ldevid+0x6da>

400183e4 <idevid>:
400183e4:	710d                	add	sp,sp,-352
400183e6:	72f9                	lui	t0,0xffffe
400183e8:	6785                	lui	a5,0x1
400183ea:	14112e23          	sw	ra,348(sp)
400183ee:	13078793          	add	a5,a5,304 # 1130 <mfdc+0x937>
400183f2:	14812c23          	sw	s0,344(sp)
400183f6:	14912a23          	sw	s1,340(sp)
400183fa:	15212823          	sw	s2,336(sp)
400183fe:	15312623          	sw	s3,332(sp)
40018402:	15412423          	sw	s4,328(sp)
40018406:	6985                	lui	s3,0x1
40018408:	15512223          	sw	s5,324(sp)
4001840c:	15612023          	sw	s6,320(sp)
40018410:	13712e23          	sw	s7,316(sp)
40018414:	13812c23          	sw	s8,312(sp)
40018418:	13912a23          	sw	s9,308(sp)
4001841c:	9116                	add	sp,sp,t0
4001841e:	00f104b3          	add	s1,sp,a5
40018422:	80098913          	add	s2,s3,-2048 # 800 <mfdc+0x7>
40018426:	864a                	mv	a2,s2
40018428:	4581                	li	a1,0
4001842a:	80048513          	add	a0,s1,-2048
4001842e:	411000ef          	jal	4001903e <memset>
40018432:	864e                	mv	a2,s3
40018434:	4581                	li	a1,0
40018436:	8526                	mv	a0,s1
40018438:	39212423          	sw	s2,904(sp)
4001843c:	403000ef          	jal	4001903e <memset>
40018440:	08400613          	li	a2,132
40018444:	4581                	li	a1,0
40018446:	59410513          	add	a0,sp,1428
4001844a:	39312623          	sw	s3,908(sp)
4001844e:	3f1000ef          	jal	4001903e <memset>
40018452:	4785                	li	a5,1
40018454:	08400613          	li	a2,132
40018458:	4581                	li	a1,0
4001845a:	61810513          	add	a0,sp,1560
4001845e:	58f10a23          	sb	a5,1428(sp)
40018462:	3dd000ef          	jal	4001903e <memset>
40018466:	61810413          	add	s0,sp,1560
4001846a:	500115b7          	lui	a1,0x50011
4001846e:	462d                	li	a2,11
40018470:	fb458593          	add	a1,a1,-76 # 50010fb4 <__func__.2+0x334>
40018474:	00440513          	add	a0,s0,4
40018478:	46f000ef          	jal	400190e6 <memcpy>
4001847c:	50011537          	lui	a0,0x50011
40018480:	fc050513          	add	a0,a0,-64 # 50010fc0 <__func__.2+0x340>
40018484:	c05fd0ef          	jal	40016088 <puts>
40018488:	4901                	li	s2,0
4001848a:	500114b7          	lui	s1,0x50011
4001848e:	4a3d                	li	s4,15
40018490:	02000993          	li	s3,32
40018494:	404c                	lw	a1,4(s0)
40018496:	b9048513          	add	a0,s1,-1136 # 50010b90 <k+0x310>
4001849a:	bf1fd0ef          	jal	4001608a <printf>
4001849e:	00f97793          	and	a5,s2,15
400184a2:	01479563          	bne	a5,s4,400184ac <idevid+0xc8>
400184a6:	4529                	li	a0,10
400184a8:	bdbfd0ef          	jal	40016082 <putchar>
400184ac:	0905                	add	s2,s2,1
400184ae:	0411                	add	s0,s0,4
400184b0:	ff3912e3          	bne	s2,s3,40018494 <idevid+0xb0>
400184b4:	4529                	li	a0,10
400184b6:	bcdfd0ef          	jal	40016082 <putchar>
400184ba:	69c10913          	add	s2,sp,1692
400184be:	08400613          	li	a2,132
400184c2:	4581                	li	a1,0
400184c4:	854a                	mv	a0,s2
400184c6:	379000ef          	jal	4001903e <memset>
400184ca:	08200613          	li	a2,130
400184ce:	4581                	li	a1,0
400184d0:	72210513          	add	a0,sp,1826
400184d4:	36b000ef          	jal	4001903e <memset>
400184d8:	4785                	li	a5,1
400184da:	72f10023          	sb	a5,1824(sp)
400184de:	59410593          	add	a1,sp,1428
400184e2:	4799                	li	a5,6
400184e4:	08400613          	li	a2,132
400184e8:	1d88                	add	a0,sp,752
400184ea:	72f100a3          	sb	a5,1825(sp)
400184ee:	3f9000ef          	jal	400190e6 <memcpy>
400184f2:	61810593          	add	a1,sp,1560
400184f6:	08400613          	li	a2,132
400184fa:	1488                	add	a0,sp,608
400184fc:	3eb000ef          	jal	400190e6 <memcpy>
40018500:	85ca                	mv	a1,s2
40018502:	08400613          	li	a2,132
40018506:	0b88                	add	a0,sp,464
40018508:	3df000ef          	jal	400190e6 <memcpy>
4001850c:	72010593          	add	a1,sp,1824
40018510:	08400613          	li	a2,132
40018514:	0288                	add	a0,sp,320
40018516:	3d1000ef          	jal	400190e6 <memcpy>
4001851a:	0294                	add	a3,sp,320
4001851c:	0b90                	add	a2,sp,464
4001851e:	148c                	add	a1,sp,608
40018520:	1d88                	add	a0,sp,752
40018522:	d30fd0ef          	jal	40015a52 <hmac_flow>
40018526:	50011537          	lui	a0,0x50011
4001852a:	fd050513          	add	a0,a0,-48 # 50010fd0 <__func__.2+0x350>
4001852e:	b5bfd0ef          	jal	40016088 <puts>
40018532:	0220000f          	fence	r,r
40018536:	0220000f          	fence	r,r
4001853a:	10018737          	lui	a4,0x10018
4001853e:	4791                	li	a5,4
40018540:	c31c                	sw	a5,0(a4)
40018542:	431c                	lw	a5,0(a4)
40018544:	8b91                	and	a5,a5,4
40018546:	fff5                	bnez	a5,40018542 <idevid+0x15e>
40018548:	50011537          	lui	a0,0x50011
4001854c:	ffc50513          	add	a0,a0,-4 # 50010ffc <__func__.2+0x37c>
40018550:	b39fd0ef          	jal	40016088 <puts>
40018554:	08200613          	li	a2,130
40018558:	4581                	li	a1,0
4001855a:	7a610513          	add	a0,sp,1958
4001855e:	2e1000ef          	jal	4001903e <memset>
40018562:	1a00                	add	s0,sp,304
40018564:	4785                	li	a5,1
40018566:	7af10223          	sb	a5,1956(sp)
4001856a:	08400613          	li	a2,132
4001856e:	4799                	li	a5,6
40018570:	4581                	li	a1,0
40018572:	6f840513          	add	a0,s0,1784
40018576:	7af102a3          	sb	a5,1957(sp)
4001857a:	2c5000ef          	jal	4001903e <memset>
4001857e:	6785                	lui	a5,0x1
40018580:	82878793          	add	a5,a5,-2008 # 828 <mfdc+0x2f>
40018584:	00f10433          	add	s0,sp,a5
40018588:	500115b7          	lui	a1,0x50011
4001858c:	4639                	li	a2,14
4001858e:	01858593          	add	a1,a1,24 # 50011018 <__func__.2+0x398>
40018592:	00440513          	add	a0,s0,4
40018596:	351000ef          	jal	400190e6 <memcpy>
4001859a:	50011537          	lui	a0,0x50011
4001859e:	02850513          	add	a0,a0,40 # 50011028 <__func__.2+0x3a8>
400185a2:	ae7fd0ef          	jal	40016088 <puts>
400185a6:	4901                	li	s2,0
400185a8:	4a3d                	li	s4,15
400185aa:	02000993          	li	s3,32
400185ae:	404c                	lw	a1,4(s0)
400185b0:	b9048513          	add	a0,s1,-1136
400185b4:	ad7fd0ef          	jal	4001608a <printf>
400185b8:	00f97793          	and	a5,s2,15
400185bc:	01479563          	bne	a5,s4,400185c6 <idevid+0x1e2>
400185c0:	4529                	li	a0,10
400185c2:	ac1fd0ef          	jal	40016082 <putchar>
400185c6:	0905                	add	s2,s2,1
400185c8:	0411                	add	s0,s0,4
400185ca:	ff3912e3          	bne	s2,s3,400185ae <idevid+0x1ca>
400185ce:	4529                	li	a0,10
400185d0:	1a00                	add	s0,sp,304
400185d2:	ab1fd0ef          	jal	40016082 <putchar>
400185d6:	08200613          	li	a2,130
400185da:	4581                	li	a1,0
400185dc:	77e40513          	add	a0,s0,1918
400185e0:	25f000ef          	jal	4001903e <memset>
400185e4:	4905                	li	s2,1
400185e6:	67440593          	add	a1,s0,1652
400185ea:	498d                	li	s3,3
400185ec:	08400613          	li	a2,132
400185f0:	1c040513          	add	a0,s0,448
400185f4:	77240e23          	sb	s2,1916(s0)
400185f8:	77340ea3          	sb	s3,1917(s0)
400185fc:	2eb000ef          	jal	400190e6 <memcpy>
40018600:	6f840593          	add	a1,s0,1784
40018604:	08400613          	li	a2,132
40018608:	13040513          	add	a0,s0,304
4001860c:	2db000ef          	jal	400190e6 <memcpy>
40018610:	56c40593          	add	a1,s0,1388
40018614:	08400613          	li	a2,132
40018618:	0a040513          	add	a0,s0,160
4001861c:	2cb000ef          	jal	400190e6 <memcpy>
40018620:	77c40593          	add	a1,s0,1916
40018624:	08400613          	li	a2,132
40018628:	01040513          	add	a0,s0,16
4001862c:	2bb000ef          	jal	400190e6 <memcpy>
40018630:	0294                	add	a3,sp,320
40018632:	0b90                	add	a2,sp,464
40018634:	148c                	add	a1,sp,608
40018636:	1d88                	add	a0,sp,752
40018638:	c1afd0ef          	jal	40015a52 <hmac_flow>
4001863c:	50011537          	lui	a0,0x50011
40018640:	dd450513          	add	a0,a0,-556 # 50010dd4 <__func__.2+0x154>
40018644:	a45fd0ef          	jal	40016088 <puts>
40018648:	03200613          	li	a2,50
4001864c:	4581                	li	a1,0
4001864e:	29240513          	add	a0,s0,658
40018652:	1ed000ef          	jal	4001903e <memset>
40018656:	03400613          	li	a2,52
4001865a:	4581                	li	a1,0
4001865c:	2c440513          	add	a0,s0,708
40018660:	29240823          	sb	s2,656(s0)
40018664:	293408a3          	sb	s3,657(s0)
40018668:	1d7000ef          	jal	4001903e <memset>
4001866c:	03400613          	li	a2,52
40018670:	4581                	li	a1,0
40018672:	2f840513          	add	a0,s0,760
40018676:	1c9000ef          	jal	4001903e <memset>
4001867a:	03200613          	li	a2,50
4001867e:	4581                	li	a1,0
40018680:	32e40513          	add	a0,s0,814
40018684:	1bb000ef          	jal	4001903e <memset>
40018688:	479d                	li	a5,7
4001868a:	03400613          	li	a2,52
4001868e:	4581                	li	a1,0
40018690:	36040513          	add	a0,s0,864
40018694:	32f406a3          	sb	a5,813(s0)
40018698:	33240623          	sb	s2,812(s0)
4001869c:	1a3000ef          	jal	4001903e <memset>
400186a0:	03400613          	li	a2,52
400186a4:	4581                	li	a1,0
400186a6:	39440513          	add	a0,s0,916
400186aa:	37240023          	sb	s2,864(s0)
400186ae:	191000ef          	jal	4001903e <memset>
400186b2:	39240a23          	sb	s2,916(s0)
400186b6:	49010413          	add	s0,sp,1168
400186ba:	4c410793          	add	a5,sp,1220
400186be:	8722                	mv	a4,s0
400186c0:	45c10693          	add	a3,sp,1116
400186c4:	42810613          	add	a2,sp,1064
400186c8:	1fcc                	add	a1,sp,1012
400186ca:	0788                	add	a0,sp,960
400186cc:	c37fc0ef          	jal	40015302 <ecc_keygen_flow>
400186d0:	50011537          	lui	a0,0x50011
400186d4:	03c50513          	add	a0,a0,60 # 5001103c <__func__.2+0x3bc>
400186d8:	9b1fd0ef          	jal	40016088 <puts>
400186dc:	50011537          	lui	a0,0x50011
400186e0:	07850513          	add	a0,a0,120 # 50011078 <__func__.2+0x3f8>
400186e4:	9a5fd0ef          	jal	40016088 <puts>
400186e8:	4c010913          	add	s2,sp,1216
400186ec:	404c                	lw	a1,4(s0)
400186ee:	b9048513          	add	a0,s1,-1136
400186f2:	0411                	add	s0,s0,4
400186f4:	997fd0ef          	jal	4001608a <printf>
400186f8:	ff241ae3          	bne	s0,s2,400186ec <idevid+0x308>
400186fc:	4529                	li	a0,10
400186fe:	985fd0ef          	jal	40016082 <putchar>
40018702:	50011537          	lui	a0,0x50011
40018706:	08850513          	add	a0,a0,136 # 50011088 <__func__.2+0x408>
4001870a:	97ffd0ef          	jal	40016088 <puts>
4001870e:	4c410413          	add	s0,sp,1220
40018712:	4f410913          	add	s2,sp,1268
40018716:	404c                	lw	a1,4(s0)
40018718:	b9048513          	add	a0,s1,-1136
4001871c:	0411                	add	s0,s0,4
4001871e:	96dfd0ef          	jal	4001608a <printf>
40018722:	ff241ae3          	bne	s0,s2,40018716 <idevid+0x332>
40018726:	4529                	li	a0,10
40018728:	95bfd0ef          	jal	40016082 <putchar>
4001872c:	0220000f          	fence	r,r
40018730:	0220000f          	fence	r,r
40018734:	100187b7          	lui	a5,0x10018
40018738:	07b1                	add	a5,a5,12 # 1001800c <mfdc+0x10017813>
4001873a:	4711                	li	a4,4
4001873c:	c398                	sw	a4,0(a5)
4001873e:	4380                	lw	s0,0(a5)
40018740:	8811                	and	s0,s0,4
40018742:	fc75                	bnez	s0,4001873e <idevid+0x35a>
40018744:	50011537          	lui	a0,0x50011
40018748:	e3c50513          	add	a0,a0,-452 # 50010e3c <__func__.2+0x1bc>
4001874c:	93dfd0ef          	jal	40016088 <puts>
40018750:	6785                	lui	a5,0x1
40018752:	93078793          	add	a5,a5,-1744 # 930 <mfdc+0x137>
40018756:	00f10a33          	add	s4,sp,a5
4001875a:	50011637          	lui	a2,0x50011
4001875e:	e7460693          	add	a3,a2,-396 # 50010e74 <__func__.2+0x1f4>
40018762:	4801                	li	a6,0
40018764:	073c                	add	a5,sp,904
40018766:	8752                	mv	a4,s4
40018768:	e7460613          	add	a2,a2,-396
4001876c:	4c810593          	add	a1,sp,1224
40018770:	49410513          	add	a0,sp,1172
40018774:	fb7fe0ef          	jal	4001772a <generate_intermediate_tbs_der>
40018778:	89aa                	mv	s3,a0
4001877a:	24051263          	bnez	a0,400189be <idevid+0x5da>
4001877e:	6785                	lui	a5,0x1
40018780:	80078793          	add	a5,a5,-2048 # 800 <mfdc+0x7>
40018784:	38812583          	lw	a1,904(sp)
40018788:	13010a93          	add	s5,sp,304
4001878c:	22b7e963          	bltu	a5,a1,400189be <idevid+0x5da>
40018790:	50011937          	lui	s2,0x50011
40018794:	e8890513          	add	a0,s2,-376 # 50010e88 <__func__.2+0x208>
40018798:	8f3fd0ef          	jal	4001608a <printf>
4001879c:	50011537          	lui	a0,0x50011
400187a0:	09850513          	add	a0,a0,152 # 50011098 <__func__.2+0x418>
400187a4:	8e5fd0ef          	jal	40016088 <puts>
400187a8:	4b3d                	li	s6,15
400187aa:	50011bb7          	lui	s7,0x50011
400187ae:	50011c37          	lui	s8,0x50011
400187b2:	50011cb7          	lui	s9,0x50011
400187b6:	258aa783          	lw	a5,600(s5)
400187ba:	1ef9e263          	bltu	s3,a5,4001899e <idevid+0x5ba>
400187be:	4529                	li	a0,10
400187c0:	8c3fd0ef          	jal	40016082 <putchar>
400187c4:	5001f537          	lui	a0,0x5001f
400187c8:	258aab03          	lw	s6,600(s5)
400187cc:	82050793          	add	a5,a0,-2016 # 5001e820 <tbs_der_store>
400187d0:	2167a023          	sw	s6,512(a5)
400187d4:	20078223          	sb	zero,516(a5)
400187d8:	6785                	lui	a5,0x1
400187da:	93078793          	add	a5,a5,-1744 # 930 <mfdc+0x137>
400187de:	00f109b3          	add	s3,sp,a5
400187e2:	865a                	mv	a2,s6
400187e4:	85ce                	mv	a1,s3
400187e6:	82050513          	add	a0,a0,-2016
400187ea:	0fd000ef          	jal	400190e6 <memcpy>
400187ee:	39010a13          	add	s4,sp,912
400187f2:	4685                	li	a3,1
400187f4:	8652                	mv	a2,s4
400187f6:	85da                	mv	a1,s6
400187f8:	854e                	mv	a0,s3
400187fa:	d16fe0ef          	jal	40016d10 <sha384_digest>
400187fe:	03400613          	li	a2,52
40018802:	4581                	li	a1,0
40018804:	3c8a8513          	add	a0,s5,968
40018808:	037000ef          	jal	4001903e <memset>
4001880c:	1a14                	add	a3,sp,304
4001880e:	03000513          	li	a0,48
40018812:	008a07b3          	add	a5,s4,s0
40018816:	4390                	lw	a2,0(a5)
40018818:	43cc                	lw	a1,4(a5)
4001881a:	40068793          	add	a5,a3,1024
4001881e:	db8c                	sw	a1,48(a5)
40018820:	dbd0                	sw	a2,52(a5)
40018822:	4fc10793          	add	a5,sp,1276
40018826:	97a2                	add	a5,a5,s0
40018828:	c38c                	sw	a1,0(a5)
4001882a:	c3d0                	sw	a2,4(a5)
4001882c:	0421                	add	s0,s0,8
4001882e:	4f810993          	add	s3,sp,1272
40018832:	fea410e3          	bne	s0,a0,40018812 <idevid+0x42e>
40018836:	50011537          	lui	a0,0x50011
4001883a:	ed450513          	add	a0,a0,-300 # 50010ed4 <__func__.2+0x254>
4001883e:	84bfd0ef          	jal	40016088 <puts>
40018842:	52810413          	add	s0,sp,1320
40018846:	0049a583          	lw	a1,4(s3)
4001884a:	b9048513          	add	a0,s1,-1136
4001884e:	0991                	add	s3,s3,4
40018850:	83bfd0ef          	jal	4001608a <printf>
40018854:	fe8999e3          	bne	s3,s0,40018846 <idevid+0x462>
40018858:	4529                	li	a0,10
4001885a:	829fd0ef          	jal	40016082 <putchar>
4001885e:	03400613          	li	a2,52
40018862:	4581                	li	a1,0
40018864:	52c10513          	add	a0,sp,1324
40018868:	7d6000ef          	jal	4001903e <memset>
4001886c:	4485                	li	s1,1
4001886e:	03400613          	li	a2,52
40018872:	4581                	li	a1,0
40018874:	56010513          	add	a0,sp,1376
40018878:	52910623          	sb	s1,1324(sp)
4001887c:	52c10413          	add	s0,sp,1324
40018880:	7be000ef          	jal	4001903e <memset>
40018884:	56010713          	add	a4,sp,1376
40018888:	86a2                	mv	a3,s0
4001888a:	42810613          	add	a2,sp,1064
4001888e:	4f810593          	add	a1,sp,1272
40018892:	45c10513          	add	a0,sp,1116
40018896:	56910023          	sb	s1,1376(sp)
4001889a:	dc5fc0ef          	jal	4001565e <ecc_signing_flow>
4001889e:	50011537          	lui	a0,0x50011
400188a2:	ee450513          	add	a0,a0,-284 # 50010ee4 <__func__.2+0x264>
400188a6:	fe2fd0ef          	jal	40016088 <puts>
400188aa:	55c10993          	add	s3,sp,1372
400188ae:	500114b7          	lui	s1,0x50011
400188b2:	404c                	lw	a1,4(s0)
400188b4:	ef448513          	add	a0,s1,-268 # 50010ef4 <__func__.2+0x274>
400188b8:	0411                	add	s0,s0,4
400188ba:	fd0fd0ef          	jal	4001608a <printf>
400188be:	fe899ae3          	bne	s3,s0,400188b2 <idevid+0x4ce>
400188c2:	50011537          	lui	a0,0x50011
400188c6:	efc50513          	add	a0,a0,-260 # 50010efc <__func__.2+0x27c>
400188ca:	fbefd0ef          	jal	40016088 <puts>
400188ce:	56010413          	add	s0,sp,1376
400188d2:	59010993          	add	s3,sp,1424
400188d6:	404c                	lw	a1,4(s0)
400188d8:	ef448513          	add	a0,s1,-268
400188dc:	0411                	add	s0,s0,4
400188de:	facfd0ef          	jal	4001608a <printf>
400188e2:	ff341ae3          	bne	s0,s3,400188d6 <idevid+0x4f2>
400188e6:	4529                	li	a0,10
400188e8:	1a00                	add	s0,sp,304
400188ea:	f98fd0ef          	jal	40016082 <putchar>
400188ee:	03400613          	li	a2,52
400188f2:	3c840593          	add	a1,s0,968
400188f6:	fd040513          	add	a0,s0,-48
400188fa:	7ec000ef          	jal	400190e6 <memcpy>
400188fe:	03400613          	li	a2,52
40018902:	36040593          	add	a1,s0,864
40018906:	f9040513          	add	a0,s0,-112
4001890a:	7dc000ef          	jal	400190e6 <memcpy>
4001890e:	03400613          	li	a2,52
40018912:	39440593          	add	a1,s0,916
40018916:	f5040513          	add	a0,s0,-176
4001891a:	7cc000ef          	jal	400190e6 <memcpy>
4001891e:	03400613          	li	a2,52
40018922:	3fc40593          	add	a1,s0,1020
40018926:	f1040513          	add	a0,s0,-240
4001892a:	7bc000ef          	jal	400190e6 <memcpy>
4001892e:	03400613          	li	a2,52
40018932:	43040593          	add	a1,s0,1072
40018936:	850a                	mv	a0,sp
40018938:	7ae000ef          	jal	400190e6 <memcpy>
4001893c:	870a                	mv	a4,sp
4001893e:	0094                	add	a3,sp,64
40018940:	0110                	add	a2,sp,128
40018942:	018c                	add	a1,sp,192
40018944:	0208                	add	a0,sp,256
40018946:	f79fc0ef          	jal	400158be <ecc_verifying_flow>
4001894a:	e149                	bnez	a0,400189cc <idevid+0x5e8>
4001894c:	50011537          	lui	a0,0x50011
40018950:	f6050513          	add	a0,a0,-160 # 50010f60 <__func__.2+0x2e0>
40018954:	f34fd0ef          	jal	40016088 <puts>
40018958:	46a5                	li	a3,9
4001895a:	4621                	li	a2,8
4001895c:	4c810593          	add	a1,sp,1224
40018960:	49410513          	add	a0,sp,1172
40018964:	805fc0ef          	jal	40015168 <store_to_datavault>
40018968:	6505                	lui	a0,0x1
4001896a:	13050793          	add	a5,a0,304 # 1130 <mfdc+0x937>
4001896e:	00f109b3          	add	s3,sp,a5
40018972:	93050513          	add	a0,a0,-1744
40018976:	077c                	add	a5,sp,908
40018978:	874e                	mv	a4,s3
4001897a:	56410693          	add	a3,sp,1380
4001897e:	53010613          	add	a2,sp,1328
40018982:	25842583          	lw	a1,600(s0)
40018986:	950a                	add	a0,a0,sp
40018988:	902ff0ef          	jal	40017a8a <add_signature_to_cert>
4001898c:	84aa                	mv	s1,a0
4001898e:	c531                	beqz	a0,400189da <idevid+0x5f6>
40018990:	50011537          	lui	a0,0x50011
40018994:	0a850513          	add	a0,a0,168 # 500110a8 <__func__.2+0x428>
40018998:	ef0fd0ef          	jal	40016088 <puts>
4001899c:	a001                	j	4001899c <idevid+0x5b8>
4001899e:	013a07b3          	add	a5,s4,s3
400189a2:	0007c603          	lbu	a2,0(a5)
400189a6:	cd4b8593          	add	a1,s7,-812 # 50010cd4 <__func__.2+0x54>
400189aa:	00cb6463          	bltu	s6,a2,400189b2 <idevid+0x5ce>
400189ae:	d08c0593          	add	a1,s8,-760 # 50010d08 <__func__.2+0x88>
400189b2:	eacc8513          	add	a0,s9,-340 # 50010eac <__func__.2+0x22c>
400189b6:	ed4fd0ef          	jal	4001608a <printf>
400189ba:	0985                	add	s3,s3,1
400189bc:	bbed                	j	400187b6 <idevid+0x3d2>
400189be:	50011537          	lui	a0,0x50011
400189c2:	0a850513          	add	a0,a0,168 # 500110a8 <__func__.2+0x428>
400189c6:	ec2fd0ef          	jal	40016088 <puts>
400189ca:	a001                	j	400189ca <idevid+0x5e6>
400189cc:	50011537          	lui	a0,0x50011
400189d0:	f8450513          	add	a0,a0,-124 # 50010f84 <__func__.2+0x304>
400189d4:	eb4fd0ef          	jal	40016088 <puts>
400189d8:	a001                	j	400189d8 <idevid+0x5f4>
400189da:	25c42583          	lw	a1,604(s0)
400189de:	6785                	lui	a5,0x1
400189e0:	fab7e8e3          	bltu	a5,a1,40018990 <idevid+0x5ac>
400189e4:	e8890513          	add	a0,s2,-376
400189e8:	ea2fd0ef          	jal	4001608a <printf>
400189ec:	50011537          	lui	a0,0x50011
400189f0:	0c850513          	add	a0,a0,200 # 500110c8 <__func__.2+0x448>
400189f4:	e94fd0ef          	jal	40016088 <puts>
400189f8:	493d                	li	s2,15
400189fa:	50011a37          	lui	s4,0x50011
400189fe:	50011ab7          	lui	s5,0x50011
40018a02:	50011b37          	lui	s6,0x50011
40018a06:	25c42783          	lw	a5,604(s0)
40018a0a:	06f4e163          	bltu	s1,a5,40018a6c <idevid+0x688>
40018a0e:	4529                	li	a0,10
40018a10:	e72fd0ef          	jal	40016082 <putchar>
40018a14:	5001e537          	lui	a0,0x5001e
40018a18:	00050793          	mv	a5,a0
40018a1c:	25c42603          	lw	a2,604(s0)
40018a20:	20c7a023          	sw	a2,512(a5) # 1200 <mfdc+0xa07>
40018a24:	20078223          	sb	zero,516(a5)
40018a28:	6785                	lui	a5,0x1
40018a2a:	13078793          	add	a5,a5,304 # 1130 <mfdc+0x937>
40018a2e:	00f105b3          	add	a1,sp,a5
40018a32:	00050513          	mv	a0,a0
40018a36:	2d45                	jal	400190e6 <memcpy>
40018a38:	6289                	lui	t0,0x2
40018a3a:	9116                	add	sp,sp,t0
40018a3c:	15c12083          	lw	ra,348(sp)
40018a40:	15812403          	lw	s0,344(sp)
40018a44:	15412483          	lw	s1,340(sp)
40018a48:	15012903          	lw	s2,336(sp)
40018a4c:	14c12983          	lw	s3,332(sp)
40018a50:	14812a03          	lw	s4,328(sp)
40018a54:	14412a83          	lw	s5,324(sp)
40018a58:	14012b03          	lw	s6,320(sp)
40018a5c:	13c12b83          	lw	s7,316(sp)
40018a60:	13812c03          	lw	s8,312(sp)
40018a64:	13412c83          	lw	s9,308(sp)
40018a68:	6135                	add	sp,sp,352
40018a6a:	8082                	ret
40018a6c:	009987b3          	add	a5,s3,s1
40018a70:	0007c603          	lbu	a2,0(a5)
40018a74:	cd4a0593          	add	a1,s4,-812 # 50010cd4 <__func__.2+0x54>
40018a78:	00c96463          	bltu	s2,a2,40018a80 <idevid+0x69c>
40018a7c:	d08a8593          	add	a1,s5,-760 # 50010d08 <__func__.2+0x88>
40018a80:	eacb0513          	add	a0,s6,-340 # 50010eac <__func__.2+0x22c>
40018a84:	e06fd0ef          	jal	4001608a <printf>
40018a88:	0485                	add	s1,s1,1
40018a8a:	bfb5                	j	40018a06 <idevid+0x622>

40018a8c <init_doe>:
40018a8c:	2eb94737          	lui	a4,0x2eb94
40018a90:	100007b7          	lui	a5,0x10000
40018a94:	29770713          	add	a4,a4,663 # 2eb94297 <mfdc+0x2eb93a9e>
40018a98:	772856b7          	lui	a3,0x77285
40018a9c:	c398                	sw	a4,0(a5)
40018a9e:	19668693          	add	a3,a3,406 # 77285196 <_tbs_der_store_end+0x27266176>
40018aa2:	c3d4                	sw	a3,4(a5)
40018aa4:	3dd3a6b7          	lui	a3,0x3dd3a
40018aa8:	a1e68693          	add	a3,a3,-1506 # 3dd39a1e <mfdc+0x3dd39225>
40018aac:	c794                	sw	a3,8(a5)
40018aae:	b95d46b7          	lui	a3,0xb95d4
40018ab2:	38f68693          	add	a3,a3,911 # b95d438f <_tbs_der_store_end+0x695b536f>
40018ab6:	c7d4                	sw	a3,12(a5)
40018ab8:	0220000f          	fence	r,r
40018abc:	0220000f          	fence	r,r
40018ac0:	4685                	li	a3,1
40018ac2:	cb94                	sw	a3,16(a5)
40018ac4:	01478693          	add	a3,a5,20 # 10000014 <mfdc+0xffff81b>
40018ac8:	4298                	lw	a4,0(a3)
40018aca:	8b09                	and	a4,a4,2
40018acc:	df75                	beqz	a4,40018ac8 <init_doe+0x3c>
40018ace:	14451737          	lui	a4,0x14451
40018ad2:	62470713          	add	a4,a4,1572 # 14451624 <mfdc+0x14450e2b>
40018ad6:	c398                	sw	a4,0(a5)
40018ad8:	6a753737          	lui	a4,0x6a753
40018adc:	c3270713          	add	a4,a4,-974 # 6a752c32 <_tbs_der_store_end+0x1a733c12>
40018ae0:	c3d8                	sw	a4,4(a5)
40018ae2:	9056e737          	lui	a4,0x9056e
40018ae6:	88470713          	add	a4,a4,-1916 # 9056d884 <_tbs_der_store_end+0x4054e864>
40018aea:	c798                	sw	a4,8(a5)
40018aec:	daf3d737          	lui	a4,0xdaf3d
40018af0:	89d70713          	add	a4,a4,-1891 # daf3c89d <_tbs_der_store_end+0x8af1d87d>
40018af4:	c7d8                	sw	a4,12(a5)
40018af6:	0220000f          	fence	r,r
40018afa:	0220000f          	fence	r,r
40018afe:	100007b7          	lui	a5,0x10000
40018b02:	4719                	li	a4,6
40018b04:	cb98                	sw	a4,16(a5)
40018b06:	01478713          	add	a4,a5,20 # 10000014 <mfdc+0xffff81b>
40018b0a:	431c                	lw	a5,0(a4)
40018b0c:	8b89                	and	a5,a5,2
40018b0e:	dff5                	beqz	a5,40018b0a <init_doe+0x7e>
40018b10:	0220000f          	fence	r,r
40018b14:	0220000f          	fence	r,r
40018b18:	100007b7          	lui	a5,0x10000
40018b1c:	470d                	li	a4,3
40018b1e:	cb98                	sw	a4,16(a5)
40018b20:	8082                	ret

40018b22 <main>:
40018b22:	db010113          	add	sp,sp,-592
40018b26:	24112623          	sw	ra,588(sp)
40018b2a:	24812423          	sw	s0,584(sp)
40018b2e:	24912223          	sw	s1,580(sp)
40018b32:	23412c23          	sw	s4,568(sp)
40018b36:	25212023          	sw	s2,576(sp)
40018b3a:	50011a37          	lui	s4,0x50011
40018b3e:	23312e23          	sw	s3,572(sp)
40018b42:	23512a23          	sw	s5,564(sp)
40018b46:	23612823          	sw	s6,560(sp)
40018b4a:	23712623          	sw	s7,556(sp)
40018b4e:	23812423          	sw	s8,552(sp)
40018b52:	23912223          	sw	s9,548(sp)
40018b56:	23a12023          	sw	s10,544(sp)
40018b5a:	21b12e23          	sw	s11,540(sp)
40018b5e:	a83fe0ef          	jal	400175e0 <init_uart>
40018b62:	f2efd0ef          	jal	40016290 <init_qspi>
40018b66:	0d8a0513          	add	a0,s4,216 # 500110d8 <__func__.2+0x458>
40018b6a:	d1efd0ef          	jal	40016088 <puts>
40018b6e:	50011537          	lui	a0,0x50011
40018b72:	10050513          	add	a0,a0,256 # 50011100 <__func__.2+0x480>
40018b76:	d12fd0ef          	jal	40016088 <puts>
40018b7a:	0d8a0513          	add	a0,s4,216
40018b7e:	d0afd0ef          	jal	40016088 <puts>
40018b82:	50011637          	lui	a2,0x50011
40018b86:	500115b7          	lui	a1,0x50011
40018b8a:	50011537          	lui	a0,0x50011
40018b8e:	12860613          	add	a2,a2,296 # 50011128 <__func__.2+0x4a8>
40018b92:	13458593          	add	a1,a1,308 # 50011134 <__func__.2+0x4b4>
40018b96:	14050513          	add	a0,a0,320 # 50011140 <__func__.2+0x4c0>
40018b9a:	cf0fd0ef          	jal	4001608a <printf>
40018b9e:	eefff0ef          	jal	40018a8c <init_doe>
40018ba2:	843ff0ef          	jal	400183e4 <idevid>
40018ba6:	8d0ff0ef          	jal	40017c76 <ldevid>
40018baa:	b19fd0ef          	jal	400166c2 <init_sd_card>
40018bae:	500134b7          	lui	s1,0x50013
40018bb2:	0800                	add	s0,sp,16
40018bb4:	1c051663          	bnez	a0,40018d80 <main+0x25e>
40018bb8:	892a                	mv	s2,a0
40018bba:	50011537          	lui	a0,0x50011
40018bbe:	15850513          	add	a0,a0,344 # 50011158 <__func__.2+0x4d8>
40018bc2:	6b85                	lui	s7,0x1
40018bc4:	cc4fd0ef          	jal	40016088 <puts>
40018bc8:	27048a93          	add	s5,s1,624 # 50013270 <FMC_data>
40018bcc:	27048b13          	add	s6,s1,624
40018bd0:	4981                	li	s3,0
40018bd2:	800b8b93          	add	s7,s7,-2048 # 800 <mfdc+0x7>
40018bd6:	50011cb7          	lui	s9,0x50011
40018bda:	50011d37          	lui	s10,0x50011
40018bde:	4dbd                	li	s11,15
40018be0:	20000613          	li	a2,512
40018be4:	0ff00593          	li	a1,255
40018be8:	8522                	mv	a0,s0
40018bea:	2991                	jal	4001903e <memset>
40018bec:	4681                	li	a3,0
40018bee:	4601                	li	a2,0
40018bf0:	85a2                	mv	a1,s0
40018bf2:	01798533          	add	a0,s3,s7
40018bf6:	bbffd0ef          	jal	400167b4 <read_sd_card>
40018bfa:	c42a                	sw	a0,8(sp)
40018bfc:	02099c63          	bnez	s3,40018c34 <main+0x112>
40018c00:	4581                	li	a1,0
40018c02:	168c8513          	add	a0,s9,360 # 50011168 <__func__.2+0x4e8>
40018c06:	c84fd0ef          	jal	4001608a <printf>
40018c0a:	4c01                	li	s8,0
40018c0c:	01840733          	add	a4,s0,s8
40018c10:	00074583          	lbu	a1,0(a4)
40018c14:	170d0513          	add	a0,s10,368 # 50011170 <__func__.2+0x4f0>
40018c18:	c72fd0ef          	jal	4001608a <printf>
40018c1c:	00fc7713          	and	a4,s8,15
40018c20:	01b71563          	bne	a4,s11,40018c2a <main+0x108>
40018c24:	4529                	li	a0,10
40018c26:	c5cfd0ef          	jal	40016082 <putchar>
40018c2a:	0c05                	add	s8,s8,1
40018c2c:	20000793          	li	a5,512
40018c30:	fcfc1ee3          	bne	s8,a5,40018c0c <main+0xea>
40018c34:	855a                	mv	a0,s6
40018c36:	20000613          	li	a2,512
40018c3a:	85a2                	mv	a1,s0
40018c3c:	216d                	jal	400190e6 <memcpy>
40018c3e:	0985                	add	s3,s3,1
40018c40:	02800793          	li	a5,40
40018c44:	200b0b13          	add	s6,s6,512
40018c48:	f8f99ce3          	bne	s3,a5,40018be0 <main+0xbe>
40018c4c:	4529                	li	a0,10
40018c4e:	c34fd0ef          	jal	40016082 <putchar>
40018c52:	47a2                	lw	a5,8(sp)
40018c54:	eb9d                	bnez	a5,40018c8a <main+0x168>
40018c56:	50011537          	lui	a0,0x50011
40018c5a:	17850513          	add	a0,a0,376 # 50011178 <__func__.2+0x4f8>
40018c5e:	c2afd0ef          	jal	40016088 <puts>
40018c62:	6595                	lui	a1,0x5
40018c64:	27048513          	add	a0,s1,624
40018c68:	e46fe0ef          	jal	400172ae <measure_fmc>
40018c6c:	0ff57513          	zext.b	a0,a0
40018c70:	ed09                	bnez	a0,40018c8a <main+0x168>
40018c72:	400007b7          	lui	a5,0x40000
40018c76:	40005737          	lui	a4,0x40005
40018c7a:	000aa683          	lw	a3,0(s5)
40018c7e:	c394                	sw	a3,0(a5)
40018c80:	0791                	add	a5,a5,4 # 40000004 <mfdc+0x3ffff80b>
40018c82:	0a91                	add	s5,s5,4
40018c84:	fee79be3          	bne	a5,a4,40018c7a <main+0x158>
40018c88:	4905                	li	s2,1
40018c8a:	50011537          	lui	a0,0x50011
40018c8e:	18c50513          	add	a0,a0,396 # 5001118c <__func__.2+0x50c>
40018c92:	50011bb7          	lui	s7,0x50011
40018c96:	6b09                	lui	s6,0x2
40018c98:	bf0fd0ef          	jal	40016088 <puts>
40018c9c:	270b8a93          	add	s5,s7,624 # 50011270 <SOC_FW_data>
40018ca0:	4981                	li	s3,0
40018ca2:	20000d93          	li	s11,512
40018ca6:	800b0b13          	add	s6,s6,-2048 # 1800 <mfdc+0x1007>
40018caa:	50011c37          	lui	s8,0x50011
40018cae:	50011cb7          	lui	s9,0x50011
40018cb2:	4d3d                	li	s10,15
40018cb4:	20000613          	li	a2,512
40018cb8:	0ff00593          	li	a1,255
40018cbc:	8522                	mv	a0,s0
40018cbe:	2641                	jal	4001903e <memset>
40018cc0:	4601                	li	a2,0
40018cc2:	4681                	li	a3,0
40018cc4:	85a2                	mv	a1,s0
40018cc6:	01698533          	add	a0,s3,s6
40018cca:	aebfd0ef          	jal	400167b4 <read_sd_card>
40018cce:	c42a                	sw	a0,8(sp)
40018cd0:	85ce                	mv	a1,s3
40018cd2:	168c0513          	add	a0,s8,360 # 50011168 <__func__.2+0x4e8>
40018cd6:	bb4fd0ef          	jal	4001608a <printf>
40018cda:	4601                	li	a2,0
40018cdc:	00c407b3          	add	a5,s0,a2
40018ce0:	0007c583          	lbu	a1,0(a5)
40018ce4:	170c8513          	add	a0,s9,368 # 50011170 <__func__.2+0x4f0>
40018ce8:	c632                	sw	a2,12(sp)
40018cea:	ba0fd0ef          	jal	4001608a <printf>
40018cee:	4632                	lw	a2,12(sp)
40018cf0:	00f67793          	and	a5,a2,15
40018cf4:	01a79663          	bne	a5,s10,40018d00 <main+0x1de>
40018cf8:	4529                	li	a0,10
40018cfa:	b88fd0ef          	jal	40016082 <putchar>
40018cfe:	4632                	lw	a2,12(sp)
40018d00:	0605                	add	a2,a2,1
40018d02:	fdb61de3          	bne	a2,s11,40018cdc <main+0x1ba>
40018d06:	8556                	mv	a0,s5
40018d08:	85a2                	mv	a1,s0
40018d0a:	2ef1                	jal	400190e6 <memcpy>
40018d0c:	0985                	add	s3,s3,1
40018d0e:	47c1                	li	a5,16
40018d10:	200a8a93          	add	s5,s5,512
40018d14:	faf990e3          	bne	s3,a5,40018cb4 <main+0x192>
40018d18:	4529                	li	a0,10
40018d1a:	b68fd0ef          	jal	40016082 <putchar>
40018d1e:	47a2                	lw	a5,8(sp)
40018d20:	efb1                	bnez	a5,40018d7c <main+0x25a>
40018d22:	50011537          	lui	a0,0x50011
40018d26:	19c50513          	add	a0,a0,412 # 5001119c <__func__.2+0x51c>
40018d2a:	b5efd0ef          	jal	40016088 <puts>
40018d2e:	6589                	lui	a1,0x2
40018d30:	270b8513          	add	a0,s7,624
40018d34:	ae2fe0ef          	jal	40017016 <measure_soc>
40018d38:	0ff57513          	zext.b	a0,a0
40018d3c:	e121                	bnez	a0,40018d7c <main+0x25a>
40018d3e:	50011537          	lui	a0,0x50011
40018d42:	6589                	lui	a1,0x2
40018d44:	27050513          	add	a0,a0,624 # 50011270 <SOC_FW_data>
40018d48:	eb7fc0ef          	jal	40015bfe <mailbox_send_data>
40018d4c:	50011537          	lui	a0,0x50011
40018d50:	1b050513          	add	a0,a0,432 # 500111b0 <__func__.2+0x530>
40018d54:	b34fd0ef          	jal	40016088 <puts>
40018d58:	400007b7          	lui	a5,0x40000
40018d5c:	9782                	jalr	a5
40018d5e:	0d8a0513          	add	a0,s4,216
40018d62:	b26fd0ef          	jal	40016088 <puts>
40018d66:	50011537          	lui	a0,0x50011
40018d6a:	20850513          	add	a0,a0,520 # 50011208 <__func__.2+0x588>
40018d6e:	b1afd0ef          	jal	40016088 <puts>
40018d72:	0d8a0513          	add	a0,s4,216
40018d76:	b12fd0ef          	jal	40016088 <puts>
40018d7a:	a001                	j	40018d7a <main+0x258>
40018d7c:	fc0918e3          	bnez	s2,40018d4c <main+0x22a>
40018d80:	50011537          	lui	a0,0x50011
40018d84:	1c050513          	add	a0,a0,448 # 500111c0 <__func__.2+0x540>
40018d88:	b00fd0ef          	jal	40016088 <puts>
40018d8c:	500137b7          	lui	a5,0x50013
40018d90:	6b85                	lui	s7,0x1
40018d92:	27078993          	add	s3,a5,624 # 50013270 <FMC_data>
40018d96:	27048b13          	add	s6,s1,624
40018d9a:	4901                	li	s2,0
40018d9c:	20000c13          	li	s8,512
40018da0:	800b8b93          	add	s7,s7,-2048 # 800 <mfdc+0x7>
40018da4:	50011cb7          	lui	s9,0x50011
40018da8:	50011d37          	lui	s10,0x50011
40018dac:	4dbd                	li	s11,15
40018dae:	20000613          	li	a2,512
40018db2:	0ff00593          	li	a1,255
40018db6:	8522                	mv	a0,s0
40018db8:	2459                	jal	4001903e <memset>
40018dba:	4681                	li	a3,0
40018dbc:	4601                	li	a2,0
40018dbe:	85a2                	mv	a1,s0
40018dc0:	01790533          	add	a0,s2,s7
40018dc4:	9f1fd0ef          	jal	400167b4 <read_sd_card>
40018dc8:	c42a                	sw	a0,8(sp)
40018dca:	02091a63          	bnez	s2,40018dfe <main+0x2dc>
40018dce:	4581                	li	a1,0
40018dd0:	168c8513          	add	a0,s9,360 # 50011168 <__func__.2+0x4e8>
40018dd4:	ab6fd0ef          	jal	4001608a <printf>
40018dd8:	4a81                	li	s5,0
40018dda:	01540733          	add	a4,s0,s5
40018dde:	00074583          	lbu	a1,0(a4) # 40005000 <mfdc+0x40004807>
40018de2:	170d0513          	add	a0,s10,368 # 50011170 <__func__.2+0x4f0>
40018de6:	aa4fd0ef          	jal	4001608a <printf>
40018dea:	00faf713          	and	a4,s5,15
40018dee:	01b71563          	bne	a4,s11,40018df8 <main+0x2d6>
40018df2:	4529                	li	a0,10
40018df4:	a8efd0ef          	jal	40016082 <putchar>
40018df8:	0a85                	add	s5,s5,1
40018dfa:	ff8a90e3          	bne	s5,s8,40018dda <main+0x2b8>
40018dfe:	855a                	mv	a0,s6
40018e00:	20000613          	li	a2,512
40018e04:	85a2                	mv	a1,s0
40018e06:	24c5                	jal	400190e6 <memcpy>
40018e08:	0905                	add	s2,s2,1
40018e0a:	02800793          	li	a5,40
40018e0e:	200b0b13          	add	s6,s6,512
40018e12:	f8f91ee3          	bne	s2,a5,40018dae <main+0x28c>
40018e16:	4529                	li	a0,10
40018e18:	a6afd0ef          	jal	40016082 <putchar>
40018e1c:	47a2                	lw	a5,8(sp)
40018e1e:	0e079b63          	bnez	a5,40018f14 <main+0x3f2>
40018e22:	50011537          	lui	a0,0x50011
40018e26:	1d050513          	add	a0,a0,464 # 500111d0 <__func__.2+0x550>
40018e2a:	a5efd0ef          	jal	40016088 <puts>
40018e2e:	6595                	lui	a1,0x5
40018e30:	27048513          	add	a0,s1,624
40018e34:	c7afe0ef          	jal	400172ae <measure_fmc>
40018e38:	0ff57513          	zext.b	a0,a0
40018e3c:	0c051c63          	bnez	a0,40018f14 <main+0x3f2>
40018e40:	400007b7          	lui	a5,0x40000
40018e44:	40005737          	lui	a4,0x40005
40018e48:	0009a683          	lw	a3,0(s3)
40018e4c:	c394                	sw	a3,0(a5)
40018e4e:	0791                	add	a5,a5,4 # 40000004 <mfdc+0x3ffff80b>
40018e50:	0991                	add	s3,s3,4
40018e52:	fee79be3          	bne	a5,a4,40018e48 <main+0x326>
40018e56:	4b05                	li	s6,1
40018e58:	50011537          	lui	a0,0x50011
40018e5c:	1e450513          	add	a0,a0,484 # 500111e4 <__func__.2+0x564>
40018e60:	50011bb7          	lui	s7,0x50011
40018e64:	6a89                	lui	s5,0x2
40018e66:	a22fd0ef          	jal	40016088 <puts>
40018e6a:	270b8993          	add	s3,s7,624 # 50011270 <SOC_FW_data>
40018e6e:	4481                	li	s1,0
40018e70:	20000c13          	li	s8,512
40018e74:	800a8a93          	add	s5,s5,-2048 # 1800 <mfdc+0x1007>
40018e78:	50011cb7          	lui	s9,0x50011
40018e7c:	50011d37          	lui	s10,0x50011
40018e80:	4dbd                	li	s11,15
40018e82:	20000613          	li	a2,512
40018e86:	0ff00593          	li	a1,255
40018e8a:	8522                	mv	a0,s0
40018e8c:	2a4d                	jal	4001903e <memset>
40018e8e:	4681                	li	a3,0
40018e90:	4601                	li	a2,0
40018e92:	85a2                	mv	a1,s0
40018e94:	01548533          	add	a0,s1,s5
40018e98:	91dfd0ef          	jal	400167b4 <read_sd_card>
40018e9c:	c42a                	sw	a0,8(sp)
40018e9e:	e88d                	bnez	s1,40018ed0 <main+0x3ae>
40018ea0:	4581                	li	a1,0
40018ea2:	168c8513          	add	a0,s9,360 # 50011168 <__func__.2+0x4e8>
40018ea6:	9e4fd0ef          	jal	4001608a <printf>
40018eaa:	4901                	li	s2,0
40018eac:	01240733          	add	a4,s0,s2
40018eb0:	00074583          	lbu	a1,0(a4) # 40005000 <mfdc+0x40004807>
40018eb4:	170d0513          	add	a0,s10,368 # 50011170 <__func__.2+0x4f0>
40018eb8:	9d2fd0ef          	jal	4001608a <printf>
40018ebc:	00f97713          	and	a4,s2,15
40018ec0:	01b71563          	bne	a4,s11,40018eca <main+0x3a8>
40018ec4:	4529                	li	a0,10
40018ec6:	9bcfd0ef          	jal	40016082 <putchar>
40018eca:	0905                	add	s2,s2,1
40018ecc:	ff8910e3          	bne	s2,s8,40018eac <main+0x38a>
40018ed0:	854e                	mv	a0,s3
40018ed2:	20000613          	li	a2,512
40018ed6:	85a2                	mv	a1,s0
40018ed8:	2439                	jal	400190e6 <memcpy>
40018eda:	0485                	add	s1,s1,1
40018edc:	47c1                	li	a5,16
40018ede:	20098993          	add	s3,s3,512
40018ee2:	faf490e3          	bne	s1,a5,40018e82 <main+0x360>
40018ee6:	4529                	li	a0,10
40018ee8:	99afd0ef          	jal	40016082 <putchar>
40018eec:	47a2                	lw	a5,8(sp)
40018eee:	e385                	bnez	a5,40018f0e <main+0x3ec>
40018ef0:	50011537          	lui	a0,0x50011
40018ef4:	1f450513          	add	a0,a0,500 # 500111f4 <__func__.2+0x574>
40018ef8:	990fd0ef          	jal	40016088 <puts>
40018efc:	6589                	lui	a1,0x2
40018efe:	270b8513          	add	a0,s7,624
40018f02:	914fe0ef          	jal	40017016 <measure_soc>
40018f06:	0ff57513          	zext.b	a0,a0
40018f0a:	e2050ae3          	beqz	a0,40018d3e <main+0x21c>
40018f0e:	e20b1fe3          	bnez	s6,40018d4c <main+0x22a>
40018f12:	b5b1                	j	40018d5e <main+0x23c>
40018f14:	4b01                	li	s6,0
40018f16:	b789                	j	40018e58 <main+0x336>

40018f18 <early_trap_vector>:
40018f18:	342022f3          	csrr	t0,mcause
40018f1c:	34102373          	csrr	t1,mepc
40018f20:	343023f3          	csrr	t2,mtval
40018f24:	30030e37          	lui	t3,0x30030
40018f28:	0cce0e13          	add	t3,t3,204 # 300300cc <mfdc+0x3002f8d3>
40018f2c:	0fff7e97          	auipc	t4,0xfff7
40018f30:	1bce8e93          	add	t4,t4,444 # 500100e8 <trap_msg>

40018f34 <trap_print_loop>:
40018f34:	000e8283          	lb	t0,0(t4)
40018f38:	005e0023          	sb	t0,0(t3)
40018f3c:	0e85                	add	t4,t4,1
40018f3e:	fe029be3          	bnez	t0,40018f34 <trap_print_loop>
40018f42:	4f05                	li	t5,1
40018f44:	01ee0023          	sb	t5,0(t3)
40018f48:	bfc1                	j	40018f18 <early_trap_vector>

40018f4a <__lshrdi3>:
40018f4a:	ca19                	beqz	a2,40018f60 <__lshrdi3+0x16>
40018f4c:	02000793          	li	a5,32
40018f50:	8f91                	sub	a5,a5,a2
40018f52:	00f04863          	bgtz	a5,40018f62 <__lshrdi3+0x18>
40018f56:	1601                	add	a2,a2,-32
40018f58:	00c5d533          	srl	a0,a1,a2
40018f5c:	4701                	li	a4,0
40018f5e:	85ba                	mv	a1,a4
40018f60:	8082                	ret
40018f62:	00c5d733          	srl	a4,a1,a2
40018f66:	00c55533          	srl	a0,a0,a2
40018f6a:	00f595b3          	sll	a1,a1,a5
40018f6e:	8d4d                	or	a0,a0,a1
40018f70:	b7fd                	j	40018f5e <__lshrdi3+0x14>

40018f72 <memmove>:
40018f72:	02a5f263          	bgeu	a1,a0,40018f96 <memmove+0x24>
40018f76:	00c58733          	add	a4,a1,a2
40018f7a:	00e57e63          	bgeu	a0,a4,40018f96 <memmove+0x24>
40018f7e:	00c507b3          	add	a5,a0,a2
40018f82:	ca1d                	beqz	a2,40018fb8 <memmove+0x46>
40018f84:	17fd                	add	a5,a5,-1
40018f86:	fff74683          	lbu	a3,-1(a4)
40018f8a:	00d78023          	sb	a3,0(a5)
40018f8e:	177d                	add	a4,a4,-1
40018f90:	fef51ae3          	bne	a0,a5,40018f84 <memmove+0x12>
40018f94:	8082                	ret
40018f96:	47bd                	li	a5,15
40018f98:	02c7e163          	bltu	a5,a2,40018fba <memmove+0x48>
40018f9c:	87aa                	mv	a5,a0
40018f9e:	fff60693          	add	a3,a2,-1
40018fa2:	ca59                	beqz	a2,40019038 <memmove+0xc6>
40018fa4:	0685                	add	a3,a3,1
40018fa6:	96be                	add	a3,a3,a5
40018fa8:	0785                	add	a5,a5,1
40018faa:	0005c703          	lbu	a4,0(a1) # 2000 <mfdc+0x1807>
40018fae:	fee78fa3          	sb	a4,-1(a5)
40018fb2:	0585                	add	a1,a1,1
40018fb4:	fed79ae3          	bne	a5,a3,40018fa8 <memmove+0x36>
40018fb8:	8082                	ret
40018fba:	00b567b3          	or	a5,a0,a1
40018fbe:	8b8d                	and	a5,a5,3
40018fc0:	eba5                	bnez	a5,40019030 <memmove+0xbe>
40018fc2:	ff060893          	add	a7,a2,-16
40018fc6:	ff08f893          	and	a7,a7,-16
40018fca:	08c1                	add	a7,a7,16
40018fcc:	011506b3          	add	a3,a0,a7
40018fd0:	872e                	mv	a4,a1
40018fd2:	87aa                	mv	a5,a0
40018fd4:	00072803          	lw	a6,0(a4)
40018fd8:	0107a023          	sw	a6,0(a5)
40018fdc:	00472803          	lw	a6,4(a4)
40018fe0:	0107a223          	sw	a6,4(a5)
40018fe4:	00872803          	lw	a6,8(a4)
40018fe8:	0107a423          	sw	a6,8(a5)
40018fec:	00c72803          	lw	a6,12(a4)
40018ff0:	07c1                	add	a5,a5,16
40018ff2:	ff07ae23          	sw	a6,-4(a5)
40018ff6:	0741                	add	a4,a4,16
40018ff8:	fcd79ee3          	bne	a5,a3,40018fd4 <memmove+0x62>
40018ffc:	00c67813          	and	a6,a2,12
40019000:	95c6                	add	a1,a1,a7
40019002:	00f67713          	and	a4,a2,15
40019006:	02080a63          	beqz	a6,4001903a <memmove+0xc8>
4001900a:	ffc70813          	add	a6,a4,-4
4001900e:	ffc87813          	and	a6,a6,-4
40019012:	0811                	add	a6,a6,4
40019014:	010687b3          	add	a5,a3,a6
40019018:	872e                	mv	a4,a1
4001901a:	0691                	add	a3,a3,4
4001901c:	00072883          	lw	a7,0(a4)
40019020:	ff16ae23          	sw	a7,-4(a3)
40019024:	0711                	add	a4,a4,4
40019026:	fef69ae3          	bne	a3,a5,4001901a <memmove+0xa8>
4001902a:	8a0d                	and	a2,a2,3
4001902c:	95c2                	add	a1,a1,a6
4001902e:	bf85                	j	40018f9e <memmove+0x2c>
40019030:	fff60693          	add	a3,a2,-1
40019034:	87aa                	mv	a5,a0
40019036:	b7bd                	j	40018fa4 <memmove+0x32>
40019038:	8082                	ret
4001903a:	863a                	mv	a2,a4
4001903c:	b78d                	j	40018f9e <memmove+0x2c>

4001903e <memset>:
4001903e:	433d                	li	t1,15
40019040:	872a                	mv	a4,a0
40019042:	02c37363          	bgeu	t1,a2,40019068 <memset+0x2a>
40019046:	00f77793          	and	a5,a4,15
4001904a:	efbd                	bnez	a5,400190c8 <memset+0x8a>
4001904c:	e5ad                	bnez	a1,400190b6 <memset+0x78>
4001904e:	ff067693          	and	a3,a2,-16
40019052:	8a3d                	and	a2,a2,15
40019054:	96ba                	add	a3,a3,a4
40019056:	c30c                	sw	a1,0(a4)
40019058:	c34c                	sw	a1,4(a4)
4001905a:	c70c                	sw	a1,8(a4)
4001905c:	c74c                	sw	a1,12(a4)
4001905e:	0741                	add	a4,a4,16
40019060:	fed76be3          	bltu	a4,a3,40019056 <memset+0x18>
40019064:	e211                	bnez	a2,40019068 <memset+0x2a>
40019066:	8082                	ret
40019068:	40c306b3          	sub	a3,t1,a2
4001906c:	068a                	sll	a3,a3,0x2
4001906e:	00000297          	auipc	t0,0x0
40019072:	9696                	add	a3,a3,t0
40019074:	00a68067          	jr	10(a3)
40019078:	00b70723          	sb	a1,14(a4)
4001907c:	00b706a3          	sb	a1,13(a4)
40019080:	00b70623          	sb	a1,12(a4)
40019084:	00b705a3          	sb	a1,11(a4)
40019088:	00b70523          	sb	a1,10(a4)
4001908c:	00b704a3          	sb	a1,9(a4)
40019090:	00b70423          	sb	a1,8(a4)
40019094:	00b703a3          	sb	a1,7(a4)
40019098:	00b70323          	sb	a1,6(a4)
4001909c:	00b702a3          	sb	a1,5(a4)
400190a0:	00b70223          	sb	a1,4(a4)
400190a4:	00b701a3          	sb	a1,3(a4)
400190a8:	00b70123          	sb	a1,2(a4)
400190ac:	00b700a3          	sb	a1,1(a4)
400190b0:	00b70023          	sb	a1,0(a4)
400190b4:	8082                	ret
400190b6:	0ff5f593          	zext.b	a1,a1
400190ba:	00859693          	sll	a3,a1,0x8
400190be:	8dd5                	or	a1,a1,a3
400190c0:	01059693          	sll	a3,a1,0x10
400190c4:	8dd5                	or	a1,a1,a3
400190c6:	b761                	j	4001904e <memset+0x10>
400190c8:	00279693          	sll	a3,a5,0x2
400190cc:	00000297          	auipc	t0,0x0
400190d0:	9696                	add	a3,a3,t0
400190d2:	8286                	mv	t0,ra
400190d4:	fa8680e7          	jalr	-88(a3)
400190d8:	8096                	mv	ra,t0
400190da:	17c1                	add	a5,a5,-16
400190dc:	8f1d                	sub	a4,a4,a5
400190de:	963e                	add	a2,a2,a5
400190e0:	f8c374e3          	bgeu	t1,a2,40019068 <memset+0x2a>
400190e4:	b7a5                	j	4001904c <memset+0xe>

400190e6 <memcpy>:
400190e6:	00a5c7b3          	xor	a5,a1,a0
400190ea:	8b8d                	and	a5,a5,3
400190ec:	00c508b3          	add	a7,a0,a2
400190f0:	e7b1                	bnez	a5,4001913c <memcpy+0x56>
400190f2:	478d                	li	a5,3
400190f4:	04c7f463          	bgeu	a5,a2,4001913c <memcpy+0x56>
400190f8:	00357793          	and	a5,a0,3
400190fc:	872a                	mv	a4,a0
400190fe:	e7dd                	bnez	a5,400191ac <memcpy+0xc6>
40019100:	ffc8f613          	and	a2,a7,-4
40019104:	40e606b3          	sub	a3,a2,a4
40019108:	02000793          	li	a5,32
4001910c:	04d7c463          	blt	a5,a3,40019154 <memcpy+0x6e>
40019110:	86ae                	mv	a3,a1
40019112:	87ba                	mv	a5,a4
40019114:	02c77163          	bgeu	a4,a2,40019136 <memcpy+0x50>
40019118:	0006a803          	lw	a6,0(a3)
4001911c:	0791                	add	a5,a5,4
4001911e:	ff07ae23          	sw	a6,-4(a5)
40019122:	0691                	add	a3,a3,4
40019124:	fec7eae3          	bltu	a5,a2,40019118 <memcpy+0x32>
40019128:	fff60793          	add	a5,a2,-1
4001912c:	8f99                	sub	a5,a5,a4
4001912e:	9bf1                	and	a5,a5,-4
40019130:	0791                	add	a5,a5,4
40019132:	973e                	add	a4,a4,a5
40019134:	95be                	add	a1,a1,a5
40019136:	01176663          	bltu	a4,a7,40019142 <memcpy+0x5c>
4001913a:	8082                	ret
4001913c:	872a                	mv	a4,a0
4001913e:	ff157ee3          	bgeu	a0,a7,4001913a <memcpy+0x54>
40019142:	0005c783          	lbu	a5,0(a1)
40019146:	0705                	add	a4,a4,1
40019148:	fef70fa3          	sb	a5,-1(a4)
4001914c:	0585                	add	a1,a1,1
4001914e:	fee89ae3          	bne	a7,a4,40019142 <memcpy+0x5c>
40019152:	8082                	ret
40019154:	02470713          	add	a4,a4,36
40019158:	5194                	lw	a3,32(a1)
4001915a:	0005a383          	lw	t2,0(a1)
4001915e:	0045a283          	lw	t0,4(a1)
40019162:	0085af83          	lw	t6,8(a1)
40019166:	00c5af03          	lw	t5,12(a1)
4001916a:	0105ae83          	lw	t4,16(a1)
4001916e:	0145ae03          	lw	t3,20(a1)
40019172:	0185a303          	lw	t1,24(a1)
40019176:	01c5a803          	lw	a6,28(a1)
4001917a:	fed72e23          	sw	a3,-4(a4)
4001917e:	fc772e23          	sw	t2,-36(a4)
40019182:	fe572023          	sw	t0,-32(a4)
40019186:	fff72223          	sw	t6,-28(a4)
4001918a:	ffe72423          	sw	t5,-24(a4)
4001918e:	ffd72623          	sw	t4,-20(a4)
40019192:	ffc72823          	sw	t3,-16(a4)
40019196:	fe672a23          	sw	t1,-12(a4)
4001919a:	ff072c23          	sw	a6,-8(a4)
4001919e:	40e606b3          	sub	a3,a2,a4
400191a2:	02458593          	add	a1,a1,36
400191a6:	fad7c7e3          	blt	a5,a3,40019154 <memcpy+0x6e>
400191aa:	b79d                	j	40019110 <memcpy+0x2a>
400191ac:	0005c783          	lbu	a5,0(a1)
400191b0:	0705                	add	a4,a4,1
400191b2:	fef70fa3          	sb	a5,-1(a4)
400191b6:	00377793          	and	a5,a4,3
400191ba:	0585                	add	a1,a1,1
400191bc:	d3b1                	beqz	a5,40019100 <memcpy+0x1a>
400191be:	0005c783          	lbu	a5,0(a1)
400191c2:	0705                	add	a4,a4,1
400191c4:	fef70fa3          	sb	a5,-1(a4)
400191c8:	00377793          	and	a5,a4,3
400191cc:	0585                	add	a1,a1,1
400191ce:	fff9                	bnez	a5,400191ac <memcpy+0xc6>
400191d0:	bf05                	j	40019100 <memcpy+0x1a>

400191d2 <strlen>:
400191d2:	00357793          	and	a5,a0,3
400191d6:	872a                	mv	a4,a0
400191d8:	ef9d                	bnez	a5,40019216 <strlen+0x44>
400191da:	7f7f86b7          	lui	a3,0x7f7f8
400191de:	f7f68693          	add	a3,a3,-129 # 7f7f7f7f <_tbs_der_store_end+0x2f7d8f5f>
400191e2:	55fd                	li	a1,-1
400191e4:	4310                	lw	a2,0(a4)
400191e6:	00d677b3          	and	a5,a2,a3
400191ea:	97b6                	add	a5,a5,a3
400191ec:	8fd1                	or	a5,a5,a2
400191ee:	8fd5                	or	a5,a5,a3
400191f0:	0711                	add	a4,a4,4
400191f2:	feb789e3          	beq	a5,a1,400191e4 <strlen+0x12>
400191f6:	ffc74683          	lbu	a3,-4(a4)
400191fa:	40a707b3          	sub	a5,a4,a0
400191fe:	ca8d                	beqz	a3,40019230 <strlen+0x5e>
40019200:	ffd74683          	lbu	a3,-3(a4)
40019204:	c29d                	beqz	a3,4001922a <strlen+0x58>
40019206:	ffe74503          	lbu	a0,-2(a4)
4001920a:	00a03533          	snez	a0,a0
4001920e:	953e                	add	a0,a0,a5
40019210:	1579                	add	a0,a0,-2
40019212:	8082                	ret
40019214:	d2f9                	beqz	a3,400191da <strlen+0x8>
40019216:	00074783          	lbu	a5,0(a4)
4001921a:	0705                	add	a4,a4,1
4001921c:	00377693          	and	a3,a4,3
40019220:	fbf5                	bnez	a5,40019214 <strlen+0x42>
40019222:	8f09                	sub	a4,a4,a0
40019224:	fff70513          	add	a0,a4,-1
40019228:	8082                	ret
4001922a:	ffd78513          	add	a0,a5,-3
4001922e:	8082                	ret
40019230:	ffc78513          	add	a0,a5,-4
40019234:	8082                	ret

Disassembly of section .data:

50010000 <trap_msg-0xe8>:
50010000:	6d1d644b          	.insn	4, 0x6d1d644b
50010004:	42e5                	li	t0,25
50010006:	3bd06ad7          	.insn	4, 0x3bd06ad7
5001000a:	271f d052 a4c2      	.insn	6, 0xa4c2d052271f
50010010:	ca61                	beqz	a2,500100e0 <_data_vma_start+0xe0>
50010012:	493ee717          	auipc	a4,0x493ee
50010016:	02b8                	add	a4,sp,328
50010018:	804a0d47          	.insn	4, 0x804a0d47
5001001c:	1150                	add	a2,sp,164
5001001e:	f4dd                	bnez	s1,5000ffcc <_bss_lma_end+0xfff5b24>
50010020:	9a31                	and	a2,a2,-20
50010022:	2b7e                	.insn	2, 0x2b7e
50010024:	b0396fdb          	.insn	4, 0xb0396fdb
50010028:	c969                	beqz	a0,500100fa <trap_msg+0x12>
5001002a:	521a                	lw	tp,164(sp)
5001002c:	d6fc6cc7          	.insn	4, 0xd6fc6cc7
50010030:	c3918a53          	.insn	4, 0xc3918a53
50010034:	b6c7208f          	.insn	4, 0xb6c7208f
50010038:	fa92                	.insn	2, 0xfa92
5001003a:	cf02                	sw	zero,156(sp)
5001003c:	2afd                	jal	5001023a <trap_msg+0x152>
5001003e:	ba21                	j	5000f956 <_bss_lma_end+0xfff54ae>
50010040:	e1e2                	.insn	2, 0xe1e2
50010042:	2527c803          	lbu	a6,594(a5)
50010046:	0ed6                	sll	t4,t4,0x15
50010048:	c191                	beqz	a1,5001004c <_data_vma_start+0x4c>
5001004a:	8412                	mv	s0,tp
5001004c:	6662                	.insn	2, 0x6662
5001004e:	de019737          	lui	a4,0xde019
50010052:	c33893ef          	jal	t2,4ff99c84 <_bss_lma_end+0xff7f7dc>
50010056:	2064                	.insn	2, 0x2064
50010058:	99a0                	.insn	2, 0x99a0
5001005a:	fc31                	bnez	s0,5000ffb6 <_bss_lma_end+0xfff5b0e>
5001005c:	6046                	.insn	2, 0x6046
5001005e:	84dd                	sra	s1,s1,0x17
50010060:	f24c                	.insn	2, 0xf24c
50010062:	3b35                	jal	5000fd9e <_bss_lma_end+0xfff58f6>
50010064:	1db1                	add	s11,s11,-20
50010066:	9520                	.insn	2, 0x9520
50010068:	ca846b73          	csrrs	s6,0xca8,8
5001006c:	df01                	beqz	a4,5000ff84 <_bss_lma_end+0xfff5adc>
5001006e:	1b81                	add	s7,s7,-32
50010070:	167d                	add	a2,a2,-1
50010072:	f1dd                	bnez	a1,50010018 <_data_vma_start+0x18>
50010074:	5a24bc73          	csrrc	s8,0x5a2,s1
50010078:	a4ece127          	.insn	4, 0xa4ece127
5001007c:	14bc5a37          	lui	s4,0x14bc5
50010080:	8215                	srl	a2,a2,0x5
50010082:	9946                	add	s2,s2,a7
50010084:	32ce                	.insn	2, 0x32ce
50010086:	0fd7a4af          	.insn	4, 0x0fd7a4af
5001008a:	8f51                	or	a4,a4,a2
5001008c:	389da5e7          	.insn	4, 0x389da5e7
50010090:	d6e2                	sw	s8,108(sp)
50010092:	a5fe                	.insn	2, 0xa5fe
50010094:	8d5c                	.insn	2, 0x8d5c
50010096:	0bc8                	add	a0,sp,468
50010098:	a3f6                	.insn	2, 0xa3f6
5001009a:	6795                	lui	a5,0x5
5001009c:	81a4                	.insn	2, 0x81a4
5001009e:	1a36                	sll	s4,s4,0x2d
500100a0:	a514                	.insn	2, 0xa514
500100a2:	9e64                	.insn	2, 0x9e64
500100a4:	d7e2                	sw	s8,236(sp)
500100a6:	dd34                	sw	a3,120(a0)
500100a8:	bc745eab          	.insn	4, 0xbc745eab
500100ac:	90ec                	.insn	2, 0x90ec
500100ae:	4bba                	lw	s7,140(sp)
500100b0:	4a43dbe3          	bge	t2,tp,50010d66 <__func__.2+0xe6>
500100b4:	6316                	.insn	2, 0x6316
500100b6:	c581                	beqz	a1,500100be <_data_vma_start+0xbe>
500100b8:	fee1                	bnez	a3,50010090 <_data_vma_start+0x90>
500100ba:	adb2                	.insn	2, 0xadb2
500100bc:	ec94                	.insn	2, 0xec94
500100be:	7942                	.insn	2, 0x7942
500100c0:	2630                	.insn	2, 0x2630
500100c2:	1030                	add	a2,sp,40
500100c4:	0306                	sll	t1,t1,0x1
500100c6:	1d55                	add	s10,s10,-11
500100c8:	ff01010f          	.insn	4, 0xff01010f
500100cc:	0604                	add	s1,sp,768
500100ce:	06040403          	lb	s0,96(s0)
500100d2:	0000                	unimp
500100d4:	1230                	add	a2,sp,296
500100d6:	0306                	sll	t1,t1,0x1
500100d8:	1d55                	add	s10,s10,-11
500100da:	ff010113          	add	sp,sp,-16
500100de:	0804                	add	s1,sp,16
500100e0:	0630                	add	a2,sp,776
500100e2:	0101                	add	sp,sp,0
500100e4:	000102ff          	.insn	4, 0x000102ff

500100e8 <trap_msg>:
500100e8:	7878                	.insn	2, 0x7878
500100ea:	7878                	.insn	2, 0x7878
500100ec:	7878                	.insn	2, 0x7878
500100ee:	7878                	.insn	2, 0x7878
500100f0:	7878                	.insn	2, 0x7878
500100f2:	7878                	.insn	2, 0x7878
500100f4:	7878                	.insn	2, 0x7878
500100f6:	7878                	.insn	2, 0x7878
500100f8:	7878                	.insn	2, 0x7878
500100fa:	7878                	.insn	2, 0x7878
500100fc:	7878                	.insn	2, 0x7878
500100fe:	7878                	.insn	2, 0x7878
50010100:	7878                	.insn	2, 0x7878
50010102:	7878                	.insn	2, 0x7878
50010104:	7878                	.insn	2, 0x7878
50010106:	7878                	.insn	2, 0x7878
50010108:	7878                	.insn	2, 0x7878
5001010a:	7878                	.insn	2, 0x7878
5001010c:	7878                	.insn	2, 0x7878
5001010e:	7878                	.insn	2, 0x7878
50010110:	200a                	.insn	2, 0x200a
50010112:	2020                	.insn	2, 0x2020
50010114:	5254                	lw	a3,36(a2)
50010116:	5041                	c.li	zero,-16
50010118:	5620                	lw	s0,104(a2)
5001011a:	4345                	li	t1,17
5001011c:	4f54                	lw	a3,28(a4)
5001011e:	2052                	.insn	2, 0x2052
50010120:	5845                	li	a6,-15
50010122:	4345                	li	t1,17
50010124:	5455                	li	s0,-11
50010126:	4e49                	li	t3,18
50010128:	4b202147          	.insn	4, 0x4b202147
5001012c:	4c49                	li	s8,18
5001012e:	204c                	.insn	2, 0x204c
50010130:	214d4953          	.insn	4, 0x214d4953
50010134:	2121                	jal	5001053c <__func__.0+0x2c>
50010136:	2020                	.insn	2, 0x2020
50010138:	0a20                	add	s0,sp,280
5001013a:	7878                	.insn	2, 0x7878
5001013c:	7878                	.insn	2, 0x7878
5001013e:	7878                	.insn	2, 0x7878
50010140:	7878                	.insn	2, 0x7878
50010142:	7878                	.insn	2, 0x7878
50010144:	7878                	.insn	2, 0x7878
50010146:	7878                	.insn	2, 0x7878
50010148:	7878                	.insn	2, 0x7878
5001014a:	7878                	.insn	2, 0x7878
5001014c:	7878                	.insn	2, 0x7878
5001014e:	7878                	.insn	2, 0x7878
50010150:	7878                	.insn	2, 0x7878
50010152:	7878                	.insn	2, 0x7878
50010154:	7878                	.insn	2, 0x7878
50010156:	7878                	.insn	2, 0x7878
50010158:	7878                	.insn	2, 0x7878
5001015a:	7878                	.insn	2, 0x7878
5001015c:	7878                	.insn	2, 0x7878
5001015e:	7878                	.insn	2, 0x7878
50010160:	7878                	.insn	2, 0x7878
50010162:	000a                	c.slli	zero,0x2
50010164:	7566                	.insn	2, 0x7566
50010166:	636e                	.insn	2, 0x636e
50010168:	203a                	.insn	2, 0x203a
5001016a:	7325                	lui	t1,0xfffe9
5001016c:	202c                	.insn	2, 0x202c
5001016e:	696c                	.insn	2, 0x696c
50010170:	656e                	.insn	2, 0x656e
50010172:	203a                	.insn	2, 0x203a
50010174:	6425                	lui	s0,0x9
50010176:	000a                	c.slli	zero,0x2
50010178:	7245                	lui	tp,0xffff1
5001017a:	6f72                	.insn	2, 0x6f72
5001017c:	3a72                	.insn	2, 0x3a72
5001017e:	5220                	lw	s0,96(a2)
50010180:	6765                	lui	a4,0x19
50010182:	7369                	lui	t1,0xffffa
50010184:	6574                	.insn	2, 0x6574
50010186:	2072                	.insn	2, 0x2072
50010188:	6e69                	lui	t3,0x1a
5001018a:	6564                	.insn	2, 0x6564
5001018c:	2078                	.insn	2, 0x2078
5001018e:	2074756f          	jal	a0,50057b94 <_tbs_der_store_end+0x38b74>
50010192:	7220666f          	jal	a2,500168b4 <FMC_data+0x3644>
50010196:	6e61                	lui	t3,0x18
50010198:	28206567          	.insn	4, 0x28206567
5001019c:	2d30                	.insn	2, 0x2d30
5001019e:	2939                	jal	500105bc <__func__.0+0xac>
500101a0:	0000                	unimp
500101a2:	0000                	unimp
500101a4:	63637553          	.insn	4, 0x63637553
500101a8:	7365                	lui	t1,0xffff9
500101aa:	44203a73          	csrrc	s4,0x442,zero
500101ae:	7461                	lui	s0,0xffff8
500101b0:	2061                	jal	50010238 <trap_msg+0x150>
500101b2:	726f7473          	csrrc	s0,mhpmevent6h,30
500101b6:	6465                	lui	s0,0x19
500101b8:	7420                	.insn	2, 0x7420
500101ba:	4144206f          	j	500525ce <_tbs_der_store_end+0x335ae>
500101be:	4154                	lw	a3,4(a0)
500101c0:	565f 5541 544c      	.insn	6, 0x544c5541565f
500101c6:	455f 544e 5952      	.insn	6, 0x5952544e455f
500101cc:	255f 3830 2078      	.insn	6, 0x20783830255f
500101d2:	6e61                	lui	t3,0x18
500101d4:	2064                	.insn	2, 0x2064
500101d6:	4144                	lw	s1,4(a0)
500101d8:	4154                	lw	a3,4(a0)
500101da:	565f 5541 544c      	.insn	6, 0x544c5541565f
500101e0:	455f 544e 5952      	.insn	6, 0x5952544e455f
500101e6:	255f 3830 0a78      	.insn	6, 0x0a783830255f
500101ec:	0000                	unimp
500101ee:	0000                	unimp
500101f0:	63637553          	.insn	4, 0x63637553
500101f4:	7365                	lui	t1,0xffff9
500101f6:	44203a73          	csrrc	s4,0x442,zero
500101fa:	7461                	lui	s0,0xffff8
500101fc:	2061                	jal	50010284 <__func__.1+0x34>
500101fe:	6572                	.insn	2, 0x6572
50010200:	6461                	lui	s0,0x18
50010202:	6620                	.insn	2, 0x6620
50010204:	6f72                	.insn	2, 0x6f72
50010206:	206d                	jal	500102b0 <__func__.1+0x60>
50010208:	4144                	lw	s1,4(a0)
5001020a:	4154                	lw	a3,4(a0)
5001020c:	565f 5541 544c      	.insn	6, 0x544c5541565f
50010212:	455f 544e 5952      	.insn	6, 0x5952544e455f
50010218:	255f 3830 2078      	.insn	6, 0x20783830255f
5001021e:	6e61                	lui	t3,0x18
50010220:	2064                	.insn	2, 0x2064
50010222:	4144                	lw	s1,4(a0)
50010224:	4154                	lw	a3,4(a0)
50010226:	565f 5541 544c      	.insn	6, 0x544c5541565f
5001022c:	455f 544e 5952      	.insn	6, 0x5952544e455f
50010232:	255f 3830 0a78      	.insn	6, 0x0a783830255f
50010238:	0000                	unimp
	...

5001023c <__func__.0>:
5001023c:	6572                	.insn	2, 0x6572
5001023e:	6461                	lui	s0,0x18
50010240:	665f 6f72 5f6d      	.insn	6, 0x5f6d6f72665f
50010246:	6164                	.insn	2, 0x6164
50010248:	6174                	.insn	2, 0x6174
5001024a:	6176                	.insn	2, 0x6176
5001024c:	6c75                	lui	s8,0x1d
5001024e:	0074                	add	a3,sp,12

50010250 <__func__.1>:
50010250:	726f7473          	csrrc	s0,mhpmevent6h,30
50010254:	5f65                	li	t5,-7
50010256:	6f74                	.insn	2, 0x6f74
50010258:	645f 7461 7661      	.insn	6, 0x76617461645f
5001025e:	7561                	lui	a0,0xffff8
50010260:	746c                	.insn	2, 0x746c
50010262:	0000                	unimp
50010264:	450a                	lw	a0,128(sp)
50010266:	4b204343          	.insn	4, 0x4b204343
5001026a:	5945                	li	s2,-15
5001026c:	004e4547          	.insn	4, 0x004e4547
50010270:	74696157          	.insn	4, 0x74696157
50010274:	6620                	.insn	2, 0x6620
50010276:	4b20726f          	jal	tp,50017728 <FMC_data+0x44b8>
5001027a:	2056                	.insn	2, 0x2056
5001027c:	74697277          	.insn	4, 0x74697277
50010280:	0065                	c.nop	25
50010282:	0000                	unimp
50010284:	6f4c                	.insn	2, 0x6f4c
50010286:	6461                	lui	s0,0x18
50010288:	5020                	lw	s0,96(s0)
5001028a:	4952                	lw	s2,20(sp)
5001028c:	4b56                	lw	s6,84(sp)
5001028e:	5945                	li	s2,-15
50010290:	6420                	.insn	2, 0x6420
50010292:	7461                	lui	s0,0xffff8
50010294:	2061                	jal	5001031c <__func__.1+0xcc>
50010296:	7266                	.insn	2, 0x7266
50010298:	45206d6f          	jal	s10,500166ea <FMC_data+0x347a>
5001029c:	00004343          	.insn	4, 0x4343
500102a0:	7441                	lui	s0,0xffff0
500102a2:	6f20                	.insn	2, 0x6f20
500102a4:	6666                	.insn	2, 0x6666
500102a6:	20746573          	csrrs	a0,0x207,8
500102aa:	5d64255b          	.insn	4, 0x5d64255b
500102ae:	202c                	.insn	2, 0x202c
500102b0:	6365                	lui	t1,0x19
500102b2:	72705f63          	blez	t2,500109f0 <k+0x170>
500102b6:	7669                	lui	a2,0xffffa
500102b8:	2079656b          	.insn	4, 0x2079656b
500102bc:	6164                	.insn	2, 0x6164
500102be:	6174                	.insn	2, 0x6174
500102c0:	6d20                	.insn	2, 0x6d20
500102c2:	7369                	lui	t1,0xffffa
500102c4:	616d                	add	sp,sp,240
500102c6:	6374                	.insn	2, 0x6374
500102c8:	2168                	.insn	2, 0x2168
500102ca:	000a                	c.slli	zero,0x2
500102cc:	6341                	lui	t1,0x10
500102ce:	7574                	.insn	2, 0x7574
500102d0:	6c61                	lui	s8,0x18
500102d2:	2020                	.insn	2, 0x2020
500102d4:	6420                	.insn	2, 0x6420
500102d6:	7461                	lui	s0,0xffff8
500102d8:	3a61                	jal	5000fc70 <_bss_lma_end+0xfff57c8>
500102da:	3020                	.insn	2, 0x3020
500102dc:	2578                	.insn	2, 0x2578
500102de:	786c                	.insn	2, 0x786c
500102e0:	000a                	c.slli	zero,0x2
500102e2:	0000                	unimp
500102e4:	7845                	lui	a6,0xffff1
500102e6:	6570                	.insn	2, 0x6570
500102e8:	64657463          	bgeu	a0,t1,50010930 <k+0xb0>
500102ec:	6420                	.insn	2, 0x6420
500102ee:	7461                	lui	s0,0xffff8
500102f0:	3a61                	jal	5000fc88 <_bss_lma_end+0xfff57e0>
500102f2:	3020                	.insn	2, 0x3020
500102f4:	2578                	.insn	2, 0x2578
500102f6:	786c                	.insn	2, 0x786c
500102f8:	000a                	c.slli	zero,0x2
500102fa:	0000                	unimp
500102fc:	6f4c                	.insn	2, 0x6f4c
500102fe:	6461                	lui	s0,0x18
50010300:	5020                	lw	s0,96(s0)
50010302:	4255                	li	tp,21
50010304:	5f59454b          	.insn	4, 0x5f59454b
50010308:	2058                	.insn	2, 0x2058
5001030a:	6164                	.insn	2, 0x6164
5001030c:	6174                	.insn	2, 0x6174
5001030e:	6620                	.insn	2, 0x6620
50010310:	6f72                	.insn	2, 0x6f72
50010312:	206d                	jal	500103bc <__func__.1+0x16c>
50010314:	4345                	li	t1,17
50010316:	74410043          	.insn	4, 0x74410043
5001031a:	6f20                	.insn	2, 0x6f20
5001031c:	6666                	.insn	2, 0x6666
5001031e:	20746573          	csrrs	a0,0x207,8
50010322:	5d64255b          	.insn	4, 0x5d64255b
50010326:	202c                	.insn	2, 0x202c
50010328:	6365                	lui	t1,0x19
5001032a:	75705f63          	blez	s7,50010a88 <k+0x208>
5001032e:	6b62                	.insn	2, 0x6b62
50010330:	7965                	lui	s2,0xffff9
50010332:	785f 6420 7461      	.insn	6, 0x74616420785f
50010338:	2061                	jal	500103c0 <__func__.1+0x170>
5001033a:	696d                	lui	s2,0x1b
5001033c:	74616d73          	csrrs	s10,0x746,2
50010340:	0a216863          	bltu	sp,sp,500103f0 <__func__.1+0x1a0>
50010344:	0000                	unimp
50010346:	0000                	unimp
50010348:	6f4c                	.insn	2, 0x6f4c
5001034a:	6461                	lui	s0,0x18
5001034c:	5020                	lw	s0,96(s0)
5001034e:	4255                	li	tp,21
50010350:	5f59454b          	.insn	4, 0x5f59454b
50010354:	2059                	jal	500103da <__func__.1+0x18a>
50010356:	6164                	.insn	2, 0x6164
50010358:	6174                	.insn	2, 0x6174
5001035a:	6620                	.insn	2, 0x6620
5001035c:	6f72                	.insn	2, 0x6f72
5001035e:	206d                	jal	50010408 <__func__.1+0x1b8>
50010360:	4345                	li	t1,17
50010362:	74410043          	.insn	4, 0x74410043
50010366:	6f20                	.insn	2, 0x6f20
50010368:	6666                	.insn	2, 0x6666
5001036a:	20746573          	csrrs	a0,0x207,8
5001036e:	5d64255b          	.insn	4, 0x5d64255b
50010372:	202c                	.insn	2, 0x202c
50010374:	6365                	lui	t1,0x19
50010376:	75705f63          	blez	s7,50010ad4 <k+0x254>
5001037a:	6b62                	.insn	2, 0x6b62
5001037c:	7965                	lui	s2,0xffff9
5001037e:	795f 6420 7461      	.insn	6, 0x74616420795f
50010384:	2061                	jal	5001040c <__func__.1+0x1bc>
50010386:	696d                	lui	s2,0x1b
50010388:	74616d73          	csrrs	s10,0x746,2
5001038c:	0a216863          	bltu	sp,sp,5001043c <__func__.1+0x1ec>
50010390:	0000                	unimp
50010392:	0000                	unimp
50010394:	6e49                	lui	t3,0x12
50010396:	656a                	.insn	2, 0x656a
50010398:	50207463          	bgeu	zero,sp,500108a0 <k+0x20>
5001039c:	4952                	lw	s2,20(sp)
5001039e:	4b56                	lw	s6,84(sp)
500103a0:	5945                	li	s2,-15
500103a2:	6620                	.insn	2, 0x6620
500103a4:	6f72                	.insn	2, 0x6f72
500103a6:	206d                	jal	50010450 <__func__.1+0x200>
500103a8:	7420766b          	.insn	4, 0x7420766b
500103ac:	4345206f          	j	500627e0 <_tbs_der_store_end+0x437c0>
500103b0:	00000043          	.insn	4, 0x0043
500103b4:	450a                	lw	a0,128(sp)
500103b6:	53204343          	.insn	4, 0x53204343
500103ba:	4749                	li	a4,18
500103bc:	494e                	lw	s2,208(sp)
500103be:	474e                	lw	a4,208(sp)
500103c0:	0000                	unimp
500103c2:	0000                	unimp
500103c4:	6f4c                	.insn	2, 0x6f4c
500103c6:	6461                	lui	s0,0x18
500103c8:	5320                	lw	s0,96(a4)
500103ca:	4749                	li	a4,18
500103cc:	5f4e                	lw	t5,240(sp)
500103ce:	2052                	.insn	2, 0x2052
500103d0:	6164                	.insn	2, 0x6164
500103d2:	6174                	.insn	2, 0x6174
500103d4:	6620                	.insn	2, 0x6620
500103d6:	6f72                	.insn	2, 0x6f72
500103d8:	206d                	jal	50010482 <__func__.1+0x232>
500103da:	4345                	li	t1,17
500103dc:	00000043          	.insn	4, 0x0043
500103e0:	7441                	lui	s0,0xffff0
500103e2:	6f20                	.insn	2, 0x6f20
500103e4:	6666                	.insn	2, 0x6666
500103e6:	20746573          	csrrs	a0,0x207,8
500103ea:	5d64255b          	.insn	4, 0x5d64255b
500103ee:	202c                	.insn	2, 0x202c
500103f0:	6365                	lui	t1,0x19
500103f2:	69735f63          	bge	t1,s7,50010a90 <k+0x210>
500103f6:	725f6e67          	.insn	4, 0x725f6e67
500103fa:	6420                	.insn	2, 0x6420
500103fc:	7461                	lui	s0,0xffff8
500103fe:	2061                	jal	50010486 <__func__.1+0x236>
50010400:	696d                	lui	s2,0x1b
50010402:	74616d73          	csrrs	s10,0x746,2
50010406:	0a216863          	bltu	sp,sp,500104b6 <__func__.1+0x266>
5001040a:	0000                	unimp
5001040c:	6341                	lui	t1,0x10
5001040e:	7574                	.insn	2, 0x7574
50010410:	6c61                	lui	s8,0x18
50010412:	2020                	.insn	2, 0x2020
50010414:	6420                	.insn	2, 0x6420
50010416:	7461                	lui	s0,0xffff8
50010418:	3a61                	jal	5000fdb0 <_bss_lma_end+0xfff5908>
5001041a:	3020                	.insn	2, 0x3020
5001041c:	2578                	.insn	2, 0x2578
5001041e:	3830                	.insn	2, 0x3830
50010420:	786c                	.insn	2, 0x786c
50010422:	000a                	c.slli	zero,0x2
50010424:	7845                	lui	a6,0xffff1
50010426:	6570                	.insn	2, 0x6570
50010428:	64657463          	bgeu	a0,t1,50010a70 <k+0x1f0>
5001042c:	6420                	.insn	2, 0x6420
5001042e:	7461                	lui	s0,0xffff8
50010430:	3a61                	jal	5000fdc8 <_bss_lma_end+0xfff5920>
50010432:	3020                	.insn	2, 0x3020
50010434:	2578                	.insn	2, 0x2578
50010436:	3830                	.insn	2, 0x3830
50010438:	786c                	.insn	2, 0x786c
5001043a:	000a                	c.slli	zero,0x2
5001043c:	6f4c                	.insn	2, 0x6f4c
5001043e:	6461                	lui	s0,0x18
50010440:	5320                	lw	s0,96(a4)
50010442:	4749                	li	a4,18
50010444:	5f4e                	lw	t5,240(sp)
50010446:	61642053          	.insn	4, 0x61642053
5001044a:	6174                	.insn	2, 0x6174
5001044c:	6620                	.insn	2, 0x6620
5001044e:	6f72                	.insn	2, 0x6f72
50010450:	206d                	jal	500104fa <__func__.1+0x2aa>
50010452:	4345                	li	t1,17
50010454:	00000043          	.insn	4, 0x0043
50010458:	7441                	lui	s0,0xffff0
5001045a:	6f20                	.insn	2, 0x6f20
5001045c:	6666                	.insn	2, 0x6666
5001045e:	20746573          	csrrs	a0,0x207,8
50010462:	5d64255b          	.insn	4, 0x5d64255b
50010466:	202c                	.insn	2, 0x202c
50010468:	6365                	lui	t1,0x19
5001046a:	69735f63          	bge	t1,s7,50010b08 <k+0x288>
5001046e:	735f6e67          	.insn	4, 0x735f6e67
50010472:	6420                	.insn	2, 0x6420
50010474:	7461                	lui	s0,0xffff8
50010476:	2061                	jal	500104fe <__func__.1+0x2ae>
50010478:	696d                	lui	s2,0x1b
5001047a:	74616d73          	csrrs	s10,0x746,2
5001047e:	0a216863          	bltu	sp,sp,5001052e <__func__.0+0x1e>
50010482:	0000                	unimp
50010484:	450a                	lw	a0,128(sp)
50010486:	56204343          	.insn	4, 0x56204343
5001048a:	5245                	li	tp,-15
5001048c:	4649                	li	a2,18
5001048e:	4959                	li	s2,22
50010490:	474e                	lw	a4,208(sp)
50010492:	0000                	unimp
50010494:	6f4c                	.insn	2, 0x6f4c
50010496:	6461                	lui	s0,0x18
50010498:	5620                	lw	s0,104(a2)
5001049a:	5245                	li	tp,-15
5001049c:	4649                	li	a2,18
5001049e:	5f59                	li	t5,-10
500104a0:	2052                	.insn	2, 0x2052
500104a2:	6164                	.insn	2, 0x6164
500104a4:	6174                	.insn	2, 0x6174
500104a6:	6620                	.insn	2, 0x6620
500104a8:	6f72                	.insn	2, 0x6f72
500104aa:	206d                	jal	50010554 <__func__.0+0x44>
500104ac:	4345                	li	t1,17
500104ae:	74410043          	.insn	4, 0x74410043
500104b2:	6f20                	.insn	2, 0x6f20
500104b4:	6666                	.insn	2, 0x6666
500104b6:	20746573          	csrrs	a0,0x207,8
500104ba:	5d64255b          	.insn	4, 0x5d64255b
500104be:	202c                	.insn	2, 0x202c
500104c0:	6365                	lui	t1,0x19
500104c2:	65765f63          	bge	a2,s7,50010b20 <k+0x2a0>
500104c6:	6972                	.insn	2, 0x6972
500104c8:	7966                	.insn	2, 0x7966
500104ca:	725f 6420 7461      	.insn	6, 0x74616420725f
500104d0:	2061                	jal	50010558 <__func__.0+0x48>
500104d2:	696d                	lui	s2,0x1b
500104d4:	74616d73          	csrrs	s10,0x746,2
500104d8:	0a216863          	bltu	sp,sp,50010588 <__func__.0+0x78>
500104dc:	0000                	unimp
500104de:	0000                	unimp
500104e0:	6341                	lui	t1,0x10
500104e2:	7574                	.insn	2, 0x7574
500104e4:	6c61                	lui	s8,0x18
500104e6:	2020                	.insn	2, 0x2020
500104e8:	6420                	.insn	2, 0x6420
500104ea:	7461                	lui	s0,0xffff8
500104ec:	3a61                	jal	5000fe84 <_bss_lma_end+0xfff59dc>
500104ee:	3020                	.insn	2, 0x3020
500104f0:	2578                	.insn	2, 0x2578
500104f2:	7838                	.insn	2, 0x7838
500104f4:	000a                	c.slli	zero,0x2
500104f6:	0000                	unimp
500104f8:	7845                	lui	a6,0xffff1
500104fa:	6570                	.insn	2, 0x6570
500104fc:	64657463          	bgeu	a0,t1,50010b44 <k+0x2c4>
50010500:	6420                	.insn	2, 0x6420
50010502:	7461                	lui	s0,0xffff8
50010504:	3a61                	jal	5000fe9c <_bss_lma_end+0xfff59f4>
50010506:	3020                	.insn	2, 0x3020
50010508:	2578                	.insn	2, 0x2578
5001050a:	7838                	.insn	2, 0x7838
5001050c:	000a                	c.slli	zero,0x2
	...

50010510 <__func__.0>:
50010510:	6365                	lui	t1,0x19
50010512:	656b5f63          	bge	s6,s6,50010b70 <k+0x2f0>
50010516:	6779                	lui	a4,0x1e
50010518:	6e65                	lui	t3,0x19
5001051a:	665f 6f6c 0077      	.insn	6, 0x00776f6c665f
50010520:	6f4c                	.insn	2, 0x6f4c
50010522:	6461                	lui	s0,0x18
50010524:	4b20                	lw	s0,80(a4)
50010526:	7965                	lui	s2,0xffff9
50010528:	6420                	.insn	2, 0x6420
5001052a:	7461                	lui	s0,0xffff8
5001052c:	2061                	jal	500105b4 <__func__.0+0xa4>
5001052e:	6f74                	.insn	2, 0x6f74
50010530:	4820                	lw	s0,80(s0)
50010532:	414d                	li	sp,19
50010534:	00000043          	.insn	4, 0x0043
50010538:	6f4c                	.insn	2, 0x6f4c
5001053a:	6461                	lui	s0,0x18
5001053c:	5420                	lw	s0,104(s0)
5001053e:	4741                	li	a4,16
50010540:	6420                	.insn	2, 0x6420
50010542:	7461                	lui	s0,0xffff8
50010544:	2061                	jal	500105cc <__func__.0+0xbc>
50010546:	7266                	.insn	2, 0x7266
50010548:	48206d6f          	jal	s10,500169ca <FMC_data+0x375a>
5001054c:	414d                	li	sp,19
5001054e:	6f742043          	.insn	4, 0x6f742043
50010552:	4b20                	lw	s0,80(a4)
50010554:	0056                	c.slli	zero,0x15
50010556:	0000                	unimp
50010558:	6f4c                	.insn	2, 0x6f4c
5001055a:	6461                	lui	s0,0x18
5001055c:	5420                	lw	s0,104(s0)
5001055e:	4741                	li	a4,16
50010560:	6420                	.insn	2, 0x6420
50010562:	7461                	lui	s0,0xffff8
50010564:	2061                	jal	500105ec <__func__.0+0xdc>
50010566:	7266                	.insn	2, 0x7266
50010568:	48206d6f          	jal	s10,500169ea <FMC_data+0x377a>
5001056c:	414d                	li	sp,19
5001056e:	74410043          	.insn	4, 0x74410043
50010572:	6f20                	.insn	2, 0x6f20
50010574:	6666                	.insn	2, 0x6666
50010576:	20746573          	csrrs	a0,0x207,8
5001057a:	5d64255b          	.insn	4, 0x5d64255b
5001057e:	202c                	.insn	2, 0x202c
50010580:	6d68                	.insn	2, 0x6d68
50010582:	6361                	lui	t1,0x18
50010584:	745f 6761 6420      	.insn	6, 0x64206761745f
5001058a:	7461                	lui	s0,0xffff8
5001058c:	2061                	jal	50010614 <__func__.0+0x104>
5001058e:	696d                	lui	s2,0x1b
50010590:	74616d73          	csrrs	s10,0x746,2
50010594:	0a216863          	bltu	sp,sp,50010644 <__func__.0+0x134>
50010598:	0000                	unimp
5001059a:	0000                	unimp
5001059c:	5746                	lw	a4,112(sp)
5001059e:	203a                	.insn	2, 0x203a
500105a0:	74696157          	.insn	4, 0x74696157
500105a4:	0000                	unimp
500105a6:	0000                	unimp
500105a8:	5746                	lw	a4,112(sp)
500105aa:	203a                	.insn	2, 0x203a
500105ac:	6552                	.insn	2, 0x6552
500105ae:	6461                	lui	s0,0x18
500105b0:	6e69                	lui	t3,0x1a
500105b2:	30252067          	.insn	4, 0x30252067
500105b6:	6438                	.insn	2, 0x6438
500105b8:	6220                	.insn	2, 0x6220
500105ba:	7479                	lui	s0,0xffffe
500105bc:	7365                	lui	t1,0xffff9
500105be:	6620                	.insn	2, 0x6620
500105c0:	6f72                	.insn	2, 0x6f72
500105c2:	206d                	jal	5001066c <__func__.0+0x15c>
500105c4:	616d                	add	sp,sp,240
500105c6:	6c69                	lui	s8,0x1a
500105c8:	6f62                	.insn	2, 0x6f62
500105ca:	0a78                	add	a4,sp,284
500105cc:	0000                	unimp
500105ce:	0000                	unimp
500105d0:	2020                	.insn	2, 0x2020
500105d2:	6164                	.insn	2, 0x6164
500105d4:	6174                	.insn	2, 0x6174
500105d6:	3a74756f          	jal	a0,5005817c <_tbs_der_store_end+0x3915c>
500105da:	3020                	.insn	2, 0x3020
500105dc:	2578                	.insn	2, 0x2578
500105de:	3830                	.insn	2, 0x3830
500105e0:	0a78                	add	a4,sp,284
500105e2:	0000                	unimp
500105e4:	5746                	lw	a4,112(sp)
500105e6:	203a                	.insn	2, 0x203a
500105e8:	74697257          	.insn	4, 0x74697257
500105ec:	6e69                	lui	t3,0x1a
500105ee:	78302067          	.insn	4, 0x78302067
500105f2:	3025                	jal	5000fe1a <_bss_lma_end+0xfff5972>
500105f4:	7838                	.insn	2, 0x7838
500105f6:	6220                	.insn	2, 0x6220
500105f8:	7479                	lui	s0,0xffffe
500105fa:	7365                	lui	t1,0xffff9
500105fc:	7420                	.insn	2, 0x7420
500105fe:	616d206f          	j	500e2c14 <_tbs_der_store_end+0xc3bf4>
50010602:	6c69                	lui	s8,0x1a
50010604:	6f62                	.insn	2, 0x6f62
50010606:	0a78                	add	a4,sp,284
50010608:	0000                	unimp
5001060a:	0000                	unimp
5001060c:	5746                	lw	a4,112(sp)
5001060e:	203a                	.insn	2, 0x203a
50010610:	20746553          	.insn	4, 0x20746553
50010614:	6164                	.insn	2, 0x6164
50010616:	6174                	.insn	2, 0x6174
50010618:	7220                	.insn	2, 0x7220
5001061a:	6165                	add	sp,sp,112
5001061c:	7964                	.insn	2, 0x7964
5001061e:	7320                	.insn	2, 0x7320
50010620:	6174                	.insn	2, 0x6174
50010622:	7574                	.insn	2, 0x7574
50010624:	00000073          	ecall
50010628:	5245                	li	tp,-15
5001062a:	4f52                	lw	t5,20(sp)
5001062c:	3a52                	.insn	2, 0x3a52
5001062e:	6d20                	.insn	2, 0x6d20
50010630:	6961                	lui	s2,0x18
50010632:	626c                	.insn	2, 0x626c
50010634:	6920786f          	jal	a6,50017cc6 <FMC_data+0x4a56>
50010638:	206e                	.insn	2, 0x206e
5001063a:	6e75                	lui	t3,0x1d
5001063c:	7865                	lui	a6,0xffff9
5001063e:	6570                	.insn	2, 0x6570
50010640:	64657463          	bgeu	a0,t1,50010c88 <__func__.2+0x8>
50010644:	7320                	.insn	2, 0x7320
50010646:	6174                	.insn	2, 0x6174
50010648:	6574                	.insn	2, 0x6574
5001064a:	2820                	.insn	2, 0x2820
5001064c:	3025                	jal	5000fe74 <_bss_lma_end+0xfff59cc>
5001064e:	7838                	.insn	2, 0x7838
50010650:	2029                	jal	5001065a <__func__.0+0x14a>
50010652:	6e656877          	.insn	4, 0x6e656877
50010656:	6520                	.insn	2, 0x6520
50010658:	7078                	.insn	2, 0x7078
5001065a:	6365                	lui	t1,0x19
5001065c:	6974                	.insn	2, 0x6974
5001065e:	676e                	.insn	2, 0x676e
50010660:	4d20                	lw	s0,88(a0)
50010662:	4f42                	lw	t5,16(sp)
50010664:	5f58                	lw	a4,60(a4)
50010666:	5845                	li	a6,-15
50010668:	4345                	li	t1,17
5001066a:	5455                	li	s0,-11
5001066c:	5f45                	li	t5,-15
5001066e:	20434f53          	.insn	4, 0x20434f53
50010672:	3028                	.insn	2, 0x3028
50010674:	2578                	.insn	2, 0x2578
50010676:	3830                	.insn	2, 0x3830
50010678:	2978                	.insn	2, 0x2978
5001067a:	000a                	c.slli	zero,0x2
5001067c:	5746                	lw	a4,112(sp)
5001067e:	203a                	.insn	2, 0x203a
50010680:	614d                	add	sp,sp,176
50010682:	6c69                	lui	s8,0x1a
50010684:	6f62                	.insn	2, 0x6f62
50010686:	2078                	.insn	2, 0x2078
50010688:	6e69                	lui	t3,0x1a
5001068a:	6520                	.insn	2, 0x6520
5001068c:	7078                	.insn	2, 0x7078
5001068e:	6365                	lui	t1,0x19
50010690:	6574                	.insn	2, 0x6574
50010692:	2064                	.insn	2, 0x2064
50010694:	74617473          	csrrc	s0,0x746,2
50010698:	2c65                	jal	50010950 <k+0xd0>
5001069a:	4d20                	lw	s0,88(a0)
5001069c:	4f42                	lw	t5,16(sp)
5001069e:	5f58                	lw	a4,60(a4)
500106a0:	5845                	li	a6,-15
500106a2:	4345                	li	t1,17
500106a4:	5455                	li	s0,-11
500106a6:	5f45                	li	t5,-15
500106a8:	2c434f53          	.insn	4, 0x2c434f53
500106ac:	6520                	.insn	2, 0x6520
500106ae:	646e                	.insn	2, 0x646e
500106b0:	6e69                	lui	t3,0x1a
500106b2:	65742067          	.insn	4, 0x65742067
500106b6:	77207473          	csrrc	s0,0x772,0
500106ba:	7469                	lui	s0,0xffffa
500106bc:	2068                	.insn	2, 0x2068
500106be:	63637573          	csrrc	a0,0x636,6
500106c2:	7365                	lui	t1,0xffff9
500106c4:	00000073          	ecall
500106c8:	20495053          	.insn	4, 0x20495053
500106cc:	7245                	lui	tp,0xffff1
500106ce:	6f72                	.insn	2, 0x6f72
500106d0:	7372                	.insn	2, 0x7372
500106d2:	203a                	.insn	2, 0x203a
500106d4:	7830                	.insn	2, 0x7830
500106d6:	3025                	jal	5000fefe <_bss_lma_end+0xfff5a56>
500106d8:	6c38                	.insn	2, 0x6c38
500106da:	0a58                	add	a4,sp,276
500106dc:	0000                	unimp
500106de:	0000                	unimp
500106e0:	2020                	.insn	2, 0x2020
500106e2:	6d6d6f43          	.insn	4, 0x6d6d6f43
500106e6:	6e61                	lui	t3,0x18
500106e8:	2064                	.insn	2, 0x2064
500106ea:	6e49                	lui	t3,0x12
500106ec:	6176                	.insn	2, 0x6176
500106ee:	696c                	.insn	2, 0x696c
500106f0:	0064                	add	s1,sp,12
500106f2:	0000                	unimp
500106f4:	2020                	.insn	2, 0x2020
500106f6:	44495343          	.insn	4, 0x44495343
500106fa:	4920                	lw	s0,80(a0)
500106fc:	766e                	.insn	2, 0x766e
500106fe:	6c61                	lui	s8,0x18
50010700:	6469                	lui	s0,0x1a
50010702:	0000                	unimp
50010704:	2020                	.insn	2, 0x2020
50010706:	6341                	lui	t1,0x10
50010708:	73736563          	bltu	t1,s7,50010e32 <__func__.2+0x1b2>
5001070c:	4920                	lw	s0,80(a0)
5001070e:	766e                	.insn	2, 0x766e
50010710:	6c61                	lui	s8,0x18
50010712:	6469                	lui	s0,0x1a
50010714:	0000                	unimp
50010716:	0000                	unimp
50010718:	2020                	.insn	2, 0x2020
5001071a:	4946                	lw	s2,80(sp)
5001071c:	4f46                	lw	t5,80(sp)
5001071e:	4f20                	lw	s0,88(a4)
50010720:	6576                	.insn	2, 0x6576
50010722:	6672                	.insn	2, 0x6672
50010724:	6f6c                	.insn	2, 0x6f6c
50010726:	6e450077          	.insn	4, 0x6e450077
5001072a:	6261                	lui	tp,0x18
5001072c:	656c                	.insn	2, 0x656c
5001072e:	5320                	lw	s0,96(a4)
50010730:	4148                	lw	a0,4(a0)
50010732:	3532                	.insn	2, 0x3532
50010734:	0036                	c.slli	zero,0xd
50010736:	0000                	unimp
50010738:	6f4c                	.insn	2, 0x6f4c
5001073a:	6461                	lui	s0,0x18
5001073c:	4420                	lw	s0,72(s0)
5001073e:	4749                	li	a4,18
50010740:	5345                	li	t1,-15
50010742:	2054                	.insn	2, 0x2054
50010744:	6164                	.insn	2, 0x6164
50010746:	6174                	.insn	2, 0x6174
50010748:	6620                	.insn	2, 0x6620
5001074a:	6f72                	.insn	2, 0x6f72
5001074c:	206d                	jal	500107f6 <__func__.0+0x2e6>
5001074e:	32414853          	.insn	4, 0x32414853
50010752:	3635                	jal	5001027e <__func__.1+0x2e>
50010754:	0000                	unimp
50010756:	0000                	unimp
50010758:	726f7453          	.insn	4, 0x726f7453
5001075c:	6e69                	lui	t3,0x1a
5001075e:	48532067          	.insn	4, 0x48532067
50010762:	3241                	jal	500100e2 <_data_vma_start+0xe2>
50010764:	3635                	jal	50010290 <__func__.1+0x40>
50010766:	6420                	.insn	2, 0x6420
50010768:	6769                	lui	a4,0x1a
5001076a:	7365                	lui	t1,0xffff9
5001076c:	2074                	.insn	2, 0x2074
5001076e:	6f74                	.insn	2, 0x6f74
50010770:	5020                	lw	s0,96(s0)
50010772:	65205243          	.insn	4, 0x65205243
50010776:	746e                	.insn	2, 0x746e
50010778:	7972                	.insn	2, 0x7972
5001077a:	2520                	.insn	2, 0x2520
5001077c:	0a64                	add	s1,sp,284
5001077e:	0000                	unimp
50010780:	7441                	lui	s0,0xffff0
50010782:	6f20                	.insn	2, 0x6f20
50010784:	6666                	.insn	2, 0x6666
50010786:	20746573          	csrrs	a0,0x207,8
5001078a:	5d64255b          	.insn	4, 0x5d64255b
5001078e:	202c                	.insn	2, 0x202c
50010790:	5f616873          	csrrs	a6,sattri3_base,2
50010794:	6964                	.insn	2, 0x6964
50010796:	74736567          	.insn	4, 0x74736567
5001079a:	6420                	.insn	2, 0x6420
5001079c:	7461                	lui	s0,0xffff8
5001079e:	2061                	jal	50010826 <__func__.0+0x316>
500107a0:	696d                	lui	s2,0x1b
500107a2:	74616d73          	csrrs	s10,0x746,2
500107a6:	0a216863          	bltu	sp,sp,50010856 <__func__.0+0x346>
500107aa:	0000                	unimp
500107ac:	202d                	jal	500107d6 <__func__.0+0x2c6>
500107ae:	3128                	.insn	2, 0x3128
500107b0:	2029342f          	.insn	4, 0x2029342f
500107b4:	207c                	.insn	2, 0x207c
500107b6:	6f74                	.insn	2, 0x6f74
500107b8:	6174                	.insn	2, 0x6174
500107ba:	5f6c                	lw	a1,124(a4)
500107bc:	656c                	.insn	2, 0x656c
500107be:	3a6e                	.insn	2, 0x3a6e
500107c0:	2520                	.insn	2, 0x2520
500107c2:	2c64                	.insn	2, 0x2c64
500107c4:	6d20                	.insn	2, 0x6d20
500107c6:	7365                	lui	t1,0xffff9
500107c8:	65676173          	csrrs	sp,hviprio1h,14
500107cc:	6c5f 6e65 203a      	.insn	6, 0x203a6e656c5f
500107d2:	6425                	lui	s0,0x9
500107d4:	202c                	.insn	2, 0x202c
500107d6:	6170                	.insn	2, 0x6170
500107d8:	6464                	.insn	2, 0x6464
500107da:	6e69                	lui	t3,0x1a
500107dc:	656c5f67          	.insn	4, 0x656c5f67
500107e0:	3a6e                	.insn	2, 0x3a6e
500107e2:	2520                	.insn	2, 0x2520
500107e4:	2c64                	.insn	2, 0x2c64
500107e6:	6620                	.insn	2, 0x6620
500107e8:	6e69                	lui	t3,0x1a
500107ea:	6c61                	lui	s8,0x18
500107ec:	625f 6f6c 6b63      	.insn	6, 0x6b636f6c625f
500107f2:	6c5f 6e65 203a      	.insn	6, 0x203a6e656c5f
500107f8:	6425                	lui	s0,0x9
500107fa:	0a20                	add	s0,sp,280
500107fc:	0000                	unimp
500107fe:	0000                	unimp
50010800:	202d                	jal	5001082a <__func__.0+0x31a>
50010802:	3228                	.insn	2, 0x3228
50010804:	2029342f          	.insn	4, 0x2029342f
50010808:	207c                	.insn	2, 0x207c
5001080a:	33616873          	csrrs	a6,mhpmevent22,2
5001080e:	3438                	.insn	2, 0x3438
50010810:	635f 726f 2865      	.insn	6, 0x2865726f635f
50010816:	2029                	jal	50010820 <__func__.0+0x310>
50010818:	6e69                	lui	t3,0x1a
5001081a:	7469                	lui	s0,0xffffa
5001081c:	6169                	add	sp,sp,208
5001081e:	206c                	.insn	2, 0x206c
50010820:	6964                	.insn	2, 0x6964
50010822:	74736567          	.insn	4, 0x74736567
50010826:	6420                	.insn	2, 0x6420
50010828:	2e656e6f          	jal	t3,50066b0e <_tbs_der_store_end+0x47aee>
5001082c:	0000                	unimp
5001082e:	0000                	unimp
50010830:	202d                	jal	5001085a <__func__.0+0x34a>
50010832:	3328                	.insn	2, 0x3328
50010834:	2029342f          	.insn	4, 0x2029342f
50010838:	207c                	.insn	2, 0x207c
5001083a:	33616873          	csrrs	a6,mhpmevent22,2
5001083e:	3438                	.insn	2, 0x3438
50010840:	7020                	.insn	2, 0x7020
50010842:	6461                	lui	s0,0x18
50010844:	6964                	.insn	2, 0x6964
50010846:	676e                	.insn	2, 0x676e
50010848:	6420                	.insn	2, 0x6420
5001084a:	2e656e6f          	jal	t3,50066b30 <_tbs_der_store_end+0x47b10>
5001084e:	0000                	unimp
50010850:	202d                	jal	5001087a <__func__.0+0x36a>
50010852:	3428                	.insn	2, 0x3428
50010854:	2029342f          	.insn	4, 0x2029342f
50010858:	207c                	.insn	2, 0x207c
5001085a:	33616873          	csrrs	a6,mhpmevent22,2
5001085e:	3438                	.insn	2, 0x3438
50010860:	635f 726f 2865      	.insn	6, 0x2865726f635f
50010866:	2029                	jal	50010870 <__func__.0+0x360>
50010868:	6966                	.insn	2, 0x6966
5001086a:	616e                	.insn	2, 0x616e
5001086c:	206c                	.insn	2, 0x206c
5001086e:	6964                	.insn	2, 0x6964
50010870:	74736567          	.insn	4, 0x74736567
50010874:	6420                	.insn	2, 0x6420
50010876:	2e656e6f          	jal	t3,50066b5c <_tbs_der_store_end+0x47b3c>
5001087a:	0000                	unimp
5001087c:	0000                	unimp
	...

50010880 <k>:
50010880:	ae22                	.insn	2, 0xae22
50010882:	d728                	sw	a0,104(a4)
50010884:	2f98                	.insn	2, 0x2f98
50010886:	428a                	lw	t0,128(sp)
50010888:	65cd                	lui	a1,0x13
5001088a:	449123ef          	jal	t2,500234d2 <_tbs_der_store_end+0x44b2>
5001088e:	3b2f7137          	lui	sp,0x3b2f7
50010892:	ec4d                	bnez	s0,5001094c <k+0xcc>
50010894:	b5c0fbcf          	.insn	4, 0xb5c0fbcf
50010898:	dbbc                	sw	a5,112(a5)
5001089a:	8189                	srl	a1,a1,0x2
5001089c:	dba5                	beqz	a5,5001080c <__func__.0+0x2fc>
5001089e:	e9b5                	bnez	a1,50010912 <k+0x92>
500108a0:	b538                	.insn	2, 0xb538
500108a2:	f348                	.insn	2, 0xf348
500108a4:	3956c25b          	.insn	4, 0x3956c25b
500108a8:	d019                	beqz	s0,500107ae <__func__.0+0x29e>
500108aa:	b605                	j	500103ca <__func__.1+0x17a>
500108ac:	11f1                	add	gp,gp,-4
500108ae:	59f1                	li	s3,-4
500108b0:	af194f9b          	.insn	4, 0xaf194f9b
500108b4:	82a4                	.insn	2, 0x82a4
500108b6:	8118923f 5ed5da6d 	.insn	8, 0x5ed5da6d8118923f
500108be:	ab1c                	.insn	2, 0xab1c
500108c0:	0242                	sll	tp,tp,0x10
500108c2:	aa98a303          	lw	t1,-1367(a7)
500108c6:	6fbed807          	.insn	4, 0x6fbed807
500108ca:	4570                	lw	a2,76(a0)
500108cc:	5b01                	li	s6,-32
500108ce:	b28c1283          	lh	t0,-1240(s8) # 17b28 <mfdc+0x1732f>
500108d2:	4ee4                	lw	s1,92(a3)
500108d4:	85be                	mv	a1,a5
500108d6:	2431                	jal	50010ae2 <k+0x262>
500108d8:	b4e2                	.insn	2, 0xb4e2
500108da:	7dc3d5ff          	.insn	4, 0x7dc3d5ff
500108de:	550c                	lw	a1,40(a0)
500108e0:	f27b896f          	jal	s2,4ffc9806 <_bss_lma_end+0xffaf35e>
500108e4:	5d74                	lw	a3,124(a0)
500108e6:	72be                	.insn	2, 0x72be
500108e8:	96b1                	sra	a3,a3,0x2c
500108ea:	3b16                	.insn	2, 0x3b16
500108ec:	b1fe                	.insn	2, 0xb1fe
500108ee:	80de                	mv	ra,s7
500108f0:	1235                	add	tp,tp,-19 # 17fed <mfdc+0x177f4>
500108f2:	06a725c7          	.insn	4, 0x06a725c7
500108f6:	9bdc                	.insn	2, 0x9bdc
500108f8:	2694                	.insn	2, 0x2694
500108fa:	cf69                	beqz	a4,500109d4 <k+0x154>
500108fc:	f174                	.insn	2, 0xf174
500108fe:	4ad2c19b          	.insn	4, 0x4ad2c19b
50010902:	9ef1                	.insn	2, 0x9ef1
50010904:	69c1                	lui	s3,0x10
50010906:	25e3e49b          	.insn	4, 0x25e3e49b
5001090a:	4786384f          	.insn	4, 0x4786384f
5001090e:	efbe                	.insn	2, 0xefbe
50010910:	d5b5                	beqz	a1,5001087c <__func__.0+0x36c>
50010912:	8b8c                	.insn	2, 0x8b8c
50010914:	9dc6                	add	s11,s11,a7
50010916:	0fc1                	add	t6,t6,16 # 3000010 <mfdc+0x2fff817>
50010918:	9c65                	.insn	2, 0x9c65
5001091a:	77ac                	.insn	2, 0x77ac
5001091c:	a1cc                	.insn	2, 0xa1cc
5001091e:	240c                	.insn	2, 0x240c
50010920:	0275                	add	tp,tp,29 # 1d <mrac-0x7a3>
50010922:	2c6f592b          	.insn	4, 0x2c6f592b
50010926:	2de9                	jal	50011000 <__func__.2+0x380>
50010928:	6ea6e483          	.insn	4, 0x6ea6e483
5001092c:	84aa                	mv	s1,a0
5001092e:	4a74                	lw	a3,84(a2)
50010930:	fbd4                	.insn	2, 0xfbd4
50010932:	bd41                	j	500107c2 <__func__.0+0x2b2>
50010934:	a9dc                	.insn	2, 0xa9dc
50010936:	5cb0                	lw	a2,120(s1)
50010938:	53b5                	li	t2,-19
5001093a:	8311                	srl	a4,a4,0x4
5001093c:	88da                	mv	a7,s6
5001093e:	76f9                	lui	a3,0xffffe
50010940:	ee66dfab          	.insn	4, 0xee66dfab
50010944:	5152                	lw	sp,52(sp)
50010946:	983e                	add	a6,a6,a5
50010948:	3210                	.insn	2, 0x3210
5001094a:	2db4                	.insn	2, 0x2db4
5001094c:	c66d                	beqz	a2,50010a36 <k+0x1b6>
5001094e:	a831                	j	5001096a <k+0xea>
50010950:	98fb213f b00327c8 	.insn	8, 0xb00327c898fb213f
50010958:	0ee4                	add	s1,sp,860
5001095a:	7fc7beef          	jal	t4,5008c156 <_tbs_der_store_end+0x6d136>
5001095e:	bf59                	j	500108f4 <k+0x74>
50010960:	8fc2                	mv	t6,a6
50010962:	3da8                	.insn	2, 0x3da8
50010964:	c6e00bf3          	.insn	4, 0xc6e00bf3
50010968:	a725                	j	50011090 <__func__.2+0x410>
5001096a:	930a                	add	t1,t1,sp
5001096c:	d5a79147          	.insn	4, 0xd5a79147
50010970:	e003826f          	jal	tp,4ff48f70 <_bss_lma_end+0xff2eac8>
50010974:	6351                	lui	t1,0x14
50010976:	06ca                	sll	a3,a3,0x12
50010978:	6e70                	.insn	2, 0x6e70
5001097a:	0a0e                	sll	s4,s4,0x3
5001097c:	14292967          	.insn	4, 0x14292967
50010980:	2ffc                	.insn	2, 0x2ffc
50010982:	46d2                	lw	a3,20(sp)
50010984:	0a85                	add	s5,s5,1
50010986:	c92627b7          	lui	a5,0xc9262
5001098a:	5c26                	lw	s8,104(sp)
5001098c:	2138                	.insn	2, 0x2138
5001098e:	2aed2e1b          	.insn	4, 0x2aed2e1b
50010992:	5ac4                	lw	s1,52(a3)
50010994:	6dfc                	.insn	2, 0x6dfc
50010996:	4d2c                	lw	a1,88(a0)
50010998:	b3df 9d95 0d13      	.insn	6, 0x0d139d95b3df
5001099e:	5338                	lw	a4,96(a4)
500109a0:	63de                	.insn	2, 0x63de
500109a2:	73548baf          	.insn	4, 0x73548baf
500109a6:	650a                	.insn	2, 0x650a
500109a8:	b2a8                	.insn	2, 0xb2a8
500109aa:	0abb3c77          	.insn	4, 0x0abb3c77
500109ae:	766a                	.insn	2, 0x766a
500109b0:	aee6                	.insn	2, 0xaee6
500109b2:	47ed                	li	a5,27
500109b4:	c92e                	sw	a1,144(sp)
500109b6:	81c2                	mv	gp,a6
500109b8:	1482353b          	.insn	4, 0x1482353b
500109bc:	2c85                	jal	50010c2c <k+0x3ac>
500109be:	9272                	add	tp,tp,t3
500109c0:	0364                	add	s1,sp,396
500109c2:	4cf1                	li	s9,28
500109c4:	e8a1                	bnez	s1,50010a14 <k+0x194>
500109c6:	3001a2bf 664bbc42 	.insn	8, 0x664bbc423001a2bf
500109ce:	a81a                	.insn	2, 0xa81a
500109d0:	9791                	sra	a5,a5,0x24
500109d2:	d0f8                	sw	a4,100(s1)
500109d4:	8b70                	.insn	2, 0x8b70
500109d6:	be30c24b          	.insn	4, 0xbe30c24b
500109da:	0654                	add	a3,sp,772
500109dc:	c76c51a3          	.insn	4, 0xc76c51a3
500109e0:	5218                	lw	a4,32(a2)
500109e2:	e819d6ef          	jal	a3,4ffae862 <_bss_lma_end+0xff943ba>
500109e6:	d192                	sw	tp,224(sp)
500109e8:	a910                	.insn	2, 0xa910
500109ea:	5565                	li	a0,-7
500109ec:	0624                	add	s1,sp,776
500109ee:	d699                	beqz	a3,500108fc <k+0x7c>
500109f0:	202a                	.insn	2, 0x202a
500109f2:	5771                	li	a4,-4
500109f4:	3585                	jal	50010854 <__func__.0+0x344>
500109f6:	f40e                	.insn	2, 0xf40e
500109f8:	d1b8                	sw	a4,96(a1)
500109fa:	a07032bb          	.insn	4, 0xa07032bb
500109fe:	106a                	c.slli	zero,0x3a
50010a00:	d0c8                	sw	a0,36(s1)
50010a02:	b8d2                	.insn	2, 0xb8d2
50010a04:	c116                	sw	t0,128(sp)
50010a06:	19a4                	add	s1,sp,248
50010a08:	5141ab53          	.insn	4, 0x5141ab53
50010a0c:	6c08                	.insn	2, 0x6c08
50010a0e:	eb991e37          	lui	t3,0xeb991
50010a12:	df8e                	sw	gp,252(sp)
50010a14:	774c                	.insn	2, 0x774c
50010a16:	2748                	.insn	2, 0x2748
50010a18:	48a8                	lw	a0,80(s1)
50010a1a:	bcb5e19b          	.insn	4, 0xbcb5e19b
50010a1e:	34b0                	.insn	2, 0x34b0
50010a20:	c5c95a63          	bge	s2,t3,5000fe74 <_bss_lma_end+0xfff59cc>
50010a24:	391c0cb3          	.insn	4, 0x391c0cb3
50010a28:	e3418acb          	.insn	4, 0xe3418acb
50010a2c:	aa4a                	.insn	2, 0xaa4a
50010a2e:	4ed8                	lw	a4,28(a3)
50010a30:	7763e373          	csrrs	t1,0x776,7
50010a34:	5b9cca4f          	.insn	4, 0x5b9cca4f
50010a38:	d6b2b8a3          	.insn	4, 0xd6b2b8a3
50010a3c:	682e6ff3          	csrrs	t6,0x682,28
50010a40:	b2fc                	.insn	2, 0xb2fc
50010a42:	82ee5def          	jal	s11,4fff5a70 <_bss_lma_end+0xffdb5c8>
50010a46:	2f60748f          	.insn	4, 0x2f60748f
50010a4a:	636f4317          	auipc	t1,0x636f4
50010a4e:	78a5                	lui	a7,0xfffe9
50010a50:	ab72                	.insn	2, 0xab72
50010a52:	a1f0                	.insn	2, 0xa1f0
50010a54:	7814                	.insn	2, 0x7814
50010a56:	84c8                	.insn	2, 0x84c8
50010a58:	39ec                	.insn	2, 0x39ec
50010a5a:	1a64                	add	s1,sp,316
50010a5c:	0208                	add	a0,sp,256
50010a5e:	1e288cc7          	.insn	4, 0x1e288cc7
50010a62:	fffa2363          	.insn	4, 0xfffa2363
50010a66:	90be                	add	ra,ra,a5
50010a68:	bde9                	j	50010942 <k+0xc2>
50010a6a:	de82                	sw	zero,124(sp)
50010a6c:	a4506ceb          	.insn	4, 0xa4506ceb
50010a70:	7915                	lui	s2,0xfffe5
50010a72:	b2c6                	.insn	2, 0xb2c6
50010a74:	bef9a3f7          	.insn	4, 0xbef9a3f7
50010a78:	e372532b          	.insn	4, 0xe372532b
50010a7c:	78f2                	.insn	2, 0x78f2
50010a7e:	c671                	beqz	a2,50010b4a <k+0x2ca>
50010a80:	619c                	.insn	2, 0x619c
50010a82:	ea26                	.insn	2, 0xea26
50010a84:	3ece                	.insn	2, 0x3ece
50010a86:	c207ca27          	.insn	4, 0xc207ca27
50010a8a:	21c0                	.insn	2, 0x21c0
50010a8c:	d186b8c7          	.insn	4, 0xd186b8c7
50010a90:	eb1e                	.insn	2, 0xeb1e
50010a92:	cde0                	sw	s0,92(a1)
50010a94:	7dd6                	.insn	2, 0x7dd6
50010a96:	eada                	.insn	2, 0xeada
50010a98:	d178                	sw	a4,100(a0)
50010a9a:	ee6e                	.insn	2, 0xee6e
50010a9c:	f57d4f7f          	.insn	4, 0xf57d4f7f
50010aa0:	6fba                	.insn	2, 0x6fba
50010aa2:	67aa7217          	auipc	tp,0x67aa7
50010aa6:	06f0                	add	a2,sp,844
50010aa8:	98a6                	add	a7,a7,s1
50010aaa:	a2c8                	.insn	2, 0xa2c8
50010aac:	7dc5                	lui	s11,0xffff1
50010aae:	0dae0a63          	beq	t3,s10,50010b82 <k+0x302>
50010ab2:	bef9                	j	50010690 <__func__.0+0x180>
50010ab4:	9804                	.insn	2, 0x9804
50010ab6:	471b113f 0b35131c 	.insn	8, 0x0b35131c471b113f
50010abe:	1b71                	add	s6,s6,-4
50010ac0:	7d84                	.insn	2, 0x7d84
50010ac2:	2304                	.insn	2, 0x2304
50010ac4:	77f5                	lui	a5,0xffffd
50010ac6:	249328db          	.insn	4, 0x249328db
50010aca:	ab7b40c7          	.insn	4, 0xab7b40c7
50010ace:	32ca                	.insn	2, 0x32ca
50010ad0:	bebc                	.insn	2, 0xbebc
50010ad2:	15c9                	add	a1,a1,-14 # 12ff2 <mfdc+0x127f9>
50010ad4:	be0a                	.insn	2, 0xbe0a
50010ad6:	3c9e                	.insn	2, 0x3c9e
50010ad8:	0d4c                	add	a1,sp,660
50010ada:	9c10                	.insn	2, 0x9c10
50010adc:	67c4                	.insn	2, 0x67c4
50010ade:	431d                	li	t1,7
50010ae0:	42b6                	lw	t0,76(sp)
50010ae2:	cb3e                	sw	a5,148(sp)
50010ae4:	d4be                	sw	a5,104(sp)
50010ae6:	4cc5                	li	s9,17
50010ae8:	7e2a                	.insn	2, 0x7e2a
50010aea:	fc65                	bnez	s0,50010ae2 <k+0x262>
50010aec:	299c                	.insn	2, 0x299c
50010aee:	faec597f          	.insn	4, 0xfaec597f
50010af2:	3ad6                	.insn	2, 0x3ad6
50010af4:	5fcb6fab          	.insn	4, 0x5fcb6fab
50010af8:	4a475817          	auipc	a6,0x4a475
50010afc:	198c                	add	a1,sp,240
50010afe:	6c44                	.insn	2, 0x6c44
50010b00:	35414853          	.insn	4, 0x35414853
50010b04:	3231                	jal	50010410 <__func__.1+0x1c0>
50010b06:	203a                	.insn	2, 0x203a
50010b08:	20746553          	.insn	4, 0x20746553
50010b0c:	6f6d                	lui	t5,0x1b
50010b0e:	6564                	.insn	2, 0x6564
50010b10:	203a                	.insn	2, 0x203a
50010b12:	7830                	.insn	2, 0x7830
50010b14:	7825                	lui	a6,0xfffe9
50010b16:	6120                	.insn	2, 0x6120
50010b18:	646e                	.insn	2, 0x646e
50010b1a:	6920                	.insn	2, 0x6920
50010b1c:	696e                	.insn	2, 0x696e
50010b1e:	0a74                	add	a3,sp,284
50010b20:	0000                	unimp
50010b22:	0000                	unimp
50010b24:	35414853          	.insn	4, 0x35414853
50010b28:	3231                	jal	50010434 <__func__.1+0x1e4>
50010b2a:	203a                	.insn	2, 0x203a
50010b2c:	20746553          	.insn	4, 0x20746553
50010b30:	6f6d                	lui	t5,0x1b
50010b32:	6564                	.insn	2, 0x6564
50010b34:	203a                	.insn	2, 0x203a
50010b36:	7830                	.insn	2, 0x7830
50010b38:	7825                	lui	a6,0xfffe9
50010b3a:	6120                	.insn	2, 0x6120
50010b3c:	646e                	.insn	2, 0x646e
50010b3e:	6e20                	.insn	2, 0x6e20
50010b40:	7865                	lui	a6,0xffff9
50010b42:	0a74                	add	a3,sp,284
50010b44:	0000                	unimp
50010b46:	0000                	unimp
50010b48:	35414853          	.insn	4, 0x35414853
50010b4c:	3231                	jal	50010458 <__func__.1+0x208>
50010b4e:	203a                	.insn	2, 0x203a
50010b50:	20746553          	.insn	4, 0x20746553
50010b54:	6f6d                	lui	t5,0x1b
50010b56:	6564                	.insn	2, 0x6564
50010b58:	203a                	.insn	2, 0x203a
50010b5a:	7830                	.insn	2, 0x7830
50010b5c:	7825                	lui	a6,0xfffe9
50010b5e:	6120                	.insn	2, 0x6120
50010b60:	646e                	.insn	2, 0x646e
50010b62:	6e20                	.insn	2, 0x6e20
50010b64:	7865                	lui	a6,0xffff9
50010b66:	2074                	.insn	2, 0x2074
50010b68:	68746977          	.insn	4, 0x68746977
50010b6c:	6c20                	.insn	2, 0x6c20
50010b6e:	7361                	lui	t1,0xffff8
50010b70:	0a74                	add	a3,sp,284
50010b72:	0000                	unimp
50010b74:	656d                	lui	a0,0x1b
50010b76:	7361                	lui	t1,0xffff8
50010b78:	7275                	lui	tp,0xffffd
50010b7a:	5365                	li	t1,-7
50010b7c:	6d20434f          	.insn	4, 0x6d20434f
50010b80:	6165                	add	sp,sp,112
50010b82:	65727573          	csrrc	a0,hviprio2h,4
50010b86:	7620                	.insn	2, 0x7620
50010b88:	6c61                	lui	s8,0x18
50010b8a:	6575                	lui	a0,0x1d
50010b8c:	003a                	c.slli	zero,0xe
50010b8e:	0000                	unimp
50010b90:	7830                	.insn	2, 0x7830
50010b92:	3025                	jal	500103ba <__func__.1+0x16a>
50010b94:	7838                	.insn	2, 0x7838
50010b96:	0020                	add	s0,sp,8
50010b98:	656d                	lui	a0,0x1b
50010b9a:	7361                	lui	t1,0xffff8
50010b9c:	7275                	lui	tp,0xffffd
50010b9e:	5365                	li	t1,-7
50010ba0:	6520434f          	.insn	4, 0x6520434f
50010ba4:	7078                	.insn	2, 0x7078
50010ba6:	6365                	lui	t1,0x19
50010ba8:	5f74                	lw	a3,124(a4)
50010baa:	6176                	.insn	2, 0x6176
50010bac:	756c                	.insn	2, 0x756c
50010bae:	3a65                	jal	50010566 <__func__.0+0x56>
50010bb0:	0000                	unimp
50010bb2:	0000                	unimp
50010bb4:	706d6f43          	.insn	4, 0x706d6f43
50010bb8:	7261                	lui	tp,0xffff8
50010bba:	6e69                	lui	t3,0x1a
50010bbc:	48532067          	.insn	4, 0x48532067
50010bc0:	3541                	jal	50010a40 <k+0x1c0>
50010bc2:	3231                	jal	500104ce <__func__.1+0x27e>
50010bc4:	6420                	.insn	2, 0x6420
50010bc6:	6769                	lui	a4,0x1a
50010bc8:	7365                	lui	t1,0xffff9
50010bca:	2e74                	.insn	2, 0x2e74
50010bcc:	2e2e                	.insn	2, 0x2e2e
50010bce:	0000                	unimp
50010bd0:	694d                	lui	s2,0x13
50010bd2:	74616d73          	csrrs	s10,0x746,2
50010bd6:	61206863          	bltu	zero,s2,500111e6 <__func__.2+0x566>
50010bda:	2074                	.insn	2, 0x2074
50010bdc:	64726f77          	.insn	4, 0x64726f77
50010be0:	2520                	.insn	2, 0x2520
50010be2:	3a64                	.insn	2, 0x3a64
50010be4:	4d20                	lw	s0,88(a0)
50010be6:	6165                	add	sp,sp,112
50010be8:	65727573          	csrrc	a0,hviprio2h,4
50010bec:	656d                	lui	a0,0x1b
50010bee:	746e                	.insn	2, 0x746e
50010bf0:	7620                	.insn	2, 0x7620
50010bf2:	6c61                	lui	s8,0x18
50010bf4:	6575                	lui	a0,0x1d
50010bf6:	3020                	.insn	2, 0x3020
50010bf8:	2578                	.insn	2, 0x2578
50010bfa:	3830                	.insn	2, 0x3830
50010bfc:	2c78                	.insn	2, 0x2c78
50010bfe:	4520                	lw	s0,72(a0)
50010c00:	7078                	.insn	2, 0x7078
50010c02:	6365                	lui	t1,0x19
50010c04:	6574                	.insn	2, 0x6574
50010c06:	2064                	.insn	2, 0x2064
50010c08:	7830                	.insn	2, 0x7830
50010c0a:	3025                	jal	50010432 <__func__.1+0x1e2>
50010c0c:	7838                	.insn	2, 0x7838
50010c0e:	000a                	c.slli	zero,0x2
50010c10:	654d                	lui	a0,0x13
50010c12:	7361                	lui	t1,0xffff8
50010c14:	7275                	lui	tp,0xffffd
50010c16:	6d65                	lui	s10,0x19
50010c18:	6e65                	lui	t3,0x19
50010c1a:	2074                	.insn	2, 0x2074
50010c1c:	63637573          	csrrc	a0,0x636,6
50010c20:	7365                	lui	t1,0xffff9
50010c22:	00002173          	csrr	sp,ustatus
50010c26:	0000                	unimp
50010c28:	654d                	lui	a0,0x13
50010c2a:	7361                	lui	t1,0xffff8
50010c2c:	7275                	lui	tp,0xffffd
50010c2e:	6d65                	lui	s10,0x19
50010c30:	6e65                	lui	t3,0x19
50010c32:	2074                	.insn	2, 0x2074
50010c34:	6166                	.insn	2, 0x6166
50010c36:	6c69                	lui	s8,0x1a
50010c38:	6465                	lui	s0,0x19
50010c3a:	0021                	c.nop	8
50010c3c:	656d                	lui	a0,0x1b
50010c3e:	7361                	lui	t1,0xffff8
50010c40:	7275                	lui	tp,0xffffd
50010c42:	4665                	li	a2,25
50010c44:	434d                	li	t1,19
50010c46:	6d20                	.insn	2, 0x6d20
50010c48:	6165                	add	sp,sp,112
50010c4a:	65727573          	csrrc	a0,hviprio2h,4
50010c4e:	7620                	.insn	2, 0x7620
50010c50:	6c61                	lui	s8,0x18
50010c52:	6575                	lui	a0,0x1d
50010c54:	003a                	c.slli	zero,0xe
50010c56:	0000                	unimp
50010c58:	656d                	lui	a0,0x1b
50010c5a:	7361                	lui	t1,0xffff8
50010c5c:	7275                	lui	tp,0xffffd
50010c5e:	4665                	li	a2,25
50010c60:	434d                	li	t1,19
50010c62:	6520                	.insn	2, 0x6520
50010c64:	7078                	.insn	2, 0x7078
50010c66:	6365                	lui	t1,0x19
50010c68:	5f74                	lw	a3,124(a4)
50010c6a:	6176                	.insn	2, 0x6176
50010c6c:	756c                	.insn	2, 0x756c
50010c6e:	3a65                	jal	50010626 <__func__.0+0x116>
50010c70:	0000                	unimp
	...

50010c74 <__func__.0>:
50010c74:	656d                	lui	a0,0x1b
50010c76:	7361                	lui	t1,0xffff8
50010c78:	7275                	lui	tp,0xffffd
50010c7a:	5f65                	li	t5,-7
50010c7c:	6d66                	.insn	2, 0x6d66
50010c7e:	          	beq	s10,s6,500112be <SOC_FW_data+0x4e>

50010c80 <__func__.2>:
50010c80:	656d                	lui	a0,0x1b
50010c82:	7361                	lui	t1,0xffff8
50010c84:	7275                	lui	tp,0xffffd
50010c86:	5f65                	li	t5,-7
50010c88:	00636f73          	csrrs	t5,0x6,6
50010c8c:	5f434f53          	.insn	4, 0x5f434f53
50010c90:	4649                	li	a2,18
50010c92:	53203a43          	.insn	4, 0x53203a43
50010c96:	7465                	lui	s0,0xffff9
50010c98:	6620                	.insn	2, 0x6620
50010c9a:	6f6c                	.insn	2, 0x6f6c
50010c9c:	74735f77          	.insn	4, 0x74735f77
50010ca0:	7461                	lui	s0,0xffff8
50010ca2:	7375                	lui	t1,0xffffd
50010ca4:	6620                	.insn	2, 0x6620
50010ca6:	6569                	lui	a0,0x1a
50010ca8:	646c                	.insn	2, 0x646c
50010caa:	203a                	.insn	2, 0x203a
50010cac:	7830                	.insn	2, 0x7830
50010cae:	3025                	jal	500104d6 <__func__.1+0x286>
50010cb0:	7838                	.insn	2, 0x7838
50010cb2:	000a                	c.slli	zero,0x2
50010cb4:	6e49                	lui	t3,0x12
50010cb6:	6176                	.insn	2, 0x6176
50010cb8:	696c                	.insn	2, 0x696c
50010cba:	2064                	.insn	2, 0x2064
50010cbc:	6170                	.insn	2, 0x6170
50010cbe:	6172                	.insn	2, 0x6172
50010cc0:	656d                	lui	a0,0x1b
50010cc2:	6574                	.insn	2, 0x6574
50010cc4:	7372                	.insn	2, 0x7372
50010cc6:	0000                	unimp
50010cc8:	0a30                	add	a2,sp,280
50010cca:	0806                	sll	a6,a6,0x1
50010ccc:	862a                	mv	a2,a0
50010cce:	ce48                	sw	a0,28(a2)
50010cd0:	043d                	add	s0,s0,15 # ffff800f <_tbs_der_store_end+0xaffd8fef>
50010cd2:	00000303          	lb	t1,0(zero) # 0 <mrac-0x7c0>
50010cd6:	0000                	unimp
50010cd8:	2230                	.insn	2, 0x2230
50010cda:	0f18                	add	a4,sp,912
50010cdc:	3032                	.insn	2, 0x3032
50010cde:	3532                	.insn	2, 0x3532
50010ce0:	3130                	.insn	2, 0x3130
50010ce2:	3130                	.insn	2, 0x3130
50010ce4:	3030                	.insn	2, 0x3030
50010ce6:	3030                	.insn	2, 0x3030
50010ce8:	3030                	.insn	2, 0x3030
50010cea:	185a                	sll	a6,a6,0x36
50010cec:	3230320f          	.insn	4, 0x3230320f
50010cf0:	30313037          	lui	zero,0x30313
50010cf4:	3031                	jal	50010500 <__func__.1+0x2b0>
50010cf6:	3030                	.insn	2, 0x3030
50010cf8:	3030                	.insn	2, 0x3030
50010cfa:	5a30                	lw	a2,112(a2)
50010cfc:	0000                	unimp
50010cfe:	0000                	unimp
50010d00:	862a                	mv	a2,a0
50010d02:	ce48                	sw	a0,28(a2)
50010d04:	023d                	add	tp,tp,15 # ffffd00f <_tbs_der_store_end+0xaffddfef>
50010d06:	0001                	nop
50010d08:	0030                	add	a2,sp,8
50010d0a:	0000                	unimp
50010d0c:	646c                	.insn	2, 0x646c
50010d0e:	7665                	lui	a2,0xffff9
50010d10:	6469                	lui	s0,0x1a
50010d12:	635f 6964 0000      	.insn	6, 0x6964635f
50010d18:	20494443          	.insn	4, 0x20494443
50010d1c:	6964                	.insn	2, 0x6964
50010d1e:	6576                	.insn	2, 0x6576
50010d20:	7372                	.insn	2, 0x7372
50010d22:	6669                	lui	a2,0x1a
50010d24:	6569                	lui	a0,0x1a
50010d26:	2064                	.insn	2, 0x2064
50010d28:	68746977          	.insn	4, 0x68746977
50010d2c:	6c20                	.insn	2, 0x6c20
50010d2e:	6261                	lui	tp,0x18
50010d30:	6c65                	lui	s8,0x19
50010d32:	2720                	.insn	2, 0x2720
50010d34:	646c                	.insn	2, 0x646c
50010d36:	7665                	lui	a2,0xffff9
50010d38:	6469                	lui	s0,0x1a
50010d3a:	635f 6964 2e27      	.insn	6, 0x2e276964635f
50010d40:	0000                	unimp
50010d42:	0000                	unimp
50010d44:	20494443          	.insn	4, 0x20494443
50010d48:	6964                	.insn	2, 0x6964
50010d4a:	6576                	.insn	2, 0x6576
50010d4c:	7372                	.insn	2, 0x7372
50010d4e:	6669                	lui	a2,0x1a
50010d50:	6569                	lui	a0,0x1a
50010d52:	2064                	.insn	2, 0x2064
50010d54:	68746977          	.insn	4, 0x68746977
50010d58:	4620                	lw	s0,72(a2)
50010d5a:	6569                	lui	a0,0x1a
50010d5c:	646c                	.insn	2, 0x646c
50010d5e:	4520                	lw	s0,72(a0)
50010d60:	746e                	.insn	2, 0x746e
50010d62:	6f72                	.insn	2, 0x6f72
50010d64:	7970                	.insn	2, 0x7970
50010d66:	6620                	.insn	2, 0x6620
50010d68:	6f72                	.insn	2, 0x6f72
50010d6a:	206d                	jal	50010e14 <__func__.2+0x194>
50010d6c:	746f6c53          	.insn	4, 0x746f6c53
50010d70:	2e31                	jal	5001108c <__func__.2+0x40c>
50010d72:	0000                	unimp
50010d74:	444c                	lw	a1,12(s0)
50010d76:	7665                	lui	a2,0xffff9
50010d78:	4449                	li	s0,18
50010d7a:	432e                	lw	t1,200(sp)
50010d7c:	4944                	lw	s1,20(a0)
50010d7e:	6420                	.insn	2, 0x6420
50010d80:	7265                	lui	tp,0xffff9
50010d82:	7669                	lui	a2,0xffffa
50010d84:	6465                	lui	s0,0x19
50010d86:	6120                	.insn	2, 0x6120
50010d88:	646e                	.insn	2, 0x646e
50010d8a:	7320                	.insn	2, 0x7320
50010d8c:	6f74                	.insn	2, 0x6f74
50010d8e:	6572                	.insn	2, 0x6572
50010d90:	2064                	.insn	2, 0x2064
50010d92:	6e69                	lui	t3,0x1a
50010d94:	4b20                	lw	s0,80(a4)
50010d96:	7965                	lui	s2,0xffff9
50010d98:	746f6c53          	.insn	4, 0x746f6c53
50010d9c:	2e36                	.insn	2, 0x2e36
50010d9e:	0000                	unimp
50010da0:	6946                	.insn	2, 0x6946
50010da2:	6c65                	lui	s8,0x19
50010da4:	2064                	.insn	2, 0x2064
50010da6:	6e45                	lui	t3,0x11
50010da8:	7274                	.insn	2, 0x7274
50010daa:	2079706f          	j	500a87b0 <_tbs_der_store_end+0x89790>
50010dae:	61656c63          	bltu	a0,s6,500113c6 <SOC_FW_data+0x156>
50010db2:	6572                	.insn	2, 0x6572
50010db4:	2064                	.insn	2, 0x2064
50010db6:	6e69                	lui	t3,0x1a
50010db8:	4b20                	lw	s0,80(a4)
50010dba:	7965                	lui	s2,0xffff9
50010dbc:	746f6c53          	.insn	4, 0x746f6c53
50010dc0:	2e31                	jal	500110dc <__func__.2+0x45c>
50010dc2:	0000                	unimp
50010dc4:	646c                	.insn	2, 0x646c
50010dc6:	7665                	lui	a2,0xffff9
50010dc8:	6469                	lui	s0,0x1a
50010dca:	6b5f 7965 6567      	.insn	6, 0x656779656b5f
50010dd0:	006e                	c.slli	zero,0x1b
50010dd2:	0000                	unimp
50010dd4:	4345                	li	t1,17
50010dd6:	65732043          	.insn	4, 0x65732043
50010dda:	6465                	lui	s0,0x19
50010ddc:	6420                	.insn	2, 0x6420
50010dde:	7265                	lui	tp,0xffff9
50010de0:	7669                	lui	a2,0xffffa
50010de2:	6465                	lui	s0,0x19
50010de4:	6120                	.insn	2, 0x6120
50010de6:	646e                	.insn	2, 0x646e
50010de8:	7320                	.insn	2, 0x7320
50010dea:	6f74                	.insn	2, 0x6f74
50010dec:	6572                	.insn	2, 0x6572
50010dee:	2064                	.insn	2, 0x2064
50010df0:	6e69                	lui	t3,0x1a
50010df2:	4b20                	lw	s0,80(a4)
50010df4:	7965                	lui	s2,0xffff9
50010df6:	746f6c53          	.insn	4, 0x746f6c53
50010dfa:	00002e33          	sltz	t3,zero
50010dfe:	0000                	unimp
50010e00:	4345                	li	t1,17
50010e02:	656b2043          	.insn	4, 0x656b2043
50010e06:	2079                	jal	50010e94 <__func__.2+0x214>
50010e08:	6170                	.insn	2, 0x6170
50010e0a:	7269                	lui	tp,0xffffa
50010e0c:	6720                	.insn	2, 0x6720
50010e0e:	6e65                	lui	t3,0x19
50010e10:	7265                	lui	tp,0xffff9
50010e12:	7461                	lui	s0,0xffff8
50010e14:	6465                	lui	s0,0x19
50010e16:	203a                	.insn	2, 0x203a
50010e18:	7250                	.insn	2, 0x7250
50010e1a:	7669                	lui	a2,0xffffa
50010e1c:	7461                	lui	s0,0xffff8
50010e1e:	2065                	jal	50010ec6 <__func__.2+0x246>
50010e20:	6e69                	lui	t3,0x1a
50010e22:	5320                	lw	s0,96(a4)
50010e24:	6f6c                	.insn	2, 0x6f6c
50010e26:	3574                	.insn	2, 0x3574
50010e28:	202c                	.insn	2, 0x202c
50010e2a:	7550                	.insn	2, 0x7550
50010e2c:	6c62                	.insn	2, 0x6c62
50010e2e:	6369                	lui	t1,0x1a
50010e30:	7220                	.insn	2, 0x7220
50010e32:	7465                	lui	s0,0xffff9
50010e34:	7275                	lui	tp,0xffffd
50010e36:	656e                	.insn	2, 0x656e
50010e38:	2e64                	.insn	2, 0x2e64
50010e3a:	0000                	unimp
50010e3c:	6554                	.insn	2, 0x6554
50010e3e:	706d                	c.lui	zero,0xffffb
50010e40:	7261726f          	jal	tp,50028566 <_tbs_der_store_end+0x9546>
50010e44:	2079                	jal	50010ed2 <__func__.2+0x252>
50010e46:	64656573          	csrrs	a0,hviprio1,10
50010e4a:	6320                	.insn	2, 0x6320
50010e4c:	656c                	.insn	2, 0x656c
50010e4e:	7261                	lui	tp,0xffff8
50010e50:	6465                	lui	s0,0x19
50010e52:	6920                	.insn	2, 0x6920
50010e54:	206e                	.insn	2, 0x206e
50010e56:	5379654b          	.insn	4, 0x5379654b
50010e5a:	6f6c                	.insn	2, 0x6f6c
50010e5c:	3374                	.insn	2, 0x3374
50010e5e:	002e                	c.slli	zero,0xb
50010e60:	696c6143          	.insn	4, 0x696c6143
50010e64:	7470                	.insn	2, 0x7470
50010e66:	6172                	.insn	2, 0x6172
50010e68:	3120                	.insn	2, 0x3120
50010e6a:	302e                	.insn	2, 0x302e
50010e6c:	4c20                	lw	s0,88(s0)
50010e6e:	6544                	.insn	2, 0x6544
50010e70:	4976                	lw	s2,92(sp)
50010e72:	0044                	add	s1,sp,4
50010e74:	696c6143          	.insn	4, 0x696c6143
50010e78:	7470                	.insn	2, 0x7470
50010e7a:	6172                	.insn	2, 0x6172
50010e7c:	3120                	.insn	2, 0x3120
50010e7e:	302e                	.insn	2, 0x302e
50010e80:	4920                	lw	s0,80(a0)
50010e82:	6544                	.insn	2, 0x6544
50010e84:	4976                	lw	s2,92(sp)
50010e86:	0044                	add	s1,sp,4
50010e88:	74726563          	bltu	tp,t2,500115d2 <SOC_FW_data+0x362>
50010e8c:	6c5f 6e65 3d20      	.insn	6, 0x3d206e656c5f
50010e92:	3020                	.insn	2, 0x3020
50010e94:	2578                	.insn	2, 0x2578
50010e96:	0a78                	add	a4,sp,284
50010e98:	0000                	unimp
50010e9a:	0000                	unimp
50010e9c:	644c                	.insn	2, 0x644c
50010e9e:	5665                	li	a2,-7
50010ea0:	4449                	li	s0,18
50010ea2:	7420                	.insn	2, 0x7420
50010ea4:	7362                	.insn	2, 0x7362
50010ea6:	6420                	.insn	2, 0x6420
50010ea8:	7265                	lui	tp,0xffff9
50010eaa:	003a                	c.slli	zero,0xe
50010eac:	7325                	lui	t1,0xfffe9
50010eae:	5825                	li	a6,-23
50010eb0:	0000                	unimp
50010eb2:	0000                	unimp
50010eb4:	656e6567          	.insn	4, 0x656e6567
50010eb8:	6172                	.insn	2, 0x6172
50010eba:	6574                	.insn	2, 0x6574
50010ebc:	4c20                	lw	s0,88(s0)
50010ebe:	6564                	.insn	2, 0x6564
50010ec0:	4956                	lw	s2,84(sp)
50010ec2:	2044                	.insn	2, 0x2044
50010ec4:	74726563          	bltu	tp,t2,5001160e <SOC_FW_data+0x39e>
50010ec8:	6420                	.insn	2, 0x6420
50010eca:	7265                	lui	tp,0xffff9
50010ecc:	6620                	.insn	2, 0x6620
50010ece:	6961                	lui	s2,0x18
50010ed0:	646c                	.insn	2, 0x646c
50010ed2:	0021                	c.nop	8
50010ed4:	6564                	.insn	2, 0x6564
50010ed6:	5f72                	lw	t5,60(sp)
50010ed8:	2e727363          	bgeu	tp,t2,500111be <__func__.2+0x53e>
50010edc:	6964                	.insn	2, 0x6964
50010ede:	74736567          	.insn	4, 0x74736567
50010ee2:	003a                	c.slli	zero,0xe
50010ee4:	6e676953          	.insn	4, 0x6e676953
50010ee8:	7461                	lui	s0,0xffff8
50010eea:	7275                	lui	tp,0xffffd
50010eec:	2065                	jal	50010f94 <__func__.2+0x314>
50010eee:	3a52                	.insn	2, 0x3a52
50010ef0:	0000                	unimp
50010ef2:	0000                	unimp
50010ef4:	3025                	jal	5001071c <__func__.0+0x20c>
50010ef6:	7838                	.insn	2, 0x7838
50010ef8:	0020                	add	s0,sp,8
50010efa:	0000                	unimp
50010efc:	530a                	lw	t1,160(sp)
50010efe:	6769                	lui	a4,0x1a
50010f00:	616e                	.insn	2, 0x616e
50010f02:	7574                	.insn	2, 0x7574
50010f04:	6572                	.insn	2, 0x6572
50010f06:	5320                	lw	s0,96(a4)
50010f08:	003a                	c.slli	zero,0xe
50010f0a:	0000                	unimp
50010f0c:	6554                	.insn	2, 0x6554
50010f0e:	706d                	c.lui	zero,0xffffb
50010f10:	7261726f          	jal	tp,50028636 <_tbs_der_store_end+0x9616>
50010f14:	2079                	jal	50010fa2 <__func__.2+0x322>
50010f16:	64656573          	csrrs	a0,hviprio1,10
50010f1a:	6320                	.insn	2, 0x6320
50010f1c:	656c                	.insn	2, 0x656c
50010f1e:	7261                	lui	tp,0xffff8
50010f20:	6465                	lui	s0,0x19
50010f22:	6920                	.insn	2, 0x6920
50010f24:	206e                	.insn	2, 0x206e
50010f26:	5379654b          	.insn	4, 0x5379654b
50010f2a:	6f6c                	.insn	2, 0x6f6c
50010f2c:	3774                	.insn	2, 0x3774
50010f2e:	002e                	c.slli	zero,0xb
50010f30:	6469                	lui	s0,0x1a
50010f32:	7665                	lui	a2,0xffff9
50010f34:	6469                	lui	s0,0x1a
50010f36:	705f 6275 656b      	.insn	6, 0x656b6275705f
50010f3c:	5f79                	li	t5,-2
50010f3e:	2e78                	.insn	2, 0x2e78
50010f40:	6164                	.insn	2, 0x6164
50010f42:	6174                	.insn	2, 0x6174
50010f44:	003a                	c.slli	zero,0xe
50010f46:	0000                	unimp
50010f48:	6469                	lui	s0,0x1a
50010f4a:	7665                	lui	a2,0xffff9
50010f4c:	6469                	lui	s0,0x1a
50010f4e:	705f 6275 656b      	.insn	6, 0x656b6275705f
50010f54:	5f79                	li	t5,-2
50010f56:	2e79                	jal	500112f4 <SOC_FW_data+0x84>
50010f58:	6164                	.insn	2, 0x6164
50010f5a:	6174                	.insn	2, 0x6174
50010f5c:	003a                	c.slli	zero,0xe
50010f5e:	0000                	unimp
50010f60:	6e676953          	.insn	4, 0x6e676953
50010f64:	7461                	lui	s0,0xffff8
50010f66:	7275                	lui	tp,0xffffd
50010f68:	2065                	jal	50011010 <__func__.2+0x390>
50010f6a:	6576                	.insn	2, 0x6576
50010f6c:	6972                	.insn	2, 0x6972
50010f6e:	6966                	.insn	2, 0x6966
50010f70:	69746163          	bltu	s0,s7,500115f2 <SOC_FW_data+0x382>
50010f74:	73206e6f          	jal	t3,500176a6 <FMC_data+0x4436>
50010f78:	6375                	lui	t1,0x1d
50010f7a:	73736563          	bltu	t1,s7,500116a4 <SOC_FW_data+0x434>
50010f7e:	7566                	.insn	2, 0x7566
50010f80:	216c                	.insn	2, 0x216c
50010f82:	0000                	unimp
50010f84:	6e676953          	.insn	4, 0x6e676953
50010f88:	7461                	lui	s0,0xffff8
50010f8a:	7275                	lui	tp,0xffffd
50010f8c:	2065                	jal	50011034 <__func__.2+0x3b4>
50010f8e:	6576                	.insn	2, 0x6576
50010f90:	6972                	.insn	2, 0x6972
50010f92:	6966                	.insn	2, 0x6966
50010f94:	69746163          	bltu	s0,s7,50011616 <SOC_FW_data+0x3a6>
50010f98:	66206e6f          	jal	t3,500175fa <FMC_data+0x438a>
50010f9c:	6961                	lui	s2,0x18
50010f9e:	656c                	.insn	2, 0x656c
50010fa0:	2164                	.insn	2, 0x2164
50010fa2:	0000                	unimp
50010fa4:	644c                	.insn	2, 0x644c
50010fa6:	5665                	li	a2,-7
50010fa8:	4449                	li	s0,18
50010faa:	6320                	.insn	2, 0x6320
50010fac:	7265                	lui	tp,0xffff9
50010fae:	3a74                	.insn	2, 0x3a74
50010fb0:	0000                	unimp
50010fb2:	0000                	unimp
50010fb4:	6469                	lui	s0,0x1a
50010fb6:	7665                	lui	a2,0xffff9
50010fb8:	6469                	lui	s0,0x1a
50010fba:	635f 6964 0000      	.insn	6, 0x6964635f
50010fc0:	6c62                	.insn	2, 0x6c62
50010fc2:	5f6b636f          	jal	t1,500c75b8 <_tbs_der_store_end+0xa8598>
50010fc6:	2e696463          	bltu	s2,t1,500112ae <SOC_FW_data+0x3e>
50010fca:	6164                	.insn	2, 0x6164
50010fcc:	6174                	.insn	2, 0x6174
50010fce:	003a                	c.slli	zero,0xe
50010fd0:	4449                	li	s0,18
50010fd2:	7665                	lui	a2,0xffff9
50010fd4:	4449                	li	s0,18
50010fd6:	432e                	lw	t1,200(sp)
50010fd8:	4944                	lw	s1,20(a0)
50010fda:	6420                	.insn	2, 0x6420
50010fdc:	7265                	lui	tp,0xffff9
50010fde:	7669                	lui	a2,0xffffa
50010fe0:	6465                	lui	s0,0x19
50010fe2:	6120                	.insn	2, 0x6120
50010fe4:	646e                	.insn	2, 0x646e
50010fe6:	7320                	.insn	2, 0x7320
50010fe8:	6f74                	.insn	2, 0x6f74
50010fea:	6572                	.insn	2, 0x6572
50010fec:	2064                	.insn	2, 0x2064
50010fee:	6e69                	lui	t3,0x1a
50010ff0:	4b20                	lw	s0,80(a4)
50010ff2:	7965                	lui	s2,0xffff9
50010ff4:	746f6c53          	.insn	4, 0x746f6c53
50010ff8:	2e36                	.insn	2, 0x2e36
50010ffa:	0000                	unimp
50010ffc:	4455                	li	s0,21
50010ffe:	6c632053          	.insn	4, 0x6c632053
50011002:	6165                	add	sp,sp,112
50011004:	6572                	.insn	2, 0x6572
50011006:	2064                	.insn	2, 0x2064
50011008:	6e69                	lui	t3,0x1a
5001100a:	4b20                	lw	s0,80(a4)
5001100c:	7965                	lui	s2,0xffff9
5001100e:	746f6c53          	.insn	4, 0x746f6c53
50011012:	2e30                	.insn	2, 0x2e30
50011014:	0000                	unimp
50011016:	0000                	unimp
50011018:	6469                	lui	s0,0x1a
5001101a:	7665                	lui	a2,0xffff9
5001101c:	6469                	lui	s0,0x1a
5001101e:	6b5f 7965 6567      	.insn	6, 0x656779656b5f
50011024:	006e                	c.slli	zero,0x1b
50011026:	0000                	unimp
50011028:	6c62                	.insn	2, 0x6c62
5001102a:	5f6b636f          	jal	t1,500c7620 <_tbs_der_store_end+0xa8600>
5001102e:	64656573          	csrrs	a0,hviprio1,10
50011032:	642e                	.insn	2, 0x642e
50011034:	7461                	lui	s0,0xffff8
50011036:	3a61                	jal	500109ce <k+0x14e>
50011038:	0000                	unimp
5001103a:	0000                	unimp
5001103c:	4345                	li	t1,17
5001103e:	656b2043          	.insn	4, 0x656b2043
50011042:	2079                	jal	500110d0 <__func__.2+0x450>
50011044:	6170                	.insn	2, 0x6170
50011046:	7269                	lui	tp,0xffffa
50011048:	6720                	.insn	2, 0x6720
5001104a:	6e65                	lui	t3,0x19
5001104c:	7265                	lui	tp,0xffff9
5001104e:	7461                	lui	s0,0xffff8
50011050:	6465                	lui	s0,0x19
50011052:	203a                	.insn	2, 0x203a
50011054:	7250                	.insn	2, 0x7250
50011056:	7669                	lui	a2,0xffffa
50011058:	7461                	lui	s0,0xffff8
5001105a:	2065                	jal	50011102 <__func__.2+0x482>
5001105c:	6e69                	lui	t3,0x1a
5001105e:	5320                	lw	s0,96(a4)
50011060:	6f6c                	.insn	2, 0x6f6c
50011062:	3774                	.insn	2, 0x3774
50011064:	202c                	.insn	2, 0x202c
50011066:	7550                	.insn	2, 0x7550
50011068:	6c62                	.insn	2, 0x6c62
5001106a:	6369                	lui	t1,0x1a
5001106c:	7220                	.insn	2, 0x7220
5001106e:	7465                	lui	s0,0xffff9
50011070:	7275                	lui	tp,0xffffd
50011072:	656e                	.insn	2, 0x656e
50011074:	2e64                	.insn	2, 0x2e64
50011076:	0000                	unimp
50011078:	7570                	.insn	2, 0x7570
5001107a:	6b62                	.insn	2, 0x6b62
5001107c:	7965                	lui	s2,0xffff9
5001107e:	785f 642e 7461      	.insn	6, 0x7461642e785f
50011084:	3a61                	jal	50010a1c <k+0x19c>
50011086:	0000                	unimp
50011088:	7570                	.insn	2, 0x7570
5001108a:	6b62                	.insn	2, 0x6b62
5001108c:	7965                	lui	s2,0xffff9
5001108e:	795f 642e 7461      	.insn	6, 0x7461642e795f
50011094:	3a61                	jal	50010a2c <k+0x1ac>
50011096:	0000                	unimp
50011098:	6449                	lui	s0,0x12
5001109a:	5665                	li	a2,-7
5001109c:	4449                	li	s0,18
5001109e:	7420                	.insn	2, 0x7420
500110a0:	7362                	.insn	2, 0x7362
500110a2:	6420                	.insn	2, 0x6420
500110a4:	7265                	lui	tp,0xffff9
500110a6:	003a                	c.slli	zero,0xe
500110a8:	656e6567          	.insn	4, 0x656e6567
500110ac:	6172                	.insn	2, 0x6172
500110ae:	6574                	.insn	2, 0x6574
500110b0:	4920                	lw	s0,80(a0)
500110b2:	6564                	.insn	2, 0x6564
500110b4:	4956                	lw	s2,84(sp)
500110b6:	2044                	.insn	2, 0x2044
500110b8:	74726563          	bltu	tp,t2,50011802 <SOC_FW_data+0x592>
500110bc:	6420                	.insn	2, 0x6420
500110be:	7265                	lui	tp,0xffff9
500110c0:	6620                	.insn	2, 0x6620
500110c2:	6961                	lui	s2,0x18
500110c4:	646c                	.insn	2, 0x646c
500110c6:	0021                	c.nop	8
500110c8:	6449                	lui	s0,0x12
500110ca:	5665                	li	a2,-7
500110cc:	4449                	li	s0,18
500110ce:	6320                	.insn	2, 0x6320
500110d0:	7265                	lui	tp,0xffff9
500110d2:	3a74                	.insn	2, 0x3a74
500110d4:	0000                	unimp
500110d6:	0000                	unimp
500110d8:	2d2d                	jal	50011712 <SOC_FW_data+0x4a2>
500110da:	2d2d                	jal	50011714 <SOC_FW_data+0x4a4>
500110dc:	2d2d                	jal	50011716 <SOC_FW_data+0x4a6>
500110de:	2d2d                	jal	50011718 <SOC_FW_data+0x4a8>
500110e0:	2d2d                	jal	5001171a <SOC_FW_data+0x4aa>
500110e2:	2d2d                	jal	5001171c <SOC_FW_data+0x4ac>
500110e4:	2d2d                	jal	5001171e <SOC_FW_data+0x4ae>
500110e6:	2d2d                	jal	50011720 <SOC_FW_data+0x4b0>
500110e8:	2d2d                	jal	50011722 <SOC_FW_data+0x4b2>
500110ea:	2d2d                	jal	50011724 <SOC_FW_data+0x4b4>
500110ec:	2d2d                	jal	50011726 <SOC_FW_data+0x4b6>
500110ee:	2d2d                	jal	50011728 <SOC_FW_data+0x4b8>
500110f0:	2d2d                	jal	5001172a <SOC_FW_data+0x4ba>
500110f2:	2d2d                	jal	5001172c <SOC_FW_data+0x4bc>
500110f4:	2d2d                	jal	5001172e <SOC_FW_data+0x4be>
500110f6:	2d2d                	jal	50011730 <SOC_FW_data+0x4c0>
500110f8:	2d2d                	jal	50011732 <SOC_FW_data+0x4c2>
500110fa:	2d2d                	jal	50011734 <SOC_FW_data+0x4c4>
500110fc:	0000                	unimp
500110fe:	0000                	unimp
50011100:	2020                	.insn	2, 0x2020
50011102:	2020                	.insn	2, 0x2020
50011104:	2020                	.insn	2, 0x2020
50011106:	2020                	.insn	2, 0x2020
50011108:	2020                	.insn	2, 0x2020
5001110a:	2020                	.insn	2, 0x2020
5001110c:	696c6143          	.insn	4, 0x696c6143
50011110:	7470                	.insn	2, 0x7470
50011112:	6172                	.insn	2, 0x6172
50011114:	5220                	lw	s0,96(a2)
50011116:	2e2e4d4f          	.insn	4, 0x2e2e4d4f
5001111a:	202e                	.insn	2, 0x202e
5001111c:	2020                	.insn	2, 0x2020
5001111e:	2020                	.insn	2, 0x2020
50011120:	2020                	.insn	2, 0x2020
50011122:	2020                	.insn	2, 0x2020
50011124:	0000                	unimp
50011126:	0000                	unimp
50011128:	3031                	jal	50010934 <k+0xb4>
5001112a:	343a                	.insn	2, 0x343a
5001112c:	3a34                	.insn	2, 0x3a34
5001112e:	3530                	.insn	2, 0x3530
50011130:	0000                	unimp
50011132:	0000                	unimp
50011134:	7541                	lui	a0,0xffff0
50011136:	31312067          	.insn	4, 0x31312067
5001113a:	3220                	.insn	2, 0x3220
5001113c:	3230                	.insn	2, 0x3230
5001113e:	0035                	c.nop	13
50011140:	706d6f43          	.insn	4, 0x706d6f43
50011144:	6c69                	lui	s8,0x1a
50011146:	6465                	lui	s0,0x19
50011148:	6f20                	.insn	2, 0x6f20
5001114a:	3a6e                	.insn	2, 0x3a6e
5001114c:	2520                	.insn	2, 0x2520
5001114e:	74612073          	csrs	0x746,sp
50011152:	2520                	.insn	2, 0x2520
50011154:	00000a73          	.insn	4, 0x0a73
50011158:	4d46                	lw	s10,80(sp)
5001115a:	69662043          	.insn	4, 0x69662043
5001115e:	6d72                	.insn	2, 0x6d72
50011160:	72696177          	.insn	4, 0x72696177
50011164:	3a65                	jal	50010b1c <k+0x29c>
50011166:	0000                	unimp
50011168:	6425                	lui	s0,0x9
5001116a:	0a3a                	sll	s4,s4,0xe
5001116c:	0000                	unimp
5001116e:	0000                	unimp
50011170:	7830                	.insn	2, 0x7830
50011172:	3025                	jal	5001099a <k+0x11a>
50011174:	7832                	.insn	2, 0x7832
50011176:	0020                	add	s0,sp,8
50011178:	654d                	lui	a0,0x13
5001117a:	7361                	lui	t1,0xffff8
5001117c:	7275                	lui	tp,0xffffd
5001117e:	2065                	jal	50011226 <__func__.2+0x5a6>
50011180:	4d46                	lw	s10,80(sp)
50011182:	74732043          	.insn	4, 0x74732043
50011186:	7261                	lui	tp,0xffff8
50011188:	3a74                	.insn	2, 0x3a74
5001118a:	0000                	unimp
5001118c:	20434f53          	.insn	4, 0x20434f53
50011190:	6966                	.insn	2, 0x6966
50011192:	6d72                	.insn	2, 0x6d72
50011194:	72696177          	.insn	4, 0x72696177
50011198:	3a65                	jal	50010b50 <k+0x2d0>
5001119a:	0000                	unimp
5001119c:	654d                	lui	a0,0x13
5001119e:	7361                	lui	t1,0xffff8
500111a0:	7275                	lui	tp,0xffffd
500111a2:	2065                	jal	5001124a <__func__.2+0x5ca>
500111a4:	20434f53          	.insn	4, 0x20434f53
500111a8:	72617473          	csrrc	s0,mhpmevent6h,2
500111ac:	3a74                	.insn	2, 0x3a74
500111ae:	0000                	unimp
500111b0:	754a                	.insn	2, 0x754a
500111b2:	706d                	c.lui	zero,0xffffb
500111b4:	7420                	.insn	2, 0x7420
500111b6:	4d46206f          	j	5007368a <_tbs_der_store_end+0x5466a>
500111ba:	2e2e2e43          	.insn	4, 0x2e2e2e43
500111be:	0000                	unimp
500111c0:	4d46                	lw	s10,80(sp)
500111c2:	69662043          	.insn	4, 0x69662043
500111c6:	6d72                	.insn	2, 0x6d72
500111c8:	72696177          	.insn	4, 0x72696177
500111cc:	3265                	jal	50010b74 <k+0x2f4>
500111ce:	003a                	c.slli	zero,0xe
500111d0:	654d                	lui	a0,0x13
500111d2:	7361                	lui	t1,0xffff8
500111d4:	7275                	lui	tp,0xffffd
500111d6:	2065                	jal	5001127e <SOC_FW_data+0xe>
500111d8:	4d46                	lw	s10,80(sp)
500111da:	74732043          	.insn	4, 0x74732043
500111de:	7261                	lui	tp,0xffff8
500111e0:	3274                	.insn	2, 0x3274
500111e2:	003a                	c.slli	zero,0xe
500111e4:	20434f53          	.insn	4, 0x20434f53
500111e8:	6966                	.insn	2, 0x6966
500111ea:	6d72                	.insn	2, 0x6d72
500111ec:	72696177          	.insn	4, 0x72696177
500111f0:	3265                	jal	50010b98 <k+0x318>
500111f2:	003a                	c.slli	zero,0xe
500111f4:	654d                	lui	a0,0x13
500111f6:	7361                	lui	t1,0xffff8
500111f8:	7275                	lui	tp,0xffffd
500111fa:	2065                	jal	500112a2 <SOC_FW_data+0x32>
500111fc:	20434f53          	.insn	4, 0x20434f53
50011200:	72617473          	csrrc	s0,mhpmevent6h,2
50011204:	3274                	.insn	2, 0x3274
50011206:	003a                	c.slli	zero,0xe
50011208:	5220                	lw	s0,96(a2)
5001120a:	6165                	add	sp,sp,112
5001120c:	64656863          	bltu	a0,t1,5001185c <SOC_FW_data+0x5ec>
50011210:	6520                	.insn	2, 0x6520
50011212:	646e                	.insn	2, 0x646e
50011214:	6f20                	.insn	2, 0x6f20
50011216:	2066                	.insn	2, 0x2066
50011218:	4f52                	lw	t5,20(sp)
5001121a:	204d                	jal	500112bc <SOC_FW_data+0x4c>
5001121c:	5746                	lw	a4,112(sp)
5001121e:	7520                	.insn	2, 0x7520
50011220:	656e                	.insn	2, 0x656e
50011222:	7078                	.insn	2, 0x7078
50011224:	6365                	lui	t1,0x19
50011226:	6574                	.insn	2, 0x6574
50011228:	6c64                	.insn	2, 0x6c64
5001122a:	2179                	jal	500116b8 <SOC_FW_data+0x448>
5001122c:	0000                	unimp
5001122e:	0000                	unimp
50011230:	9ed8                	.insn	2, 0x9ed8
50011232:	c105                	beqz	a0,50011252 <__func__.2+0x5d2>
50011234:	9d5d                	.insn	2, 0x9d5d
50011236:	d507cbbb          	.insn	4, 0xd507cbbb
5001123a:	367c                	.insn	2, 0x367c
5001123c:	292a                	.insn	2, 0x292a
5001123e:	629a                	.insn	2, 0x629a
50011240:	3070dd17          	auipc	s10,0x3070d
50011244:	015a                	sll	sp,sp,0x16
50011246:	9159                	srl	a0,a0,0x36
50011248:	5939                	li	s2,-18
5001124a:	f70e                	.insn	2, 0xf70e
5001124c:	ecd8                	.insn	2, 0xecd8
5001124e:	0b31152f          	.insn	4, 0x0b31152f
50011252:	ffc0                	.insn	2, 0xffc0
50011254:	67332667          	.insn	4, 0x67332667
50011258:	1511                	add	a0,a0,-28 # 12fe4 <mfdc+0x127eb>
5001125a:	6858                	.insn	2, 0x6858
5001125c:	8eb44a87          	.insn	4, 0x8eb44a87
50011260:	64f98fa7          	.insn	4, 0x64f98fa7
50011264:	2e0d                	jal	50011596 <SOC_FW_data+0x326>
50011266:	db0c                	sw	a1,48(a4)
50011268:	4fa4                	lw	s1,88(a5)
5001126a:	befa                	.insn	2, 0xbefa
5001126c:	481d                	li	a6,7
5001126e:	47b5                	li	a5,13

Disassembly of section .dccm:

50011270 <SOC_FW_data>:
	...

50013270 <FMC_data>:
	...

Disassembly of section .cert_store:

5001e000 <cert_store>:
	...

Disassembly of section .tbs_der_store:

5001e820 <tbs_der_store>:
	...

Disassembly of section .comment:

00000000 <.comment>:
   0:	3a434347          	.insn	4, 0x3a434347
   4:	2820                	.insn	2, 0x2820
   6:	2029                	jal	10 <mrac-0x7b0>
   8:	3331                	jal	fffffd14 <_tbs_der_store_end+0xaffe0cf4>
   a:	312e                	.insn	2, 0x312e
   c:	312e                	.insn	2, 0x312e
   e:	3220                	.insn	2, 0x3220
  10:	3230                	.insn	2, 0x3230
  12:	31373033          	.insn	4, 0x31373033
  16:	43470033          	.insn	4, 0x43470033
  1a:	28203a43          	.insn	4, 0x28203a43
  1e:	29554e47          	.insn	4, 0x29554e47
  22:	3120                	.insn	2, 0x3120
  24:	2e312e33          	.insn	4, 0x2e312e33
  28:	2031                	jal	34 <mrac-0x78c>
  2a:	3032                	.insn	2, 0x3032
  2c:	3332                	.insn	2, 0x3332
  2e:	3730                	.insn	2, 0x3730
  30:	3331                	jal	fffffd3c <_tbs_der_store_end+0xaffe0d1c>
	...

Disassembly of section .riscv.attributes:

00000000 <.riscv.attributes>:
   0:	3241                	jal	fffff980 <_tbs_der_store_end+0xaffe0960>
   2:	0000                	unimp
   4:	7200                	.insn	2, 0x7200
   6:	7369                	lui	t1,0xffffa
   8:	01007663          	bgeu	zero,a6,14 <mrac-0x7ac>
   c:	0028                	add	a0,sp,8
   e:	0000                	unimp
  10:	1004                	add	s1,sp,32
  12:	7205                	lui	tp,0xfffe1
  14:	3376                	.insn	2, 0x3376
  16:	6932                	.insn	2, 0x6932
  18:	7032                	.insn	2, 0x7032
  1a:	5f30                	lw	a2,120(a4)
  1c:	326d                	jal	fffff9c6 <_tbs_der_store_end+0xaffe09a6>
  1e:	3070                	.insn	2, 0x3070
  20:	635f 7032 5f30      	.insn	6, 0x5f307032635f
  26:	6d7a                	.insn	2, 0x6d7a
  28:	756d                	lui	a0,0xffffb
  2a:	316c                	.insn	2, 0x316c
  2c:	3070                	.insn	2, 0x3070
  2e:	0800                	add	s0,sp,16
  30:	0a01                	add	s4,s4,0 # 14bc5000 <mfdc+0x14bc4807>
  32:	0b              	Address 0x32 is out of bounds.


Disassembly of section .debug_info:

00000000 <.debug_info>:
   0:	01b2                	sll	gp,gp,0xc
   2:	0000                	unimp
   4:	0005                	c.nop	1
   6:	0401                	add	s0,s0,0 # 9000 <mfdc+0x8807>
   8:	0000                	unimp
   a:	0000                	unimp
   c:	0000b407          	.insn	4, 0xb407
  10:	1d00                	add	s0,sp,688
  12:	0000                	unimp
  14:	0000                	unimp
  16:	0026                	c.slli	zero,0x9
  18:	0000                	unimp
  1a:	8f4a                	mv	t5,s2
  1c:	4001                	c.li	zero,0
  1e:	0028                	add	a0,sp,8
  20:	0000                	unimp
  22:	0000                	unimp
  24:	0000                	unimp
  26:	0801                	add	a6,a6,0 # ffff9000 <_tbs_der_store_end+0xaffd9fe0>
  28:	00007607          	.insn	4, 0x7607
  2c:	0100                	add	s0,sp,128
  2e:	0704                	add	s1,sp,896
  30:	0080                	add	s0,sp,64
  32:	0000                	unimp
  34:	0408                	add	a0,sp,512
  36:	6905                	lui	s2,0x1
  38:	746e                	.insn	2, 0x746e
  3a:	0100                	add	s0,sp,128
  3c:	0508                	add	a0,sp,640
  3e:	008d                	add	ra,ra,3
  40:	0000                	unimp
  42:	1001                	c.nop	-32
  44:	6a04                	.insn	2, 0x6a04
  46:	0000                	unimp
  48:	0100                	add	s0,sp,128
  4a:	0601                	add	a2,a2,0 # ffffa000 <_tbs_der_store_end+0xaffdafe0>
  4c:	0031                	c.nop	12
  4e:	0000                	unimp
  50:	0101                	add	sp,sp,0 # 3b2f7000 <mfdc+0x3b2f6807>
  52:	2f08                	.insn	2, 0x2f08
  54:	0000                	unimp
  56:	0100                	add	s0,sp,128
  58:	0502                	c.slli64	a0
  5a:	0000009b          	.insn	4, 0x009b
  5e:	0201                	add	tp,tp,0 # fffe1000 <_tbs_der_store_end+0xaffc1fe0>
  60:	00003d07          	.insn	4, 0x3d07
  64:	0100                	add	s0,sp,128
  66:	0504                	add	s1,sp,640
  68:	0092                	sll	ra,ra,0x4
  6a:	0000                	unimp
  6c:	0401                	add	s0,s0,0
  6e:	00007b07          	.insn	4, 0x7b07
  72:	0100                	add	s0,sp,128
  74:	0801                	add	a6,a6,0
  76:	0038                	add	a4,sp,8
  78:	0000                	unimp
  7a:	0101                	add	sp,sp,0
  7c:	8d02                	jr	s10
  7e:	0001                	nop
  80:	0200                	add	s0,sp,256
  82:	0028                	add	a0,sp,8
  84:	0000                	unimp
  86:	0f80                	add	s0,sp,976
  88:	0034                	add	a3,sp,8
  8a:	0000                	unimp
  8c:	2702                	.insn	2, 0x2702
  8e:	0000                	unimp
  90:	8100                	.insn	2, 0x8100
  92:	2d16                	.insn	2, 0x2d16
  94:	0000                	unimp
  96:	0300                	add	s0,sp,384
  98:	008c                	add	a1,sp,64
  9a:	0000                	unimp
  9c:	9302                	jalr	t1
  9e:	0001                	nop
  a0:	8400                	.insn	2, 0x8400
  a2:	00003b0f          	.insn	4, 0x3b0f
  a6:	0100                	add	s0,sp,128
  a8:	0402                	c.slli64	s0
  aa:	001e                	c.slli	zero,0x7
  ac:	0000                	unimp
  ae:	0401                	add	s0,s0,0
  b0:	00001603          	lh	a2,0(zero) # 0 <mrac-0x7c0>
  b4:	0100                	add	s0,sp,128
  b6:	0404                	add	s1,sp,512
  b8:	0176                	sll	sp,sp,0x1d
  ba:	0000                	unimp
  bc:	0801                	add	a6,a6,0
  be:	00016e03          	.insn	4, 0x00016e03
  c2:	0100                	add	s0,sp,128
  c4:	0408                	add	a0,sp,512
  c6:	0000006f          	j	c6 <mrac-0x6fa>
  ca:	1001                	c.nop	-32
  cc:	0000a503          	lw	a0,0(ra)
  d0:	0100                	add	s0,sp,128
  d2:	0320                	add	s0,sp,392
  d4:	0062                	c.slli	zero,0x18
  d6:	0000                	unimp
  d8:	7c02                	.insn	2, 0x7c02
  da:	0001                	nop
  dc:	a800                	.insn	2, 0xa800
  de:	340d                	jal	fffffb00 <_tbs_der_store_end+0xaffe0ae0>
  e0:	0000                	unimp
  e2:	0300                	add	s0,sp,384
  e4:	00d8                	add	a4,sp,68
  e6:	0000                	unimp
  e8:	0009                	c.nop	2
  ea:	0000                	unimp
  ec:	0800                	add	s0,sp,16
  ee:	f102                	.insn	2, 0xf102
  f0:	0a01                	add	s4,s4,0
  f2:	00000113          	li	sp,0
  f6:	6c0a                	.insn	2, 0x6c0a
  f8:	0200776f          	jal	a4,7118 <mfdc+0x691f>
  fc:	01f1                	add	gp,gp,28
  fe:	811a                	mv	sp,t1
 100:	0000                	unimp
 102:	0000                	unimp
 104:	0000090b          	.insn	4, 0x090b
 108:	0200                	add	s0,sp,256
 10a:	01f1                	add	gp,gp,28
 10c:	811f 0000 0400      	.insn	6, 0x04000000811f
 112:	0c00                	add	s0,sp,528
 114:	0208                	add	a0,sp,256
 116:	01f8                	add	a4,sp,204
 118:	3309                	jal	fffffe1a <_tbs_der_store_end+0xaffe0dfa>
 11a:	0001                	nop
 11c:	0400                	add	s0,sp,512
 11e:	01fa0073          	.insn	4, 0x01fa0073
 122:	0000e813          	or	a6,ra,0
 126:	0400                	add	s0,sp,512
 128:	6c6c                	.insn	2, 0x6c6c
 12a:	fb00                	.insn	2, 0xfb00
 12c:	0a01                	add	s4,s4,0
 12e:	009c                	add	a5,sp,64
 130:	0000                	unimp
 132:	0d00                	add	s0,sp,656
 134:	0050                	add	a2,sp,4
 136:	0000                	unimp
 138:	fc02                	.insn	2, 0xfc02
 13a:	0301                	add	t1,t1,0 # ffffa000 <_tbs_der_store_end+0xaffdafe0>
 13c:	00000113          	li	sp,0
 140:	00013303          	.insn	4, 0x00013303
 144:	0e00                	add	s0,sp,784
 146:	0058                	add	a4,sp,4
 148:	0000                	unimp
 14a:	8001                	c.srli64	s0
 14c:	0101                	add	sp,sp,0
 14e:	009c                	add	a5,sp,64
 150:	0000                	unimp
 152:	8f4a                	mv	t5,s2
 154:	4001                	c.li	zero,0
 156:	0028                	add	a0,sp,8
 158:	0000                	unimp
 15a:	9c01                	.insn	2, 0x9c01
 15c:	7505                	lui	a0,0xfffe1
 15e:	1300                	add	s0,sp,416
 160:	009c                	add	a5,sp,64
 162:	0000                	unimp
 164:	000c                	.insn	2, 0x000c
 166:	0000                	unimp
 168:	6205                	lui	tp,0x1
 16a:	2700                	.insn	2, 0x2700
 16c:	00d8                	add	a4,sp,68
 16e:	0000                	unimp
 170:	004d                	c.nop	19
 172:	0000                	unimp
 174:	7506                	.insn	2, 0x7506
 176:	0075                	c.nop	29
 178:	0185                	add	gp,gp,1
 17a:	4011                	c.li	zero,4
 17c:	0001                	nop
 17e:	0f00                	add	s0,sp,912
 180:	6d62                	.insn	2, 0x6d62
 182:	0100                	add	s0,sp,128
 184:	0186                	sll	gp,gp,0x1
 186:	e31a                	.insn	2, 0xe31a
 188:	0000                	unimp
 18a:	8500                	.insn	2, 0x8500
 18c:	0000                	unimp
 18e:	0600                	add	s0,sp,768
 190:	01870077          	.insn	4, 0x01870077
 194:	0001330b          	.insn	4, 0x0001330b
 198:	1000                	add	s0,sp,32
 19a:	8f62                	mv	t5,s8
 19c:	4001                	c.li	zero,0
 19e:	0010                	.insn	2, 0x0010
 1a0:	0000                	unimp
 1a2:	0e11                	add	t3,t3,4 # 1a004 <mfdc+0x1980b>
 1a4:	0000                	unimp
 1a6:	0100                	add	s0,sp,128
 1a8:	0190                	add	a2,sp,192
 1aa:	9714                	.insn	2, 0x9714
 1ac:	0000                	unimp
 1ae:	9c00                	.insn	2, 0x9c00
 1b0:	0000                	unimp
 1b2:	0000                	unimp
	...

Disassembly of section .debug_abbrev:

00000000 <.debug_abbrev>:
   0:	2401                	jal	200 <mrac-0x5c0>
   2:	0b00                	add	s0,sp,400
   4:	030b3e0b          	.insn	4, 0x030b3e0b
   8:	000e                	c.slli	zero,0x3
   a:	0200                	add	s0,sp,256
   c:	0016                	c.slli	zero,0x5
   e:	213a0e03          	lb	t3,531(s4)
  12:	3b02                	.insn	2, 0x3b02
  14:	490b390b          	.insn	4, 0x490b390b
  18:	03000013          	li	zero,48
  1c:	0026                	c.slli	zero,0x9
  1e:	1349                	add	t1,t1,-14
  20:	0000                	unimp
  22:	0d04                	add	s1,sp,656
  24:	0300                	add	s0,sp,384
  26:	3a08                	.insn	2, 0x3a08
  28:	0221                	add	tp,tp,8 # 1008 <mfdc+0x80f>
  2a:	0b39053b          	.insn	4, 0x0b39053b
  2e:	1349                	add	t1,t1,-14
  30:	0000                	unimp
  32:	0505                	add	a0,a0,1 # fffe1001 <_tbs_der_store_end+0xaffc1fe1>
  34:	0300                	add	s0,sp,384
  36:	3a08                	.insn	2, 0x3a08
  38:	0121                	add	sp,sp,8
  3a:	0380213b          	.insn	4, 0x0380213b
  3e:	0b39                	add	s6,s6,14
  40:	1349                	add	t1,t1,-14
  42:	1702                	sll	a4,a4,0x20
  44:	0000                	unimp
  46:	3406                	.insn	2, 0x3406
  48:	0300                	add	s0,sp,384
  4a:	3a08                	.insn	2, 0x3a08
  4c:	0121                	add	sp,sp,8
  4e:	0b39053b          	.insn	4, 0x0b39053b
  52:	1349                	add	t1,t1,-14
  54:	0000                	unimp
  56:	25011107          	.insn	4, 0x25011107
  5a:	130e                	sll	t1,t1,0x23
  5c:	1b1f030b          	.insn	4, 0x1b1f030b
  60:	111f 1201 1006      	.insn	6, 0x10061201111f
  66:	08000017          	auipc	zero,0x8000
  6a:	0024                	add	s1,sp,8
  6c:	0b3e0b0b          	.insn	4, 0x0b3e0b0b
  70:	00000803          	lb	a6,0(zero) # 0 <mrac-0x7c0>
  74:	1309                	add	t1,t1,-30
  76:	0301                	add	t1,t1,0
  78:	0b0e                	sll	s6,s6,0x3
  7a:	3b0b3a0b          	.insn	4, 0x3b0b3a0b
  7e:	3905                	jal	fffffcae <_tbs_der_store_end+0xaffe0c8e>
  80:	0013010b          	.insn	4, 0x0013010b
  84:	0a00                	add	s0,sp,272
  86:	000d                	c.nop	3
  88:	0b3a0803          	lb	a6,179(s4)
  8c:	0b39053b          	.insn	4, 0x0b39053b
  90:	1349                	add	t1,t1,-14
  92:	0b38                	add	a4,sp,408
  94:	0000                	unimp
  96:	03000d0b          	.insn	4, 0x03000d0b
  9a:	3a0e                	.insn	2, 0x3a0e
  9c:	39053b0b          	.insn	4, 0x39053b0b
  a0:	3813490b          	.insn	4, 0x3813490b
  a4:	0c00000b          	.insn	4, 0x0c00000b
  a8:	0b0b0117          	auipc	sp,0xb0b0
  ac:	0b3a                	sll	s6,s6,0xe
  ae:	0b39053b          	.insn	4, 0x0b39053b
  b2:	1301                	add	t1,t1,-32
  b4:	0000                	unimp
  b6:	160d                	add	a2,a2,-29
  b8:	0300                	add	s0,sp,384
  ba:	3a0e                	.insn	2, 0x3a0e
  bc:	39053b0b          	.insn	4, 0x39053b0b
  c0:	0013490b          	.insn	4, 0x0013490b
  c4:	0e00                	add	s0,sp,784
  c6:	012e                	sll	sp,sp,0xb
  c8:	0e03193f 053b0b3a 	.insn	8, 0x053b0b3a0e03193f
  d0:	0b39                	add	s6,s6,14
  d2:	13491927          	.insn	4, 0x13491927
  d6:	0111                	add	sp,sp,4 # b0b00ac <mfdc+0xb0af8b3>
  d8:	0612                	sll	a2,a2,0x4
  da:	1840                	add	s0,sp,52
  dc:	197a                	sll	s2,s2,0x3e
  de:	0000                	unimp
  e0:	0300340f          	.insn	4, 0x0300340f
  e4:	3a08                	.insn	2, 0x3a08
  e6:	39053b0b          	.insn	4, 0x39053b0b
  ea:	0213490b          	.insn	4, 0x0213490b
  ee:	10000017          	auipc	zero,0x10000
  f2:	0111010b          	.insn	4, 0x0111010b
  f6:	0612                	sll	a2,a2,0x4
  f8:	0000                	unimp
  fa:	3411                	jal	fffffafe <_tbs_der_store_end+0xaffe0ade>
  fc:	0300                	add	s0,sp,384
  fe:	3a0e                	.insn	2, 0x3a0e
 100:	39053b0b          	.insn	4, 0x39053b0b
 104:	0213490b          	.insn	4, 0x0213490b
 108:	00000017          	auipc	zero,0x0

Disassembly of section .debug_loclists:

00000000 <.debug_loclists>:
   0:	00a9                	add	ra,ra,10
   2:	0000                	unimp
   4:	0005                	c.nop	1
   6:	0004                	.insn	2, 0x0004
   8:	0000                	unimp
   a:	0000                	unimp
   c:	018f4a07          	.insn	4, 0x018f4a07
  10:	5c40                	lw	s0,60(s0)
  12:	0640018f          	.insn	4, 0x0640018f
  16:	935a                	add	t1,t1,s6
  18:	5b04                	lw	s1,48(a4)
  1a:	5c070493          	add	s1,a4,1472 # 1a5c0 <mfdc+0x19dc7>
  1e:	6240018f          	.insn	4, 0x6240018f
  22:	0640018f          	.insn	4, 0x0640018f
  26:	0aa503a3          	sb	a0,167(a0)
  2a:	9f26                	add	t5,t5,s1
  2c:	018f6207          	.insn	4, 0x018f6207
  30:	6a40                	.insn	2, 0x6a40
  32:	0640018f          	.insn	4, 0x0640018f
  36:	935a                	add	t1,t1,s6
  38:	5b04                	lw	s1,48(a4)
  3a:	6a070493          	add	s1,a4,1696
  3e:	7240018f          	.insn	4, 0x7240018f
  42:	0640018f          	.insn	4, 0x0640018f
  46:	0aa503a3          	sb	a0,167(a0)
  4a:	9f26                	add	t5,t5,s1
  4c:	0700                	add	s0,sp,896
  4e:	8f4a                	mv	t5,s2
  50:	4001                	c.li	zero,0
  52:	8f58                	.insn	2, 0x8f58
  54:	4001                	c.li	zero,0
  56:	5c01                	li	s8,-32
  58:	018f5807          	.insn	4, 0x018f5807
  5c:	5e40                	lw	s0,60(a2)
  5e:	0340018f          	.insn	4, 0x0340018f
  62:	207c                	.insn	2, 0x207c
  64:	079f 8f5e 4001      	.insn	6, 0x40018f5e079f
  6a:	8f62                	mv	t5,s8
  6c:	4001                	c.li	zero,0
  6e:	a30a                	.insn	2, 0xa30a
  70:	260ca503          	lw	a0,608(s9)
  74:	2da8                	.insn	2, 0x2da8
  76:	00a8                	add	a0,sp,72
  78:	079f 8f62 4001      	.insn	6, 0x40018f62079f
  7e:	8f72                	mv	t5,t3
  80:	4001                	c.li	zero,0
  82:	5c01                	li	s8,-32
  84:	0700                	add	s0,sp,896
  86:	8f52                	mv	t5,s4
  88:	4001                	c.li	zero,0
  8a:	8f60                	.insn	2, 0x8f60
  8c:	4001                	c.li	zero,0
  8e:	5f01                	li	t5,-32
  90:	018f6207          	.insn	4, 0x018f6207
  94:	7240                	.insn	2, 0x7240
  96:	0140018f          	.insn	4, 0x0140018f
  9a:	005f 6207 018f      	.insn	6, 0x018f6207005f
  a0:	6e40                	.insn	2, 0x6e40
  a2:	0640018f          	.insn	4, 0x0640018f
  a6:	007f007b          	.insn	4, 0x007f007b
  aa:	9f24                	.insn	2, 0x9f24
	...

Disassembly of section .debug_aranges:

00000000 <.debug_aranges>:
   0:	001c                	.insn	2, 0x001c
   2:	0000                	unimp
   4:	0002                	c.slli64	zero
   6:	0000                	unimp
   8:	0000                	unimp
   a:	0004                	.insn	2, 0x0004
   c:	0000                	unimp
   e:	0000                	unimp
  10:	8f4a                	mv	t5,s2
  12:	4001                	c.li	zero,0
  14:	0028                	add	a0,sp,8
	...

Disassembly of section .debug_line:

00000000 <.debug_line>:
   0:	00000103          	lb	sp,0(zero) # 0 <mrac-0x7c0>
   4:	0005                	c.nop	1
   6:	0004                	.insn	2, 0x0004
   8:	00000033          	add	zero,zero,zero
   c:	0101                	add	sp,sp,0
   e:	fb01                	bnez	a4,ffffff1e <_tbs_der_store_end+0xaffe0efe>
  10:	0d0e                	sll	s10,s10,0x3
  12:	0100                	add	s0,sp,128
  14:	0101                	add	sp,sp,0
  16:	0001                	nop
  18:	0000                	unimp
  1a:	0001                	nop
  1c:	0100                	add	s0,sp,128
  1e:	0101                	add	sp,sp,0
  20:	021f 0026 0000      	.insn	6, 0x0026021f
  26:	008c                	add	a1,sp,64
  28:	0000                	unimp
  2a:	0102                	c.slli64	sp
  2c:	021f 030f 001c      	.insn	6, 0x001c030f021f
  32:	0000                	unimp
  34:	1c01                	add	s8,s8,-32 # 19fe0 <mfdc+0x197e7>
  36:	0000                	unimp
  38:	0100                	add	s0,sp,128
  3a:	00a8                	add	a0,sp,72
  3c:	0000                	unimp
  3e:	0501                	add	a0,a0,0
  40:	0001                	nop
  42:	0205                	add	tp,tp,1 # 1 <mrac-0x7bf>
  44:	8f4a                	mv	t5,s2
  46:	4001                	c.li	zero,0
  48:	01038003          	lb	zero,16(t2)
  4c:	0305                	add	t1,t1,1
  4e:	00090103          	lb	sp,0(s2) # 1000 <mfdc+0x807>
  52:	0100                	add	s0,sp,128
  54:	0605                	add	a2,a2,1
  56:	0306                	sll	t1,t1,0x1
  58:	0900                	add	s0,sp,144
  5a:	0000                	unimp
  5c:	0501                	add	a0,a0,0
  5e:	03030603          	lb	a2,48(t1)
  62:	0209                	add	tp,tp,2 # 2 <mrac-0x7be>
  64:	0100                	add	s0,sp,128
  66:	00090103          	lb	sp,0(s2)
  6a:	0100                	add	s0,sp,128
  6c:	1a05                	add	s4,s4,-31
  6e:	0306                	sll	t1,t1,0x1
  70:	0900                	add	s0,sp,144
  72:	0000                	unimp
  74:	0501                	add	a0,a0,0
  76:	01030603          	lb	a2,16(t1)
  7a:	0609                	add	a2,a2,2
  7c:	0100                	add	s0,sp,128
  7e:	00090203          	lb	tp,0(s2)
  82:	0100                	add	s0,sp,128
  84:	0605                	add	a2,a2,1
  86:	0306                	sll	t1,t1,0x1
  88:	0900                	add	s0,sp,144
  8a:	0000                	unimp
  8c:	0501                	add	a0,a0,0
  8e:	02030607          	.insn	4, 0x02030607
  92:	0409                	add	s0,s0,2
  94:	0100                	add	s0,sp,128
  96:	00090103          	lb	sp,0(s2)
  9a:	0100                	add	s0,sp,128
  9c:	2705                	jal	7bc <mrac-0x4>
  9e:	0306                	sll	t1,t1,0x1
  a0:	0900                	add	s0,sp,144
  a2:	0000                	unimp
  a4:	0501                	add	a0,a0,0
  a6:	0324                	add	s1,sp,392
  a8:	0900                	add	s0,sp,144
  aa:	0002                	c.slli64	zero
  ac:	0501                	add	a0,a0,0
  ae:	0a030603          	lb	a2,160(t1)
  b2:	0609                	add	a2,a2,2
  b4:	0100                	add	s0,sp,128
  b6:	0b05                	add	s6,s6,1
  b8:	0306                	sll	t1,t1,0x1
  ba:	0900                	add	s0,sp,144
  bc:	0000                	unimp
  be:	0501                	add	a0,a0,0
  c0:	0301                	add	t1,t1,0
  c2:	0901                	add	s2,s2,0
  c4:	0002                	c.slli64	zero
  c6:	0501                	add	a0,a0,0
  c8:	79030607          	.insn	4, 0x79030607
  cc:	0209                	add	tp,tp,2 # 2 <mrac-0x7be>
  ce:	0100                	add	s0,sp,128
  d0:	00090203          	lb	tp,0(s2)
  d4:	0100                	add	s0,sp,128
  d6:	2505                	jal	6f6 <mrac-0xca>
  d8:	0306                	sll	t1,t1,0x1
  da:	0900                	add	s0,sp,144
  dc:	0000                	unimp
  de:	0501                	add	a0,a0,0
  e0:	01030607          	.insn	4, 0x01030607
  e4:	0409                	add	s0,s0,2
  e6:	0100                	add	s0,sp,128
  e8:	2405                	jal	308 <mrac-0x4b8>
  ea:	0306                	sll	t1,t1,0x1
  ec:	0900                	add	s0,sp,144
  ee:	0000                	unimp
  f0:	0501                	add	a0,a0,0
  f2:	0314                	add	a3,sp,384
  f4:	097d                	add	s2,s2,31
  f6:	0004                	.insn	2, 0x0004
  f8:	0501                	add	a0,a0,0
  fa:	032a                	sll	t1,t1,0xa
  fc:	00040903          	lb	s2,0(s0)
 100:	0901                	add	s2,s2,0
 102:	0004                	.insn	2, 0x0004
 104:	0100                	add	s0,sp,128
 106:	01              	Address 0x106 is out of bounds.


Disassembly of section .debug_str:

00000000 <.debug_str>:
   0:	5744                	lw	s1,44(a4)
   2:	75727473          	csrrc	s0,0x757,4
   6:	68007463          	bgeu	zero,zero,68e <mrac-0x132>
   a:	6769                	lui	a4,0x1a
   c:	0068                	add	a0,sp,12
   e:	72726163          	bltu	tp,t2,730 <mrac-0x90>
  12:	6569                	lui	a0,0x1a
  14:	6f630073          	.insn	4, 0x6f630073
  18:	706d                	c.lui	zero,0xffffb
  1a:	656c                	.insn	2, 0x656c
  1c:	2078                	.insn	2, 0x2078
  1e:	465f 6f6c 7461      	.insn	6, 0x74616f6c465f
  24:	3631                	jal	fffffb30 <_tbs_der_store_end+0xaffe0b10>
  26:	5500                	lw	s0,40(a0)
  28:	79744953          	.insn	4, 0x79744953
  2c:	6570                	.insn	2, 0x6570
  2e:	7500                	.insn	2, 0x7500
  30:	736e                	.insn	2, 0x736e
  32:	6769                	lui	a4,0x1a
  34:	656e                	.insn	2, 0x656e
  36:	2064                	.insn	2, 0x2064
  38:	72616863          	bltu	sp,t1,768 <mrac-0x58>
  3c:	7300                	.insn	2, 0x7300
  3e:	6f68                	.insn	2, 0x6f68
  40:	7472                	.insn	2, 0x7472
  42:	7520                	.insn	2, 0x7520
  44:	736e                	.insn	2, 0x736e
  46:	6769                	lui	a4,0x1a
  48:	656e                	.insn	2, 0x656e
  4a:	2064                	.insn	2, 0x2064
  4c:	6e69                	lui	t3,0x1a
  4e:	0074                	add	a3,sp,12
  50:	5744                	lw	s1,44(a4)
  52:	6e75                	lui	t3,0x1d
  54:	6f69                	lui	t5,0x1a
  56:	006e                	c.slli	zero,0x1b
  58:	5f5f 736c 7268      	.insn	6, 0x7268736c5f5f
  5e:	6964                	.insn	2, 0x6964
  60:	6f630033          	.insn	4, 0x6f630033
  64:	706d                	c.lui	zero,0xffffb
  66:	656c                	.insn	2, 0x656c
  68:	2078                	.insn	2, 0x2078
  6a:	6f6c                	.insn	2, 0x6f6c
  6c:	676e                	.insn	2, 0x676e
  6e:	6420                	.insn	2, 0x6420
  70:	6c62756f          	jal	a0,27736 <mfdc+0x26f3d>
  74:	0065                	c.nop	25
  76:	6f6c                	.insn	2, 0x6f6c
  78:	676e                	.insn	2, 0x676e
  7a:	6c20                	.insn	2, 0x6c20
  7c:	20676e6f          	jal	t3,76282 <mfdc+0x75a89>
  80:	6e75                	lui	t3,0x1d
  82:	6e676973          	csrrs	s2,0x6e6,14
  86:	6465                	lui	s0,0x19
  88:	6920                	.insn	2, 0x6920
  8a:	746e                	.insn	2, 0x746e
  8c:	6c00                	.insn	2, 0x6c00
  8e:	20676e6f          	jal	t3,76294 <mfdc+0x75a9b>
  92:	6f6c                	.insn	2, 0x6f6c
  94:	676e                	.insn	2, 0x676e
  96:	6920                	.insn	2, 0x6920
  98:	746e                	.insn	2, 0x746e
  9a:	7300                	.insn	2, 0x7300
  9c:	6f68                	.insn	2, 0x6f68
  9e:	7472                	.insn	2, 0x7472
  a0:	6920                	.insn	2, 0x6920
  a2:	746e                	.insn	2, 0x746e
  a4:	6300                	.insn	2, 0x6300
  a6:	6c706d6f          	jal	s10,6f6c <mfdc+0x6773>
  aa:	7865                	lui	a6,0xffff9
  ac:	6420                	.insn	2, 0x6420
  ae:	6c62756f          	jal	a0,27774 <mfdc+0x26f7b>
  b2:	0065                	c.nop	25
  b4:	20554e47          	.insn	4, 0x20554e47
  b8:	20373143          	.insn	4, 0x20373143
  bc:	3331                	jal	fffffdc8 <_tbs_der_store_end+0xaffe0da8>
  be:	312e                	.insn	2, 0x312e
  c0:	312e                	.insn	2, 0x312e
  c2:	3220                	.insn	2, 0x3220
  c4:	3230                	.insn	2, 0x3230
  c6:	31373033          	.insn	4, 0x31373033
  ca:	6d2d2033          	.insn	4, 0x6d2d2033
  ce:	646f6d63          	bltu	t5,t1,728 <mrac-0x98>
  d2:	6c65                	lui	s8,0x19
  d4:	6d3d                	lui	s10,0xf
  d6:	6465                	lui	s0,0x19
  d8:	6e61                	lui	t3,0x18
  da:	2079                	jal	168 <mrac-0x658>
  dc:	6d2d                	lui	s10,0xb
  de:	6261                	lui	tp,0x18
  e0:	3d69                	jal	ffffff7a <_tbs_der_store_end+0xaffe0f5a>
  e2:	6c69                	lui	s8,0x1a
  e4:	3370                	.insn	2, 0x3370
  e6:	2032                	.insn	2, 0x2032
  e8:	6d2d                	lui	s10,0xb
  ea:	646f6d63          	bltu	t5,t1,744 <mrac-0x7c>
  ee:	6c65                	lui	s8,0x19
  f0:	6d3d                	lui	s10,0xf
  f2:	6465                	lui	s0,0x19
  f4:	6e61                	lui	t3,0x18
  f6:	2079                	jal	184 <mrac-0x63c>
  f8:	6d2d                	lui	s10,0xb
  fa:	7574                	.insn	2, 0x7574
  fc:	656e                	.insn	2, 0x656e
  fe:	723d                	lui	tp,0xfffef
 100:	656b636f          	jal	t1,b6756 <mfdc+0xb5f5d>
 104:	2074                	.insn	2, 0x2074
 106:	6d2d                	lui	s10,0xb
 108:	7369                	lui	t1,0xffffa
 10a:	2d61                	jal	7a2 <mrac-0x1e>
 10c:	63657073          	csrc	0x636,10
 110:	323d                	jal	fffffa3e <_tbs_der_store_end+0xaffe0a1e>
 112:	322e                	.insn	2, 0x322e
 114:	2d20                	.insn	2, 0x2d20
 116:	616d                	add	sp,sp,240
 118:	6372                	.insn	2, 0x6372
 11a:	3d68                	.insn	2, 0x3d68
 11c:	7672                	.insn	2, 0x7672
 11e:	6d693233          	.insn	4, 0x6d693233
 122:	672d2063          	.insn	4, 0x672d2063
 126:	2d20                	.insn	2, 0x2d20
 128:	2d20734f          	.insn	4, 0x2d20734f
 12c:	2d20324f          	.insn	4, 0x2d20324f
 130:	2d20734f          	.insn	4, 0x2d20734f
 134:	6266                	.insn	2, 0x6266
 136:	6975                	lui	s2,0x1d
 138:	646c                	.insn	2, 0x646c
 13a:	6e69                	lui	t3,0x1a
 13c:	696c2d67          	.insn	4, 0x696c2d67
 140:	6762                	.insn	2, 0x6762
 142:	2d206363          	bltu	zero,s2,408 <mrac-0x3b8>
 146:	6e66                	.insn	2, 0x6e66
 148:	74732d6f          	jal	s10,3308e <mfdc+0x32895>
 14c:	6361                	lui	t1,0x18
 14e:	72702d6b          	.insn	4, 0x72702d6b
 152:	6365746f          	jal	s0,57788 <mfdc+0x56f8f>
 156:	6f74                	.insn	2, 0x6f74
 158:	2072                	.insn	2, 0x2072
 15a:	662d                	lui	a2,0xb
 15c:	6976                	.insn	2, 0x6976
 15e:	69626973          	csrrs	s2,0x696,4
 162:	696c                	.insn	2, 0x696c
 164:	7974                	.insn	2, 0x7974
 166:	683d                	lui	a6,0xf
 168:	6469                	lui	s0,0x1a
 16a:	6564                	.insn	2, 0x6564
 16c:	006e                	c.slli	zero,0x1b
 16e:	706d6f63          	bltu	s10,t1,88c <mfdc+0x93>
 172:	656c                	.insn	2, 0x656c
 174:	2078                	.insn	2, 0x2078
 176:	6c66                	.insn	2, 0x6c66
 178:	0074616f          	jal	sp,4697e <mfdc+0x46185>
 17c:	66696873          	csrrs	a6,0x666,18
 180:	5f74                	lw	a3,124(a4)
 182:	6e756f63          	bltu	a0,t2,880 <mfdc+0x87>
 186:	5f74                	lw	a3,124(a4)
 188:	7974                	.insn	2, 0x7974
 18a:	6570                	.insn	2, 0x6570
 18c:	5f00                	lw	s0,56(a4)
 18e:	6f42                	.insn	2, 0x6f42
 190:	44006c6f          	jal	s8,65d0 <mfdc+0x5dd7>
 194:	7449                	lui	s0,0xffff2
 196:	7079                	c.lui	zero,0xffffe
 198:	0065                	c.nop	25

Disassembly of section .debug_line_str:

00000000 <.debug_line_str>:
   0:	2e2e                	.insn	2, 0x2e2e
   2:	2f2e2e2f          	.insn	4, 0x2f2e2e2f
   6:	2e2e                	.insn	2, 0x2e2e
   8:	2f2e2e2f          	.insn	4, 0x2f2e2e2f
   c:	2e2e                	.insn	2, 0x2e2e
   e:	672f2e2f          	.insn	4, 0x672f2e2f
  12:	6c2f6363          	bltu	t5,sp,6d8 <mrac-0xe8>
  16:	6269                	lui	tp,0x1a
  18:	2f636367          	.insn	4, 0x2f636367
  1c:	696c                	.insn	2, 0x696c
  1e:	6762                	.insn	2, 0x6762
  20:	2e326363          	bltu	tp,gp,306 <mrac-0x4ba>
  24:	682f0063          	beq	t5,sp,6a4 <mrac-0x11c>
  28:	2f656d6f          	jal	s10,5631e <mfdc+0x55b25>
  2c:	6f68                	.insn	2, 0x6f68
  2e:	6475                	lui	s0,0x1d
  30:	68676e6f          	jal	t3,766b6 <mfdc+0x75ebd>
  34:	6975                	lui	s2,0x1d
  36:	7369722f          	.insn	4, 0x7369722f
  3a:	672d7663          	bgeu	s10,s2,6a6 <mrac-0x11a>
  3e:	756e                	.insn	2, 0x756e
  40:	742d                	lui	s0,0xfffeb
  42:	636c6f6f          	jal	t5,c6678 <mfdc+0xc5e7f>
  46:	6168                	.insn	2, 0x6168
  48:	6e69                	lui	t3,0x1a
  4a:	6975622f          	.insn	4, 0x6975622f
  4e:	646c                	.insn	2, 0x646c
  50:	672d                	lui	a4,0xb
  52:	6e2d6363          	bltu	s10,sp,738 <mrac-0x88>
  56:	7765                	lui	a4,0xffff9
  58:	696c                	.insn	2, 0x696c
  5a:	2d62                	.insn	2, 0x2d62
  5c:	67617473          	csrrc	s0,0x676,2
  60:	3265                	jal	fffffa08 <_tbs_der_store_end+0xaffe09e8>
  62:	7369722f          	.insn	4, 0x7369722f
  66:	34367663          	bgeu	a2,gp,3b2 <mrac-0x40e>
  6a:	752d                	lui	a0,0xfffeb
  6c:	6b6e                	.insn	2, 0x6b6e
  6e:	6f6e                	.insn	2, 0x6f6e
  70:	652d6e77          	.insn	4, 0x652d6e77
  74:	666c                	.insn	2, 0x666c
  76:	3376722f          	.insn	4, 0x3376722f
  7a:	6932                	.insn	2, 0x6932
  7c:	636d                	lui	t1,0x1b
  7e:	706c692f          	.insn	4, 0x706c692f
  82:	6c2f3233          	.insn	4, 0x6c2f3233
  86:	6269                	lui	tp,0x1a
  88:	00636367          	.insn	4, 0x00636367
  8c:	2e2e                	.insn	2, 0x2e2e
  8e:	2f2e2e2f          	.insn	4, 0x2f2e2e2f
  92:	2e2e                	.insn	2, 0x2e2e
  94:	2f2e2e2f          	.insn	4, 0x2f2e2e2f
  98:	2e2e                	.insn	2, 0x2e2e
  9a:	672f2e2f          	.insn	4, 0x672f2e2f
  9e:	6c2f6363          	bltu	t5,sp,764 <mrac-0x5c>
  a2:	6269                	lui	tp,0x1a
  a4:	00636367          	.insn	4, 0x00636367
  a8:	696c                	.insn	2, 0x696c
  aa:	6762                	.insn	2, 0x6762
  ac:	2e326363          	bltu	tp,gp,392 <mrac-0x42e>
  b0:	0068                	add	a0,sp,12

Disassembly of section .debug_frame:

00000000 <.debug_frame>:
   0:	000c                	.insn	2, 0x000c
   2:	0000                	unimp
   4:	ffffffff          	.insn	4, 0xffffffff
   8:	7c010003          	lb	zero,1984(sp)
   c:	0d01                	add	s10,s10,0 # b000 <mfdc+0xa807>
   e:	0002                	c.slli64	zero
  10:	000c                	.insn	2, 0x000c
  12:	0000                	unimp
  14:	0000                	unimp
  16:	0000                	unimp
  18:	8f4a                	mv	t5,s2
  1a:	4001                	c.li	zero,0
  1c:	0028                	add	a0,sp,8
	...
